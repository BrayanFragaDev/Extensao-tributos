/* Painel lateral: perfis por entidade, listas com os nomes da entidade, gerador e leitura de fórmulas. */
(function () {
"use strict";
const { MODELOS, hl, esc, hoje } = window.GF;
const $ = s => document.querySelector(s);
const URL_REVISAO_PADRAO = "https://claude.ai/artifact/KnVVmNNkp4SYUvm8vQCxZ9";

let tabId = null, ctx = null, dados = null, perfil = null, config = null, formulas = [], formulaSel = null;

/* ---------- armazenamento ---------- */
const st = {
  get: async k => (await chrome.storage.local.get(k))[k],
  set: (k, v) => chrome.storage.local.set({ [k]: v }),
  del: k => chrome.storage.local.remove(k)
};
function perfilVazio() {
  const estado = {};
  MODELOS.forEach(m => { estado[m.id] = JSON.parse(JSON.stringify(m.padrao)); });
  return { versao: window.GF.VERSAO_PADRAO, modelo: MODELOS[0].id, estado };
}
// perfis salvos com os exemplos antigos voltam em branco (o mapeamento do conversor é mantido)
function migrarPerfil(p) {
  if (!p || p.versao === window.GF.VERSAO_PADRAO) return p;
  const novo = perfilVazio();
  if (p.mapeamento) novo.mapeamento = p.mapeamento;
  return novo;
}
let salvarTimer = null;
function salvarPerfil() {
  if (!ctx) return;
  clearTimeout(salvarTimer);
  salvarTimer = setTimeout(() => st.set("perfil:" + ctx.chave, perfil), 300);
}

/* ---------- página do Cloud ---------- */
async function abaAtual() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  return t;
}
async function naPagina(func, args) {
  if (!tabId) throw new Error("Abra o Tributos Cloud nesta janela.");
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func, args: args || [] });
  if (r && r.error) throw new Error(r.error.message || "erro na página");
  return r ? r.result : null;
}
function status(id, texto, erro) { const el = $(id); el.textContent = texto || ""; el.classList.toggle("erro", !!erro); }

async function atualizarContexto() {
  const t = await abaAtual();
  tabId = t && t.url && t.url.startsWith("https://tributos.betha.cloud/") ? t.id : null;
  let novo = null;
  if (tabId) { try { novo = await naPagina(PAGINA.contexto); } catch (e) { novo = { ok: false, motivo: e.message }; } }
  else novo = { ok: false, motivo: "Abra o Tributos Cloud nesta aba." };
  if (novo && novo.ok && ctx && ctx.chave === novo.chave) { ctx = novo; mostrarEntidade(); return; }
  ctx = novo && novo.ok ? novo : null;
  if (ctx) {
    perfil = migrarPerfil(await st.get("perfil:" + ctx.chave)) || perfilVazio();
    MODELOS.forEach(m => { if (!perfil.estado[m.id]) perfil.estado[m.id] = JSON.parse(JSON.stringify(m.padrao)); });
    dados = (await st.get("dados:" + ctx.chave)) || null;
  } else { perfil = perfil || perfilVazio(); dados = null; }
  formulas = []; formulaSel = null; $("#lista").innerHTML = ""; $("#detalhe").hidden = true;
  mostrarEntidade(novo && !novo.ok ? novo.motivo : "");
  renderTudo();
}
function mostrarEntidade(motivo) {
  if (!ctx) { $("#ent-nome").textContent = "Nenhuma entidade aberta"; $("#ent-info").textContent = motivo || ""; $("#btn-carregar").disabled = true; return; }
  $("#btn-carregar").disabled = false;
  $("#ent-nome").textContent = ctx.nome || "Entidade " + ctx.entidade;
  const d = dados ? `dados de ${new Date(dados.carregadoEm).toLocaleString("pt-BR")}` : "dados da entidade ainda não carregados";
  $("#ent-info").textContent = `entidade ${ctx.entidade} · base ${ctx.database} · ${d}`;
  $("#resumo-dados").textContent = dados
    ? `${dados.campos.length} campos adicionais, ${dados.creditos.length} créditos, ${dados.indexadores.length} indexadores, ${dados.tabelas.length} tabelas de cálculo.` + (dados.avisos.length ? " Avisos: " + dados.avisos.join(" ") : "")
    : "Nenhum dado carregado. Use Atualizar dados no topo.";
}
$("#btn-carregar").addEventListener("click", async () => {
  const b = $("#btn-carregar"); b.disabled = true; b.textContent = "Lendo…";
  try {
    dados = await naPagina(PAGINA.dadosEntidade);
    await st.set("dados:" + ctx.chave, dados);
    mostrarEntidade(); renderTudo();
  } catch (e) { $("#ent-info").textContent = "Não foi possível ler os dados: " + e.message; }
  finally { b.disabled = false; b.textContent = "Atualizar dados"; }
});

/* ---------- listas da entidade ---------- */
function valoresLista(spec, s) {
  if (!dados || !spec) return null;
  const [tipo, arg] = spec.split(":");
  if (tipo === "indexador") return dados.indexadores.map(i => [i.sigla, i.nome]);
  if (tipo === "credito") {
    const f = dados.creditos.filter(c => c.tipoCadastro === arg && c.desativado !== "SIM");
    return (f.length ? f : dados.creditos).map(c => [c.abreviatura, c.descricao]);
  }
  if (tipo === "campo") {
    const base = dados.campos.filter(c => arg === "*" || c.cadastro === arg);
    return (base.length ? base : dados.campos).map(c => [c.titulo, c.tipo.toLowerCase().replace("_", " ") + " · " + (c.cadastro || "")]);
  }
  if (tipo === "opcao") {
    const campo = dados.campos.find(c => c.titulo === s[arg]);
    return campo ? campo.opcoes.map(o => [o, ""]) : null;
  }
  if (tipo === "tabela") {
    const m = new Map(); (dados.tabelas || []).filter(t => t.situacao !== "DESATIVADO").forEach(t => { if (!m.has(String(t.codigo))) m.set(String(t.codigo), t.descricao + " · " + (t.origem || "")); });
    return [...m];
  }
  if (tipo === "receita") {
    const cred = dados.creditos.find(c => c.abreviatura === s[arg]);
    if (cred && cred.receitas.length) return cred.receitas.map(r => [r.abreviatura, r.descricao]);
    const todas = new Map(); dados.creditos.forEach(c => c.receitas.forEach(r => todas.set(r.abreviatura, r.descricao)));
    return [...todas];
  }
  return null;
}
function nomeLista(spec) {
  return { tabela: "tabelas de cálculo", indexador: "indexadores", credito: "créditos", campo: "campos adicionais", opcao: "opções do campo", receita: "receitas do crédito" }[spec.split(":")[0]];
}

/* ---------- formulário ---------- */
const M = () => MODELOS.find(m => m.id === perfil.modelo) || MODELOS[0];
function dl(id, valores) {
  if (!valores) return "";
  return `<datalist id="${id}">${valores.map(v => `<option value="${esc(v[0])}">${esc(v[1] || "")}</option>`).join("")}</datalist>`;
}
function campoHTML(c, s) {
  const id = "f-" + c.k, v = s[c.k] ?? "";
  if (c.t === "rows") {
    const rows = s[c.k] || [];
    let lists = "";
    const head = c.cols.map(x => `<th>${esc(x[1])}</th>`).join("");
    const body = rows.map((r, i) => `<tr>${c.cols.map(x => {
      const dlid = x[2] ? `dl-${c.k}-${x[0]}` : "";
      return `<td><input id="${id}-${i}-${x[0]}" data-rows="${c.k}" data-i="${i}" data-col="${x[0]}" ${x[2] ? `data-lista="${x[2]}" list="${dlid}"` : ""} value="${esc(r[x[0]] ?? "")}" aria-label="${esc(x[1])} linha ${i + 1}"></td>`;
    }).join("")}<td><button type="button" class="del" data-del="${c.k}" data-i="${i}" aria-label="Remover linha ${i + 1}">×</button></td></tr>`).join("");
    c.cols.filter(x => x[2]).forEach(x => { lists += dl(`dl-${c.k}-${x[0]}`, valoresLista(x[2], s)); });
    return `<div style="display:grid;gap:3px"><span class="hint">${esc(c.l)}</span><div class="rows"><table><thead><tr>${head}<th></th></tr></thead><tbody>${body}</tbody></table></div><div><button type="button" class="btn ghost small" data-add="${c.k}">Adicionar linha</button></div>${lists}</div>`;
  }
  if (c.t === "select") return `<label class="f">${esc(c.l)}<select id="${id}" data-k="${c.k}">${c.ops.map(o => `<option value="${o[0]}"${o[0] === v ? " selected" : ""}>${esc(o[1])}</option>`).join("")}</select></label>`;
  if (c.t === "check") return `<label class="f inline"><input type="checkbox" id="${id}" data-k="${c.k}"${v ? " checked" : ""}><span>${esc(c.l)}</span></label>`;
  const lista = c.lista ? `data-lista="${c.lista}" list="dl-${c.k}"` : "";
  return `<label class="f">${esc(c.l)}<input id="${id}" data-k="${c.k}" ${lista} type="${c.t === "number" ? "text" : c.t}" ${c.t === "number" ? 'inputmode="decimal"' : ""} value="${esc(v)}" placeholder="${esc(c.ph || "")}"></label>${c.lista ? dl("dl-" + c.k, valoresLista(c.lista, s)) : ""}`;
}
function renderForm() {
  const m = M(), s = perfil.estado[m.id];
  $("#modelo").innerHTML = MODELOS.map(x => `<option value="${x.id}"${x.id === m.id ? " selected" : ""}>${esc(x.titulo)}</option>`).join("");
  $("#modelo-sub").textContent = m.sub + " · " + m.tipo;
  let h = "";
  m.campos.forEach(g => {
    h += `<fieldset><legend>${esc(g.grupo)}</legend>`;
    let buf = [];
    const flush = () => { if (buf.length) { h += `<div class="two">${buf.join("")}</div>`; buf = []; } };
    g.itens.forEach(c => { if (c.half) { buf.push(campoHTML(c, s)); if (buf.length === 2) flush(); } else { flush(); h += campoHTML(c, s); } });
    flush(); h += `</fieldset>`;
  });
  h += `<div class="acts"><button type="button" class="btn ghost small" id="btn-reset">Limpar formulário</button></div>`;
  $("#form").innerHTML = h;
}
function atualizarListas() {
  const s = perfil.estado[M().id];
  document.querySelectorAll("#form datalist").forEach(d => {
    const inp = document.querySelector(`[list="${d.id}"]`);
    if (!inp) return;
    const v = valoresLista(inp.dataset.lista, s);
    d.innerHTML = (v || []).map(x => `<option value="${esc(x[0])}">${esc(x[1] || "")}</option>`).join("");
  });
}
function conferirNomes() {
  const s = perfil.estado[M().id], avisos = [];
  document.querySelectorAll("#form [data-lista]").forEach(inp => {
    const v = inp.value.trim(), lista = valoresLista(inp.dataset.lista, s);
    const fora = !!(v && lista && lista.length && !lista.some(x => x[0] === v));
    inp.classList.toggle("nao-achado", fora);
    if (fora) avisos.push(`"${v}" não existe em ${nomeLista(inp.dataset.lista)} desta entidade.`);
  });
  return [...new Set(avisos)];
}
function renderOut() {
  const m = M(), s = perfil.estado[m.id];
  const code = m.gerar(s);
  $("#code").innerHTML = hl(code); $("#code").dataset.raw = code;
  const w = m.avisos(s).concat(conferirNomes());
  if (!dados) w.push("Dados da entidade não carregados: os nomes não estão sendo conferidos. Use Atualizar dados.");
  $("#msgs").innerHTML = (w.length ? w.map(x => `<div class="msg warn">${esc(x)}</div>`).join("") : `<div class="msg ok">Parâmetros e nomes conferidos com a entidade.</div>`) +
    m.notas.map(x => `<div class="msg">${esc(x)}</div>`).join("");
  salvarPerfil();
}
function renderTudo() { renderForm(); renderOut(); renderCampos(); if (typeof conversor !== "undefined" && conversor) conversor.atualizar(); }

$("#modelo").addEventListener("change", e => { perfil.modelo = e.target.value; renderTudo(); });
$("#form").addEventListener("input", e => {
  const s = perfil.estado[M().id], t = e.target;
  if (t.dataset.rows) s[t.dataset.rows][+t.dataset.i][t.dataset.col] = t.value;
  else if (t.dataset.k) s[t.dataset.k] = t.type === "checkbox" ? t.checked : t.value;
  atualizarListas(); renderOut();
});
$("#form").addEventListener("click", e => {
  const s = perfil.estado[M().id], t = e.target;
  if (t.dataset.add) { const c = M().campos.flatMap(g => g.itens).find(x => x.k === t.dataset.add); s[t.dataset.add] = s[t.dataset.add] || []; s[t.dataset.add].push(Object.fromEntries(c.cols.map(x => [x[0], ""]))); renderTudo(); }
  if (t.dataset.del) { s[t.dataset.del].splice(+t.dataset.i, 1); renderTudo(); }
  if (t.id === "btn-reset") { perfil.estado[M().id] = JSON.parse(JSON.stringify(M().padrao)); renderTudo(); }
});
$("#form").addEventListener("submit", e => e.preventDefault());

/* ---------- ações ---------- */
async function copiar(texto) { await navigator.clipboard.writeText(texto); }
let skillTexto = null;
async function pedido(codigo, tipo, cadastro) {
  if (skillTexto === null) skillTexto = await (await fetch(chrome.runtime.getURL("skill.md"))).text();
  return "Você é um especialista em fórmulas BFC-Script do Betha Tributos Cloud. Siga estritamente as instruções da skill abaixo, inclusive o catálogo de variáveis (não invente nomes) e o formato de entrega. Responda em português.\n\n<skill>\n" + skillTexto + "\n</skill>\n\n" +
    "TAREFA: Revise a fórmula abaixo e reescreva-a no padrão da casa, preservando a regra de negócio.\nTipo de fórmula: " + (tipo || "descobrir pelo código") + "\nCadastro do crédito: " + (cadastro || "não informado") + "\nEntidade: " + (ctx ? (ctx.nome || ctx.entidade) : "não informada") + "\nData de hoje: " + hoje() + "\n\n<formula_atual>\n" + codigo + "\n</formula_atual>";
}
async function revisar(codigo, tipo, cadastro, statusId) {
  try {
    const completo = config.copiarPedido;
    await copiar(completo ? await pedido(codigo, tipo, cadastro) : codigo);
    await chrome.tabs.create({ url: completo ? "https://claude.ai/new" : (config.urlRevisao || URL_REVISAO_PADRAO) + "#revisar" });
    status(statusId, completo ? "Pedido completo copiado. Cole na conversa que abriu." : "Código copiado. Na página que abriu, cole em Fórmula atual e clique em Revisar.");
  } catch (e) { status(statusId, "Não foi possível copiar: " + e.message, true); }
}
$("#btn-copiar").addEventListener("click", async () => { try { await copiar($("#code").dataset.raw); status("#status-modelo", "Código copiado."); } catch (e) { status("#status-modelo", "Não foi possível copiar: " + e.message, true); } });
$("#btn-inserir").addEventListener("click", async () => {
  try {
    const r = await naPagina(PAGINA.inserirNoEditor, [$("#code").dataset.raw]);
    status("#status-modelo", r && r.ok ? `Código inserido no editor (${r.editor}). Confira e clique em Salvar no Cloud.` : (r && r.motivo) + " Abra a fórmula no Cloud e tente de novo, ou use Copiar código.", !(r && r.ok));
  } catch (e) { status("#status-modelo", "Não foi possível inserir: " + e.message, true); }
});
$("#btn-revisar").addEventListener("click", () => {
  const m = M();
  revisar($("#code").dataset.raw, m.id === "desconto" ? "Desconto para parcelamentos" : "Cálculo", { enquadramento: "Econômicos", faixas: "Imóveis", iptu: "Imóveis", receita: "Receitas diversas" }[m.id], "#status-modelo");
});


/* ---------- aba Campos: campos adicionais, indexadores e funções (imóveis e econômicos) ---------- */
const CAD_CAMPOS = { IMOVEIS: { nome: "Imóveis", ref: "imovel" }, ECONOMICOS: { nome: "Econômicos", ref: "economico" }, RECEITAS_DIVERSAS: { nome: "Receitas diversas", ref: "receitaDiversa" } };
// o cadastro dos campos de receita diversa pode vir com outro nome; normaliza para a chave acima
const normCad = c => /RECEIT/i.test(c || "") ? "RECEITAS_DIVERSAS" : c;
const TIPO_NOME = { NUMERICO: "Numérico", TEXTO: "Texto", DATA: "Data", LISTA_SELECAO: "Lista de seleção", MULTIPLA_SELECAO: "Múltipla seleção" };
const RESERVADAS = new Set(["it", "item", "indice", "ano", "imovel", "economico", "lancamento", "nulo", "se", "senao", "percorrer", "retornar", "suspender", "imprimir", "in", "as", "def", "class", "new", "true", "false", "null", "this", "super", "return", "if", "else", "for", "while"]);
const marcados = new Set(), marcadosIdx = new Set();
let sub = "campos";
const semAcento = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "");
function camel(...partes) {
  const pal = partes.map(semAcento).join(" ").split(/[^A-Za-z0-9]+/).filter(Boolean).map(w => w.toLowerCase());
  let n = pal.map((w, i) => i ? w[0].toUpperCase() + w.slice(1) : w).join("");
  if (/^[0-9]/.test(n)) n = "c" + n;
  if (RESERVADAS.has(n)) n = n + "Campo";  // "it" e afins são reservados no BFC-Script/Groovy
  return n.slice(0, 48) || "campo";
}
const pascal = s => { const c = camel(s); return c[0].toUpperCase() + c.slice(1); };
const chaveCampo = c => c.cadastro + "|" + c.titulo;
const cadAtual = () => $("#c-cad").value || "";
function camposDisponiveis() { return dados ? dados.campos.map(c => Object.assign({}, c, { cadastro: normCad(c.cadastro) })).filter(c => CAD_CAMPOS[c.cadastro] && c.tipo !== "ITEM_SELECAO") : []; }
function refPadrao() { return $("#c-ref").value.trim() || (CAD_CAMPOS[cadAtual()] || {}).ref || ""; }
function refDe(c) { return $("#c-ref").value.trim() || (CAD_CAMPOS[c.cadastro] || {}).ref || "referente"; }
function nomeVar(c) {
  if (c.tipo === "DATA") return "dt" + pascal(c.titulo);
  if (c.tipo === "TEXTO") return "txt" + pascal(c.titulo);
  if (/SELECAO/.test(c.tipo)) return "opc" + pascal(c.titulo);
  return camel(c.titulo);
}
const varIdx = sigla => "vl" + pascal(sigla === "R$" ? "Real" : sigla);
function trechoLer(c) {
  const r = refDe(c), v = nomeVar(c);
  return `${v} = CamposAdicionais.valor(${r}, ${JSON.stringify(c.titulo)}, ano)${c.tipo === "NUMERICO" ? " ?: 0" : ""};`;
}
function trechoOpcao(c, o) { return `eh${pascal(c.titulo)}${pascal(o)} = (CamposAdicionais.valorOpcao(${refDe(c)}, ${JSON.stringify(c.titulo)}, ${JSON.stringify(o)}, ano) ?: false);`; }
function trechoPreencher(c) { return `CamposAdicionais.preencherCampoAdicional(${refDe(c)}, ${JSON.stringify(c.titulo)}, ${nomeVar(c)}, ano);`; }
function trechoIdx(i, modo) {
  const v = varIdx(i.sigla), s = JSON.stringify(i.sigla);
  if (modo === "data") return `${v} = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(${s}, dataLancamento);`;
  if (modo === "periodo") return `movimentos${pascal(i.sigla)} = Utilitarios.buscaMovimentacoesDoIndexadorPorSiglaEmUmPeriodo(${s}, Datas.data(ano, 1, 1), Datas.data(ano, 12, 31));`;
  return `${v} = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(${s}, Datas.data(ano, 1, 1));\nse (${v} == nulo || ${v} == 0) {\n  suspender(ident + "valor do indexador ${i.sigla} nao cadastrado para " + ano + ".");\n}`;
}

/* ----- bloco de leitura ----- */
function blocoMarcados() {
  const lista = camposDisponiveis().filter(c => marcados.has(chaveCampo(c)));
  const idx = dados ? dados.indexadores.filter(i => marcadosIdx.has(i.sigla)) : [];
  if (!lista.length && !idx.length) return "// marque campos adicionais ou indexadores para gerar o bloco";
  const obrig = $("#c-obrig").checked, uso = $("#c-uso").value, L = [];
  if (uso === "preencher") {
    L.push("// ---------- RESULTADO: gravação dos campos adicionais ----------");
    L.push("// só na fórmula de cálculo; calcule cada variável antes deste bloco");
    lista.filter(c => !/SELECAO/.test(c.tipo)).forEach(c => L.push(trechoPreencher(c)));
    const selecao = lista.filter(c => /SELECAO/.test(c.tipo));
    if (selecao.length) L.push("// campos de seleção não entram aqui (o preenchimento de opção não está documentado): " + selecao.map(c => c.titulo).join(", "));
    if (!lista.length) L.push("// indexadores não são gravados; marque campos adicionais");
    return L.join("\n");
  }
  const refs = [...new Set(lista.map(refDe))];
  const ref = refs[0] || refPadrao() || "imovel";
  L.push("// ---------- ENTRADAS E VALIDAÇÕES ----------");
  if (refs.length > 1) L.push("// ATENÇÃO: há campos de cadastros diferentes marcados (" + refs.join(", ") + "); confira o referente de cada leitura.");
  L.push(ref === "economico" ? 'ident = "Economico " + economico.codigo + " (" + ano + "): ";' : ref === "imovel" ? 'ident = "Imovel " + imovel.codigo + " (" + ano + "): ";' : ref === "receitaDiversa" ? 'ident = "Receita diversa " + receitaDiversa.codigo + " (" + ano + "): ";' : 'ident = "Cadastro (" + ano + "): ";');
  let usaFaltando = false;
  if (idx.length) {
    L.push("", "// indexadores do exercício (valor em 1º de janeiro)");
    idx.forEach(i => {
      const v = varIdx(i.sigla);
      L.push(`${v} = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(${JSON.stringify(i.sigla)}, Datas.data(ano, 1, 1));`);
      if (obrig) { L.push(`se (${v} == nulo || ${v} == 0) { faltando = faltando + ${JSON.stringify(" indexador " + i.sigla + ";")}; }`); usaFaltando = true; }
    });
  }
  L.push("");
  lista.forEach(c => {
    L.push(`// ${c.titulo} · ${TIPO_NOME[c.tipo] || c.tipo}${c.formato ? " · " + c.formato.toLowerCase() : ""}`);
    if (/SELECAO/.test(c.tipo)) {
      if (!c.opcoes.length) L.push("// (sem opções cadastradas)");
      c.opcoes.forEach(o => L.push(trechoOpcao(c, o)));
      if (obrig && c.opcoes.length) {
        L.push(`se (!(${c.opcoes.map(o => `eh${pascal(c.titulo)}${pascal(o)}`).join(" || ")})) { faltando = faltando + ${JSON.stringify(" " + c.titulo + ";")}; }`);
        usaFaltando = true;
      }
    } else if (obrig) {
      const v = nomeVar(c);
      L.push(`${v} = CamposAdicionais.valor(${refDe(c)}, ${JSON.stringify(c.titulo)}, ano);`);
      L.push(`se (${v} == nulo${c.tipo === "TEXTO" ? ` || ${v} == ""` : ""}) { faltando = faltando + ${JSON.stringify(" " + c.titulo + ";")}; }`);
      usaFaltando = true;
    } else L.push(trechoLer(c));
    L.push("");
  });
  if (usaFaltando) {
    // acumula o que falta e suspende uma vez só, com tudo listado
    L.splice(L.findIndex(x => x.startsWith("ident =")) + 1, 0, "faltando = \"\";");
    L.push("se (faltando != \"\") {", "  suspender(ident + \"dados sem valor:\" + faltando);", "}");
  }
  return L.join("\n");
}
function renderBloco() { const code = blocoMarcados(); $("#c-code").innerHTML = hl(code); $("#c-code").dataset.raw = code; }

/* ----- listas ----- */
function filtroTexto() { return semAcento($("#c-busca").value.trim().toLowerCase()); }
const casa = (termo, ...txt) => !termo || txt.some(t => semAcento(String(t || "").toLowerCase()).includes(termo));
function renderListaCampos() {
  const todos = camposDisponiveis(), cadSel = cadAtual(), tipoSel = $("#c-tipo").value, termo = filtroTexto();
  const lista = todos.filter(c => (!cadSel || c.cadastro === cadSel) && (!tipoSel || c.tipo === tipoSel) && casa(termo, c.titulo, ...c.opcoes))
    .sort((a, b) => a.cadastro.localeCompare(b.cadastro) || a.titulo.localeCompare(b.titulo, "pt-BR"));
  $("#c-lista").innerHTML = lista.slice(0, 200).map(c => {
    const k = chaveCampo(c), sel = marcados.has(k), id = "cb-" + btoa(unescape(encodeURIComponent(k))).replace(/[^A-Za-z0-9]/g, "");
    const vig = c.anoInicial || c.anoFinal ? ` · vigência ${c.anoInicial || "…"}–${c.anoFinal || "…"}` : "";
    return `<li class="campo${sel ? " sel" : ""}" data-tipo="campo" data-k="${esc(k)}">
      <label class="cab" for="${id}"><input type="checkbox" id="${id}" data-marcar="${esc(k)}"${sel ? " checked" : ""}>
        <span><span class="tit">${esc(c.titulo)}</span><small>${CAD_CAMPOS[c.cadastro].nome} · ${TIPO_NOME[c.tipo] || c.tipo}${c.formato ? " · " + esc(c.formato.toLowerCase()) : ""}${vig}${c.desabilitado === "SIM" ? " · desabilitado" : ""}</small></span></label>
      ${c.opcoes.length ? `<div class="chips">${c.opcoes.map(o => `<button type="button" class="chip" data-opcao="${esc(o)}" title="Copiar teste desta opção">${esc(o)}</button>`).join("")}</div>` : ""}
      <div class="acts">
        <button type="button" class="btn ghost small" data-acao="ler">Copiar leitura</button>
        ${!/SELECAO/.test(c.tipo) ? `<button type="button" class="btn ghost small" data-acao="preencher">Copiar preenchimento</button>` : ""}
        <button type="button" class="btn ghost small" data-acao="nome">Copiar nome</button>
      </div></li>`;
  }).join("");
  status("#status-campos", `${lista.length} campos${lista.length > 200 ? " (mostrando 200; refine a busca)" : ""} · ${marcados.size} campos e ${marcadosIdx.size} indexadores marcados.`);
}
function renderListaIdx() {
  const termo = filtroTexto();
  const lista = dados.indexadores.filter(i => casa(termo, i.sigla, i.nome)).sort((a, b) => String(a.sigla).localeCompare(String(b.sigla), "pt-BR"));
  $("#c-lista").innerHTML = lista.map(i => {
    const sel = marcadosIdx.has(i.sigla), id = "ix-" + btoa(unescape(encodeURIComponent(i.sigla))).replace(/[^A-Za-z0-9]/g, "");
    const ult = i.ultimo ? `último valor ${Number(i.ultimo.valor).toLocaleString("pt-BR", { maximumFractionDigits: 6 })} em ${String(i.ultimo.data).split("-").reverse().join("/")}` : "sem valores cadastrados";
    return `<li class="campo${sel ? " sel" : ""}" data-tipo="idx" data-k="${esc(i.sigla)}">
      <label class="cab" for="${id}"><input type="checkbox" id="${id}" data-marcar-idx="${esc(i.sigla)}"${sel ? " checked" : ""}>
        <span><span class="tit">${esc(i.sigla)}</span> <span>${esc(i.nome || "")}</span><small>${esc((i.tipo || "").toLowerCase().replace(/_/g, " "))} · ${esc(ult)}</small></span></label>
      <div class="acts">
        <button type="button" class="btn ghost small" data-acao="ano">Copiar valor do exercício</button>
        <button type="button" class="btn ghost small" data-acao="data">Valor na data do lançamento</button>
        <button type="button" class="btn ghost small" data-acao="periodo">Movimentações do ano</button>
      </div></li>`;
  }).join("");
  status("#status-campos", `${lista.length} indexadores · marcados entram no bloco de leitura, com validação.`);
}
function exemploChamada(dono, m, ehClasse) {
  const args = m.params.map(p => /^[A-Za-z_][\w.]*$/.test(p) ? p : "<" + p + ">");
  if (!ehClasse && !m.params.length) return `${dono}.${m.nome}`;
  return `${dono}.${m.nome}(${args.join(", ")})`;
}
function renderListaFuncoes() {
  const cad = cadAtual() || "IMOVEIS", cat = dados.catalogos && dados.catalogos[cad];
  if (!cat) { $("#c-lista").innerHTML = ""; status("#status-campos", `Catálogo de ${CAD_CAMPOS[cad].nome.toLowerCase()} não carregado. Use Atualizar dados; é preciso haver uma fórmula de cálculo desse cadastro na entidade.`, true); return; }
  const termo = filtroTexto(), html = [];
  let total = 0;
  [["Variáveis da fórmula", cat.variaveis, false], ["Classes e funções", cat.classes, true]].forEach(([titulo, itens, ehClasse]) => {
    const blocos = [];
    itens.forEach(x => {
      const ms = x.metodos.filter(m => casa(termo, x.nome, m.nome, m.descricao, x.descricao));
      const proprio = casa(termo, x.nome, x.descricao);
      if (!ms.length && !proprio) return;
      total += Math.max(1, ms.length);
      blocos.push(`<li class="fn" data-tipo="fn" data-dono="${esc(x.nome)}"><span><code>${esc(x.nome)}</code>${x.tipo ? ` <small>${esc(x.tipo)}${x.lista ? ", lista" : ""}</small>` : ""}</span><small>${esc(x.descricao)}</small>
        ${!x.metodos.length ? `<div class="acts"><button type="button" class="btn ghost small" data-copia="${esc(x.nome)}">Copiar</button></div>` : ""}</li>`);
      (ms.length ? ms : (proprio ? x.metodos : [])).slice(0, 60).forEach(m => {
        const ex = exemploChamada(x.nome, m, ehClasse);
        blocos.push(`<li class="fn"><code>${esc(ex)}</code><small>${m.retorno ? "→ " + esc(m.retorno) + " · " : ""}${esc(m.descricao)}</small><div class="acts"><button type="button" class="btn ghost small" data-copia="${esc(ex)}">Copiar</button></div></li>`);
      });
    });
    if (blocos.length) html.push(`<li class="grupo-fn">${titulo}</li>` + blocos.join(""));
  });
  $("#c-lista").innerHTML = html.join("");
  status("#status-campos", `${CAD_CAMPOS[cad].nome}: ${total} itens · catálogo lido da fórmula "${cat.origem}". Parâmetros entre < > são para você preencher.`);
}
function renderCampos() {
  ["campos", "indexadores", "funcoes"].forEach(n => { const b = document.querySelector(`.seg [data-sub="${n}"]`); if (b) b.setAttribute("aria-pressed", n === sub); });
  $("#c-tipo-wrap").hidden = sub !== "campos";
  $("#c-busca").placeholder = { campos: "Buscar campo ou opção", indexadores: "Buscar sigla ou nome", funcoes: "Buscar função, variável ou descrição" }[sub];
  const optTodos = $("#c-cad").querySelector('option[value=""]'); if (optTodos) optTodos.hidden = sub === "funcoes";
  if (sub === "funcoes" && !$("#c-cad").value) $("#c-cad").value = "IMOVEIS";
  if (!dados) { $("#c-lista").innerHTML = ""; status("#status-campos", "Use Atualizar dados no topo para ler os dados da entidade.", true); renderBloco(); return; }
  if (sub === "campos") renderListaCampos(); else if (sub === "indexadores") renderListaIdx(); else renderListaFuncoes();
  renderBloco();
}
function prepararFiltros() {
  $("#c-cad").innerHTML = `<option value="">Todos os cadastros</option>` + Object.entries(CAD_CAMPOS).map(([k, v]) => `<option value="${k}">${v.nome}</option>`).join("");
  $("#c-tipo").innerHTML = `<option value="">Todos os tipos</option>` + Object.entries(TIPO_NOME).map(([k, v]) => `<option value="${k}">${v}</option>`).join("");
}
document.querySelector(".seg").addEventListener("click", e => { const b = e.target.closest("[data-sub]"); if (!b) return; sub = b.dataset.sub; $("#c-busca").value = ""; renderCampos(); });
["#c-busca", "#c-ref"].forEach(s => $(s).addEventListener("input", renderCampos));
["#c-cad", "#c-tipo", "#c-uso", "#c-obrig"].forEach(s => $(s).addEventListener("change", renderCampos));
$("#c-lista").addEventListener("click", async e => {
  const t = e.target;
  if (t.dataset.marcar !== undefined) { t.checked ? marcados.add(t.dataset.marcar) : marcados.delete(t.dataset.marcar); renderCampos(); return; }
  if (t.dataset.marcarIdx !== undefined) { t.checked ? marcadosIdx.add(t.dataset.marcarIdx) : marcadosIdx.delete(t.dataset.marcarIdx); renderCampos(); return; }
  let texto = null, rotulo = "Trecho";
  if (t.dataset.copia !== undefined) texto = t.dataset.copia;
  const li = t.closest("[data-tipo]");
  if (texto === null && li && li.dataset.tipo === "campo") {
    const c = camposDisponiveis().find(x => chaveCampo(x) === li.dataset.k); if (!c) return;
    if (t.dataset.opcao !== undefined) { texto = trechoOpcao(c, t.dataset.opcao); rotulo = "Teste da opção"; }
    else if (t.dataset.acao === "ler") { texto = /SELECAO/.test(c.tipo) ? c.opcoes.map(o => trechoOpcao(c, o)).join("\n") || trechoLer(c) : trechoLer(c); rotulo = "Leitura"; }
    else if (t.dataset.acao === "preencher") { texto = trechoPreencher(c); rotulo = "Preenchimento"; }
    else if (t.dataset.acao === "nome") { texto = c.titulo; rotulo = "Nome"; }
  }
  if (texto === null && li && li.dataset.tipo === "idx" && t.dataset.acao) {
    const i = dados.indexadores.find(x => x.sigla === li.dataset.k); if (!i) return;
    texto = trechoIdx(i, t.dataset.acao); rotulo = "Leitura do indexador";
  }
  if (texto === null) return;
  try { await copiar(texto); status("#status-campos", rotulo + " copiado: " + texto.split("\n")[0] + (texto.includes("\n") ? " …" : "")); }
  catch (err) { status("#status-campos", "Não foi possível copiar: " + err.message, true); }
});
$("#c-copiar").addEventListener("click", async () => { try { await copiar($("#c-code").dataset.raw); status("#status-bloco", "Bloco copiado."); } catch (e) { status("#status-bloco", e.message, true); } });
$("#c-inserir").addEventListener("click", async () => {
  try { const r = await naPagina(PAGINA.inserirNoCursor, [$("#c-code").dataset.raw + "\n"]); status("#status-bloco", r && r.ok ? "Bloco inserido na posição do cursor. Confira e salve no Cloud." : (r && r.motivo) + " Use Copiar bloco.", !(r && r.ok)); }
  catch (e) { status("#status-bloco", "Não foi possível inserir: " + e.message, true); }
});
$("#c-limpar").addEventListener("click", () => { marcados.clear(); marcadosIdx.clear(); renderCampos(); });
prepararFiltros();

/* ---------- fórmulas da entidade ---------- */
const TIPOS = { GERACAO_CREDITO: "Cálculo", DESCONTO_PARCELAMENTO: "Desconto para parcelamentos", CONVENIO_BANCARIO: "Convênio bancário", ACRESCIMO: "Acréscimos", DIVIDA_ATIVA: "Dívida ativa", IMPOSTOS_FEDERAIS: "Impostos federais", ITBI: "ITBI", REDUCAO_BASE_CALC_ISSQN: "Redução da base de cálculo do ISSQN", VALIDACAO_CADASTRAL: "Validação cadastral", BENEFICIO_FISCAL: "Benefício fiscal" };
const CADS = { IMOVEIS: "Imóveis", ECONOMICOS: "Econômicos", RECEITAS_DIVERSAS: "Receitas diversas" };
function renderLista() {
  const f = $("#filtro").value.trim().toLowerCase();
  const itens = formulas.filter(x => !f || [x.descricao, x.tipo, TIPOS[x.tipo], x.credito, x.ano].join(" ").toLowerCase().includes(f));
  $("#lista").innerHTML = itens.map(x => `<li><button type="button" data-id="${x.id}" aria-pressed="${formulaSel && formulaSel.id === x.id}"><span>${esc(x.descricao || "(sem descrição)")}</span><small>${esc(TIPOS[x.tipo] || x.tipo)} · ${esc(x.credito || "—")} · ${esc(x.ano || "")}${x.disponivel === "SIM" ? "" : " · desativada"}</small></button></li>`).join("");
  status("#status-formulas", `${itens.length} de ${formulas.length} fórmulas.`);
}
$("#btn-listar").addEventListener("click", async () => {
  status("#status-formulas", "Lendo fórmulas…");
  try { formulas = await naPagina(PAGINA.listarFormulas); renderLista(); }
  catch (e) { status("#status-formulas", "Não foi possível listar: " + e.message, true); }
});
$("#filtro").addEventListener("input", renderLista);
$("#lista").addEventListener("click", e => {
  const b = e.target.closest("[data-id]"); if (!b) return;
  formulaSel = formulas.find(x => String(x.id) === b.dataset.id);
  $("#detalhe").hidden = false;
  $("#det-titulo").textContent = formulaSel.descricao || "(sem descrição)";
  $("#det-info").textContent = `${TIPOS[formulaSel.tipo] || formulaSel.tipo} · crédito ${formulaSel.credito || "—"} · ${formulaSel.ano || ""} · alterada em ${formulaSel.atualizacao || "?"} por ${formulaSel.usuario || "?"}`;
  $("#det-code").innerHTML = hl(formulaSel.codigo || ""); status("#status-det", "");
  renderLista();
});
$("#det-copiar").addEventListener("click", async () => { try { await copiar(formulaSel.codigo || ""); status("#status-det", "Código copiado."); } catch (e) { status("#status-det", e.message, true); } });
$("#det-revisar").addEventListener("click", () => revisar(formulaSel.codigo || "", TIPOS[formulaSel.tipo], CADS[formulaSel.tipoCadastro], "#status-det"));
$("#det-catalogo").addEventListener("click", async () => {
  status("#status-det", "Lendo catálogo…");
  try { await copiar(await naPagina(PAGINA.catalogo, [formulaSel.id])); status("#status-det", "Catálogo copiado. Cole junto com a fórmula ao pedir uma revisão."); }
  catch (e) { status("#status-det", "Não foi possível ler o catálogo: " + e.message, true); }
});

/* ---------- ajustes ---------- */
async function carregarConfig() {
  config = Object.assign({ urlRevisao: URL_REVISAO_PADRAO, copiarPedido: false }, (await st.get("config")) || {});
  $("#url-revisao").value = config.urlRevisao; $("#copiar-pedido").checked = !!config.copiarPedido;
}
$("#url-revisao").addEventListener("change", e => { config.urlRevisao = e.target.value.trim() || URL_REVISAO_PADRAO; st.set("config", config); });
$("#copiar-pedido").addEventListener("change", e => { config.copiarPedido = e.target.checked; st.set("config", config); });
$("#btn-exportar").addEventListener("click", () => {
  const pacote = { formato: "formulas-tributos-perfil/1", exportadoEm: new Date().toISOString(), entidade: ctx, perfil, dados };
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(pacote, null, 2)], { type: "application/json" }));
  a.download = "perfil-" + (ctx ? ctx.chave : "sem-entidade") + ".json"; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  status("#status-ajustes", "Perfil exportado.");
});
$("#importar").addEventListener("change", async e => {
  const f = e.target.files[0]; if (!f) return;
  try {
    const p = JSON.parse(await f.text());
    if (p.formato !== "formulas-tributos-perfil/1" || !p.perfil) throw new Error("arquivo não é um perfil desta extensão");
    perfil = Object.assign({ versao: window.GF.VERSAO_PADRAO }, p.perfil);
    MODELOS.forEach(m => { if (!perfil.estado[m.id]) perfil.estado[m.id] = JSON.parse(JSON.stringify(m.padrao)); });
    const mesma = ctx && p.entidade && p.entidade.chave === ctx.chave;
    if (mesma && p.dados) { dados = p.dados; await st.set("dados:" + ctx.chave, dados); }
    salvarPerfil(); mostrarEntidade(); renderTudo();
    status("#status-ajustes", mesma ? "Perfil importado." : "Modelos importados de outra entidade. Use Atualizar dados para conferir os nomes nesta.");
  } catch (err) { status("#status-ajustes", "Não foi possível importar: " + err.message, true); }
  e.target.value = "";
});
$("#btn-limpar").addEventListener("click", async () => {
  if (!ctx) return;
  await st.del("perfil:" + ctx.chave); await st.del("dados:" + ctx.chave);
  perfil = perfilVazio(); dados = null; mostrarEntidade(); renderTudo();
  status("#status-ajustes", "Perfil desta entidade apagado.");
});

/* ---------- abas e início ---------- */
function aba(nome) { ["modelos", "campos", "converter", "formulas", "ajustes"].forEach(n => { $("#tab-" + n).setAttribute("aria-selected", n === nome); $("#view-" + n).hidden = n !== nome; }); }
["modelos", "campos", "converter", "formulas", "ajustes"].forEach(n => $("#tab-" + n).addEventListener("click", () => aba(n)));

/* ---------- conversor desktop → Cloud ---------- */
const conversor = window.montarConversor($("#view-converter"), {
  getDados: () => dados,
  getChave: () => (ctx ? ctx.chave : ""),
  getMapa: () => (perfil && perfil.mapeamento) || {},
  setMapa: m => { if (!perfil) return; perfil.mapeamento = m; salvarPerfil(); },
  copiar: t => copiar(t),
  inserir: codigo => naPagina(PAGINA.inserirNoEditor, [codigo]),
  hl,
  revisar: async (r, avisar) => {
    try {
      if (skillTexto === null) skillTexto = await (await fetch(chrome.runtime.getURL("skill.md"))).text();
      const pedidoTxt = "Você é um especialista em fórmulas BFC-Script do Betha Tributos Cloud. Siga as instruções da skill abaixo, inclusive o catálogo de variáveis e o formato de entrega. Responda em português.\n\n<skill>\n" + skillTexto + "\n</skill>\n\n" +
        "TAREFA: A fórmula abaixo foi convertida automaticamente do Tributos desktop (SQL Anywhere) para BFC-Script. Termine a conversão: resolva as pendências, reorganize no padrão da casa (PARÂMETROS, ENTRADAS E VALIDAÇÕES, CÁLCULO, RESULTADO) e preserve a regra do desktop. Nomes de campos adicionais, opções e receitas já mapeados no rascunho são os reais da entidade: não os altere.\n" +
        "Tipo: " + r.tipo + " | Cadastro: " + r.cadastro + " | Entidade: " + (ctx ? (ctx.nome || ctx.entidade) : "?") + "\n\nPendências apontadas pelo conversor:\n- " + (r.pendencias.join("\n- ") || "nenhuma") +
        "\n\nObservações:\n- " + (r.notas.join("\n- ") || "nenhuma") + "\n\n<formula_desktop>\n" + r.original + "\n</formula_desktop>\n\n<rascunho_bfc>\n" + r.codigo + "\n</rascunho_bfc>";
      await copiar(pedidoTxt);
      await chrome.tabs.create({ url: "https://claude.ai/new" });
      avisar("Pedido de revisão copiado (com a fórmula do desktop e o rascunho). Cole na conversa que abriu.");
    } catch (e) { avisar("Não foi possível preparar a revisão: " + e.message); }
  }
});

chrome.tabs.onActivated.addListener(() => atualizarContexto());
chrome.tabs.onUpdated.addListener((id, info) => { if (info.url || info.status === "complete") atualizarContexto(); });

(async () => { perfil = perfilVazio(); await carregarConfig(); await atualizarContexto(); })();
})();
