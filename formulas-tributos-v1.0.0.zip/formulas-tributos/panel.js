/* Painel lateral: perfis por entidade, listas com os nomes da entidade, gerador e leitura de fórmulas. */
(function () {
"use strict";
const { MODELOS, hl, esc, hoje } = window.GF;
const $ = s => document.querySelector(s);
const URL_REVISAO_PADRAO = "https://claude.ai/artifact/KnVVmNNkp4SYUvm8vQCxZ9";

let tabId = null, ctx = null, dados = null, perfil = null, config = null, formulas = [], formulaSel = null;

/* ---------- armazenamento ---------- */
const st = {
  get: async k => (await chrome.storage.local.get(k))[k],
  set: (k, v) => chrome.storage.local.set({ [k]: v }),
  del: k => chrome.storage.local.remove(k)
};
function perfilVazio() {
  const estado = {};
  MODELOS.forEach(m => { estado[m.id] = JSON.parse(JSON.stringify(m.padrao)); });
  return { modelo: MODELOS[0].id, estado };
}
let salvarTimer = null;
function salvarPerfil() {
  if (!ctx) return;
  clearTimeout(salvarTimer);
  salvarTimer = setTimeout(() => st.set("perfil:" + ctx.chave, perfil), 300);
}

/* ---------- página do Cloud ---------- */
async function abaAtual() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  return t;
}
async function naPagina(func, args) {
  if (!tabId) throw new Error("Abra o Tributos Cloud nesta janela.");
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func, args: args || [] });
  if (r && r.error) throw new Error(r.error.message || "erro na página");
  return r ? r.result : null;
}
function status(id, texto, erro) { const el = $(id); el.textContent = texto || ""; el.classList.toggle("erro", !!erro); }

async function atualizarContexto() {
  const t = await abaAtual();
  tabId = t && t.url && t.url.startsWith("https://tributos.betha.cloud/") ? t.id : null;
  let novo = null;
  if (tabId) { try { novo = await naPagina(PAGINA.contexto); } catch (e) { novo = { ok: false, motivo: e.message }; } }
  else novo = { ok: false, motivo: "Abra o Tributos Cloud nesta aba." };
  if (novo && novo.ok && ctx && ctx.chave === novo.chave) { ctx = novo; mostrarEntidade(); return; }
  ctx = novo && novo.ok ? novo : null;
  if (ctx) {
    perfil = (await st.get("perfil:" + ctx.chave)) || perfilVazio();
    MODELOS.forEach(m => { if (!perfil.estado[m.id]) perfil.estado[m.id] = JSON.parse(JSON.stringify(m.padrao)); });
    dados = (await st.get("dados:" + ctx.chave)) || null;
  } else { perfil = perfil || perfilVazio(); dados = null; }
  formulas = []; formulaSel = null; $("#lista").innerHTML = ""; $("#detalhe").hidden = true;
  mostrarEntidade(novo && !novo.ok ? novo.motivo : "");
  renderTudo();
}
function mostrarEntidade(motivo) {
  if (!ctx) { $("#ent-nome").textContent = "Nenhuma entidade aberta"; $("#ent-info").textContent = motivo || ""; $("#btn-carregar").disabled = true; return; }
  $("#btn-carregar").disabled = false;
  $("#ent-nome").textContent = ctx.nome || "Entidade " + ctx.entidade;
  const d = dados ? `dados de ${new Date(dados.carregadoEm).toLocaleString("pt-BR")}` : "dados da entidade ainda não carregados";
  $("#ent-info").textContent = `entidade ${ctx.entidade} · base ${ctx.database} · ${d}`;
  $("#resumo-dados").textContent = dados
    ? `${dados.campos.length} campos adicionais, ${dados.creditos.length} créditos, ${dados.indexadores.length} indexadores, ${dados.tabelas.length} tabelas de cálculo.` + (dados.avisos.length ? " Avisos: " + dados.avisos.join(" ") : "")
    : "Nenhum dado carregado. Use Atualizar dados no topo.";
}
$("#btn-carregar").addEventListener("click", async () => {
  const b = $("#btn-carregar"); b.disabled = true; b.textContent = "Lendo…";
  try {
    dados = await naPagina(PAGINA.dadosEntidade);
    await st.set("dados:" + ctx.chave, dados);
    mostrarEntidade(); renderTudo();
  } catch (e) { $("#ent-info").textContent = "Não foi possível ler os dados: " + e.message; }
  finally { b.disabled = false; b.textContent = "Atualizar dados"; }
});

/* ---------- listas da entidade ---------- */
function valoresLista(spec, s) {
  if (!dados || !spec) return null;
  const [tipo, arg] = spec.split(":");
  if (tipo === "indexador") return dados.indexadores.map(i => [i.sigla, i.nome]);
  if (tipo === "credito") {
    const f = dados.creditos.filter(c => c.tipoCadastro === arg && c.desativado !== "SIM");
    return (f.length ? f : dados.creditos).map(c => [c.abreviatura, c.descricao]);
  }
  if (tipo === "campo") {
    const base = dados.campos.filter(c => arg === "*" || c.cadastro === arg);
    return (base.length ? base : dados.campos).map(c => [c.titulo, c.tipo.toLowerCase().replace("_", " ") + " · " + (c.cadastro || "")]);
  }
  if (tipo === "opcao") {
    const campo = dados.campos.find(c => c.titulo === s[arg]);
    return campo ? campo.opcoes.map(o => [o, ""]) : null;
  }
  if (tipo === "receita") {
    const cred = dados.creditos.find(c => c.abreviatura === s[arg]);
    if (cred && cred.receitas.length) return cred.receitas.map(r => [r.abreviatura, r.descricao]);
    const todas = new Map(); dados.creditos.forEach(c => c.receitas.forEach(r => todas.set(r.abreviatura, r.descricao)));
    return [...todas];
  }
  return null;
}
function nomeLista(spec) {
  return { indexador: "indexadores", credito: "créditos", campo: "campos adicionais", opcao: "opções do campo", receita: "receitas do crédito" }[spec.split(":")[0]];
}

/* ---------- formulário ---------- */
const M = () => MODELOS.find(m => m.id === perfil.modelo) || MODELOS[0];
function dl(id, valores) {
  if (!valores) return "";
  return `<datalist id="${id}">${valores.map(v => `<option value="${esc(v[0])}">${esc(v[1] || "")}</option>`).join("")}</datalist>`;
}
function campoHTML(c, s) {
  const id = "f-" + c.k, v = s[c.k] ?? "";
  if (c.t === "rows") {
    const rows = s[c.k] || [];
    let lists = "";
    const head = c.cols.map(x => `<th>${esc(x[1])}</th>`).join("");
    const body = rows.map((r, i) => `<tr>${c.cols.map(x => {
      const dlid = x[2] ? `dl-${c.k}-${x[0]}` : "";
      return `<td><input id="${id}-${i}-${x[0]}" data-rows="${c.k}" data-i="${i}" data-col="${x[0]}" ${x[2] ? `data-lista="${x[2]}" list="${dlid}"` : ""} value="${esc(r[x[0]] ?? "")}" aria-label="${esc(x[1])} linha ${i + 1}"></td>`;
    }).join("")}<td><button type="button" class="del" data-del="${c.k}" data-i="${i}" aria-label="Remover linha ${i + 1}">×</button></td></tr>`).join("");
    c.cols.filter(x => x[2]).forEach(x => { lists += dl(`dl-${c.k}-${x[0]}`, valoresLista(x[2], s)); });
    return `<div style="display:grid;gap:3px"><span class="hint">${esc(c.l)}</span><div class="rows"><table><thead><tr>${head}<th></th></tr></thead><tbody>${body}</tbody></table></div><div><button type="button" class="btn ghost small" data-add="${c.k}">Adicionar linha</button></div>${lists}</div>`;
  }
  if (c.t === "select") return `<label class="f">${esc(c.l)}<select id="${id}" data-k="${c.k}">${c.ops.map(o => `<option value="${o[0]}"${o[0] === v ? " selected" : ""}>${esc(o[1])}</option>`).join("")}</select></label>`;
  if (c.t === "check") return `<label class="f inline"><input type="checkbox" id="${id}" data-k="${c.k}"${v ? " checked" : ""}><span>${esc(c.l)}</span></label>`;
  const lista = c.lista ? `data-lista="${c.lista}" list="dl-${c.k}"` : "";
  return `<label class="f">${esc(c.l)}<input id="${id}" data-k="${c.k}" ${lista} type="${c.t === "number" ? "text" : c.t}" ${c.t === "number" ? 'inputmode="decimal"' : ""} value="${esc(v)}" placeholder="${esc(c.ph || "")}"></label>${c.lista ? dl("dl-" + c.k, valoresLista(c.lista, s)) : ""}`;
}
function renderForm() {
  const m = M(), s = perfil.estado[m.id];
  $("#modelo").innerHTML = MODELOS.map(x => `<option value="${x.id}"${x.id === m.id ? " selected" : ""}>${esc(x.titulo)}</option>`).join("");
  $("#modelo-sub").textContent = m.sub + " · " + m.tipo;
  let h = "";
  m.campos.forEach(g => {
    h += `<fieldset><legend>${esc(g.grupo)}</legend>`;
    let buf = [];
    const flush = () => { if (buf.length) { h += `<div class="two">${buf.join("")}</div>`; buf = []; } };
    g.itens.forEach(c => { if (c.half) { buf.push(campoHTML(c, s)); if (buf.length === 2) flush(); } else { flush(); h += campoHTML(c, s); } });
    flush(); h += `</fieldset>`;
  });
  h += `<div class="acts"><button type="button" class="btn ghost small" id="btn-reset">Voltar ao exemplo</button></div>`;
  $("#form").innerHTML = h;
}
function atualizarListas() {
  const s = perfil.estado[M().id];
  document.querySelectorAll("#form datalist").forEach(d => {
    const inp = document.querySelector(`[list="${d.id}"]`);
    if (!inp) return;
    const v = valoresLista(inp.dataset.lista, s);
    d.innerHTML = (v || []).map(x => `<option value="${esc(x[0])}">${esc(x[1] || "")}</option>`).join("");
  });
}
function conferirNomes() {
  const s = perfil.estado[M().id], avisos = [];
  document.querySelectorAll("#form [data-lista]").forEach(inp => {
    const v = inp.value.trim(), lista = valoresLista(inp.dataset.lista, s);
    const fora = !!(v && lista && lista.length && !lista.some(x => x[0] === v));
    inp.classList.toggle("nao-achado", fora);
    if (fora) avisos.push(`"${v}" não existe em ${nomeLista(inp.dataset.lista)} desta entidade.`);
  });
  return [...new Set(avisos)];
}
function renderOut() {
  const m = M(), s = perfil.estado[m.id];
  const code = m.gerar(s);
  $("#code").innerHTML = hl(code); $("#code").dataset.raw = code;
  const w = m.avisos(s).concat(conferirNomes());
  if (!dados) w.push("Dados da entidade não carregados: os nomes não estão sendo conferidos. Use Atualizar dados.");
  $("#msgs").innerHTML = (w.length ? w.map(x => `<div class="msg warn">${esc(x)}</div>`).join("") : `<div class="msg ok">Parâmetros e nomes conferidos com a entidade.</div>`) +
    m.notas.map(x => `<div class="msg">${esc(x)}</div>`).join("");
  salvarPerfil();
}
function renderTudo() { renderForm(); renderOut(); }

$("#modelo").addEventListener("change", e => { perfil.modelo = e.target.value; renderTudo(); });
$("#form").addEventListener("input", e => {
  const s = perfil.estado[M().id], t = e.target;
  if (t.dataset.rows) s[t.dataset.rows][+t.dataset.i][t.dataset.col] = t.value;
  else if (t.dataset.k) s[t.dataset.k] = t.type === "checkbox" ? t.checked : t.value;
  atualizarListas(); renderOut();
});
$("#form").addEventListener("click", e => {
  const s = perfil.estado[M().id], t = e.target;
  if (t.dataset.add) { const c = M().campos.flatMap(g => g.itens).find(x => x.k === t.dataset.add); s[t.dataset.add] = s[t.dataset.add] || []; s[t.dataset.add].push(Object.fromEntries(c.cols.map(x => [x[0], ""]))); renderTudo(); }
  if (t.dataset.del) { s[t.dataset.del].splice(+t.dataset.i, 1); renderTudo(); }
  if (t.id === "btn-reset") { perfil.estado[M().id] = JSON.parse(JSON.stringify(M().padrao)); renderTudo(); }
});
$("#form").addEventListener("submit", e => e.preventDefault());

/* ---------- ações ---------- */
async function copiar(texto) { await navigator.clipboard.writeText(texto); }
let skillTexto = null;
async function pedido(codigo, tipo, cadastro) {
  if (skillTexto === null) skillTexto = await (await fetch(chrome.runtime.getURL("skill.md"))).text();
  return "Você é um especialista em fórmulas BFC-Script do Betha Tributos Cloud. Siga estritamente as instruções da skill abaixo, inclusive o catálogo de variáveis (não invente nomes) e o formato de entrega. Responda em português.\n\n<skill>\n" + skillTexto + "\n</skill>\n\n" +
    "TAREFA: Revise a fórmula abaixo e reescreva-a no padrão da casa, preservando a regra de negócio.\nTipo de fórmula: " + (tipo || "descobrir pelo código") + "\nCadastro do crédito: " + (cadastro || "não informado") + "\nEntidade: " + (ctx ? (ctx.nome || ctx.entidade) : "não informada") + "\nData de hoje: " + hoje() + "\n\n<formula_atual>\n" + codigo + "\n</formula_atual>";
}
async function revisar(codigo, tipo, cadastro, statusId) {
  try {
    const completo = config.copiarPedido;
    await copiar(completo ? await pedido(codigo, tipo, cadastro) : codigo);
    await chrome.tabs.create({ url: completo ? "https://claude.ai/new" : (config.urlRevisao || URL_REVISAO_PADRAO) + "#revisar" });
    status(statusId, completo ? "Pedido completo copiado. Cole na conversa que abriu." : "Código copiado. Na página que abriu, cole em Fórmula atual e clique em Revisar.");
  } catch (e) { status(statusId, "Não foi possível copiar: " + e.message, true); }
}
$("#btn-copiar").addEventListener("click", async () => { try { await copiar($("#code").dataset.raw); status("#status-modelo", "Código copiado."); } catch (e) { status("#status-modelo", "Não foi possível copiar: " + e.message, true); } });
$("#btn-inserir").addEventListener("click", async () => {
  try {
    const r = await naPagina(PAGINA.inserirNoEditor, [$("#code").dataset.raw]);
    status("#status-modelo", r && r.ok ? `Código inserido no editor (${r.editor}). Confira e clique em Salvar no Cloud.` : (r && r.motivo) + " Abra a fórmula no Cloud e tente de novo, ou use Copiar código.", !(r && r.ok));
  } catch (e) { status("#status-modelo", "Não foi possível inserir: " + e.message, true); }
});
$("#btn-revisar").addEventListener("click", () => {
  const m = M();
  revisar($("#code").dataset.raw, m.id === "desconto" ? "Desconto para parcelamentos" : "Cálculo", { enquadramento: "Econômicos", faixas: "Imóveis", receita: "Receitas diversas" }[m.id], "#status-modelo");
});

/* ---------- fórmulas da entidade ---------- */
const TIPOS = { GERACAO_CREDITO: "Cálculo", DESCONTO_PARCELAMENTO: "Desconto para parcelamentos", CONVENIO_BANCARIO: "Convênio bancário", ACRESCIMO: "Acréscimos", DIVIDA_ATIVA: "Dívida ativa", IMPOSTOS_FEDERAIS: "Impostos federais", ITBI: "ITBI", REDUCAO_BASE_CALC_ISSQN: "Redução da base de cálculo do ISSQN", VALIDACAO_CADASTRAL: "Validação cadastral", BENEFICIO_FISCAL: "Benefício fiscal" };
const CADS = { IMOVEIS: "Imóveis", ECONOMICOS: "Econômicos", RECEITAS_DIVERSAS: "Receitas diversas" };
function renderLista() {
  const f = $("#filtro").value.trim().toLowerCase();
  const itens = formulas.filter(x => !f || [x.descricao, x.tipo, TIPOS[x.tipo], x.credito, x.ano].join(" ").toLowerCase().includes(f));
  $("#lista").innerHTML = itens.map(x => `<li><button type="button" data-id="${x.id}" aria-pressed="${formulaSel && formulaSel.id === x.id}"><span>${esc(x.descricao || "(sem descrição)")}</span><small>${esc(TIPOS[x.tipo] || x.tipo)} · ${esc(x.credito || "—")} · ${esc(x.ano || "")}${x.disponivel === "SIM" ? "" : " · desativada"}</small></button></li>`).join("");
  status("#status-formulas", `${itens.length} de ${formulas.length} fórmulas.`);
}
$("#btn-listar").addEventListener("click", async () => {
  status("#status-formulas", "Lendo fórmulas…");
  try { formulas = await naPagina(PAGINA.listarFormulas); renderLista(); }
  catch (e) { status("#status-formulas", "Não foi possível listar: " + e.message, true); }
});
$("#filtro").addEventListener("input", renderLista);
$("#lista").addEventListener("click", e => {
  const b = e.target.closest("[data-id]"); if (!b) return;
  formulaSel = formulas.find(x => String(x.id) === b.dataset.id);
  $("#detalhe").hidden = false;
  $("#det-titulo").textContent = formulaSel.descricao || "(sem descrição)";
  $("#det-info").textContent = `${TIPOS[formulaSel.tipo] || formulaSel.tipo} · crédito ${formulaSel.credito || "—"} · ${formulaSel.ano || ""} · alterada em ${formulaSel.atualizacao || "?"} por ${formulaSel.usuario || "?"}`;
  $("#det-code").innerHTML = hl(formulaSel.codigo || ""); status("#status-det", "");
  renderLista();
});
$("#det-copiar").addEventListener("click", async () => { try { await copiar(formulaSel.codigo || ""); status("#status-det", "Código copiado."); } catch (e) { status("#status-det", e.message, true); } });
$("#det-revisar").addEventListener("click", () => revisar(formulaSel.codigo || "", TIPOS[formulaSel.tipo], CADS[formulaSel.tipoCadastro], "#status-det"));
$("#det-catalogo").addEventListener("click", async () => {
  status("#status-det", "Lendo catálogo…");
  try { await copiar(await naPagina(PAGINA.catalogo, [formulaSel.id])); status("#status-det", "Catálogo copiado. Cole junto com a fórmula ao pedir uma revisão."); }
  catch (e) { status("#status-det", "Não foi possível ler o catálogo: " + e.message, true); }
});

/* ---------- ajustes ---------- */
async function carregarConfig() {
  config = Object.assign({ urlRevisao: URL_REVISAO_PADRAO, copiarPedido: false }, (await st.get("config")) || {});
  $("#url-revisao").value = config.urlRevisao; $("#copiar-pedido").checked = !!config.copiarPedido;
}
$("#url-revisao").addEventListener("change", e => { config.urlRevisao = e.target.value.trim() || URL_REVISAO_PADRAO; st.set("config", config); });
$("#copiar-pedido").addEventListener("change", e => { config.copiarPedido = e.target.checked; st.set("config", config); });
$("#btn-exportar").addEventListener("click", () => {
  const pacote = { formato: "formulas-tributos-perfil/1", exportadoEm: new Date().toISOString(), entidade: ctx, perfil, dados };
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(pacote, null, 2)], { type: "application/json" }));
  a.download = "perfil-" + (ctx ? ctx.chave : "sem-entidade") + ".json"; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  status("#status-ajustes", "Perfil exportado.");
});
$("#importar").addEventListener("change", async e => {
  const f = e.target.files[0]; if (!f) return;
  try {
    const p = JSON.parse(await f.text());
    if (p.formato !== "formulas-tributos-perfil/1" || !p.perfil) throw new Error("arquivo não é um perfil desta extensão");
    perfil = p.perfil;
    MODELOS.forEach(m => { if (!perfil.estado[m.id]) perfil.estado[m.id] = JSON.parse(JSON.stringify(m.padrao)); });
    const mesma = ctx && p.entidade && p.entidade.chave === ctx.chave;
    if (mesma && p.dados) { dados = p.dados; await st.set("dados:" + ctx.chave, dados); }
    salvarPerfil(); mostrarEntidade(); renderTudo();
    status("#status-ajustes", mesma ? "Perfil importado." : "Modelos importados de outra entidade. Use Atualizar dados para conferir os nomes nesta.");
  } catch (err) { status("#status-ajustes", "Não foi possível importar: " + err.message, true); }
  e.target.value = "";
});
$("#btn-limpar").addEventListener("click", async () => {
  if (!ctx) return;
  await st.del("perfil:" + ctx.chave); await st.del("dados:" + ctx.chave);
  perfil = perfilVazio(); dados = null; mostrarEntidade(); renderTudo();
  status("#status-ajustes", "Perfil desta entidade apagado.");
});

/* ---------- abas e início ---------- */
function aba(nome) { ["modelos", "formulas", "ajustes"].forEach(n => { $("#tab-" + n).setAttribute("aria-selected", n === nome); $("#view-" + n).hidden = n !== nome; }); }
["modelos", "formulas", "ajustes"].forEach(n => $("#tab-" + n).addEventListener("click", () => aba(n)));

chrome.tabs.onActivated.addListener(() => atualizarContexto());
chrome.tabs.onUpdated.addListener((id, info) => { if (info.url || info.status === "complete") atualizarContexto(); });

(async () => { perfil = perfilVazio(); await carregarConfig(); await atualizarContexto(); })();
})();
