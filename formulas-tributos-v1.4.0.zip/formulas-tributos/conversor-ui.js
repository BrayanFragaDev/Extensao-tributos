/* Aba "Converter" (desktop → Cloud), compartilhada pela extensão e pela página.
   montarConversor(elemento, opcoes):
     getDados()      -> dados da entidade (campos, creditos, indexadores, tabelas) ou null
     getChave()      -> chave da entidade ("db447-ent804") ou ""
     getMapa()/setMapa(m) -> mapeamento salvo por entidade
     copiar(texto)   -> Promise
     inserir(codigo) -> Promise<{ok, motivo}> (opcional; só na extensão)
     revisar({ codigo, original, pendencias, notas, cadastro }) -> void
     hl(codigo)      -> HTML com destaque de sintaxe */
(function () {
"use strict";
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const CAD_CAMPO = { bce: "ECONOMICOS", bci: "IMOVEIS", bcc: "CONTRIBUINTES", projeto: "PROJETOS_DE_OBRAS" };
const NOMES_CAD = { IMOVEIS: "Imóveis", ECONOMICOS: "Econômicos", RECEITAS_DIVERSAS: "Receitas diversas", PROJETOS: "Projetos/obras" };

window.montarConversor = function (raiz, o) {
  raiz.innerHTML = `
    <div class="cv">
      <p class="hint">Cole a fórmula do Tributos desktop. O conversor traduz o SQL para BFC-Script e lista cada código de grupo, item, base, tabela e indexador para você ligar ao nome no Cloud, onde as opções são nominais por campo adicional. O mapeamento fica salvo para a entidade e vale para as próximas fórmulas.</p>
      <label class="f">Fórmula do desktop
        <textarea id="cv-fonte" rows="10" spellcheck="false" placeholder="DECLARE ... SET ... IF ... THEN ... END IF;"></textarea>
      </label>
      <div class="acts"><label class="btn ghost small">Abrir arquivo .txt<input type="file" id="cv-arquivo" accept=".txt,.sql" hidden></label></div>
      <div class="two">
        <label class="f">Crédito tributário<input id="cv-credito" list="cv-dl-cred" placeholder="ex.: ALVAR"></label>
        <label class="f">Cadastro
          <select id="cv-cad">${Object.entries(NOMES_CAD).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select>
        </label>
      </div>
      <datalist id="cv-dl-cred"></datalist>
      <div class="two">
        <label class="f">Exercício<input id="cv-ano" inputmode="numeric" value="${new Date().getFullYear()}"></label>
        <label class="f">Seu nome (histórico)<input id="cv-autor"></label>
      </div>
      <div class="status" id="cv-status" role="status"></div>
      <div id="cv-mapa-wrap" hidden>
        <h2>Mapeamento desktop → Cloud</h2>
        <p class="hint">Em amarelo, o que ainda falta ou não existe na entidade. As sugestões vêm dos dados lidos do Cloud.</p>
        <div class="rows"><table class="cv-mapa"><thead><tr><th>No desktop</th><th>No Cloud</th></tr></thead><tbody id="cv-mapa"></tbody></table></div>
        <div id="cv-dls"></div>
      </div>
      <div class="msgs" id="cv-msgs"></div>
      <div class="acts">
        <button type="button" class="btn small" id="cv-copiar">Copiar código</button>
        ${o.inserir ? '<button type="button" class="btn ghost small" id="cv-inserir">Inserir no editor</button>' : ""}
        <button type="button" class="btn ghost small" id="cv-revisar">Revisar com IA</button>
      </div>
      <div class="status" id="cv-status2" role="status"></div>
      <pre class="code" id="cv-code"></pre>
    </div>`;
  const $ = s => raiz.querySelector(s);
  let ultimo = null, timer = null;

  function creditos() { const d = o.getDados(); return d ? d.creditos || [] : []; }
  function creditoSel() { const v = $("#cv-credito").value.trim(); return creditos().find(c => c.abreviatura === v) || null; }
  function status(id, t, erro) { const el = $(id); el.textContent = t || ""; el.classList.toggle("erro", !!erro); }

  function mapaEfetivo() {
    const salvo = o.getMapa() || {};
    const semente = (window.CONVERSOR.SEMENTES || {})[o.getChave() || ""] || {};
    return Object.assign({}, semente, salvo);
  }
  function opcoesPara(r, mapa) {
    const d = o.getDados(); if (!d) return null;
    const [tipo] = r.chave.split(":");
    if (r.tipo === "indexador") return d.indexadores.map(i => [i.sigla, i.nome]);
    if (r.tipo === "tabela") { const m = new Map(); (d.tabelas || []).forEach(t => { if (!m.has(String(t.codigo))) m.set(String(t.codigo), t.descricao + " · " + (t.origem || "")); }); return [...m]; }
    if (r.tipo === "receita") { const c = creditoSel(); const todas = new Map(); (c ? [c] : creditos()).forEach(x => (x.receitas || []).forEach(rc => todas.set(rc.abreviatura, (rc.codigo ? rc.codigo + " · " : "") + (rc.descricao || "")))); return [...todas]; }
    if (r.tipo === "campo") {
      const cad = tipo === "base" ? ({ IMOVEIS: "IMOVEIS", ECONOMICOS: "ECONOMICOS", PROJETOS: "PROJETOS_DE_OBRAS" }[$("#cv-cad").value] || "RECEITAS_DIVERSAS") : CAD_CAMPO[tipo];
      const lista = d.campos.filter(c => c.tipo !== "ITEM_SELECAO" && (!cad || c.cadastro === cad || (cad === "RECEITAS_DIVERSAS" && /RECEIT/i.test(c.cadastro || ""))));
      return (lista.length ? lista : d.campos.filter(c => c.tipo !== "ITEM_SELECAO")).map(c => [c.titulo, (c.tipo || "").toLowerCase().replace("_", " ") + " · " + (c.cadastro || "")]);
    }
    if (r.tipo === "opcao") {
      const nomeCampo = mapa[r.sugestao]; const c = d.campos.find(x => x.titulo === nomeCampo);
      return c ? (c.opcoes || []).map(x => [x, ""]) : [];
    }
    return null;
  }

  function rodar() {
    const fonte = $("#cv-fonte").value;
    if (!fonte.trim()) { $("#cv-mapa-wrap").hidden = true; $("#cv-code").textContent = ""; $("#cv-msgs").innerHTML = ""; status("#cv-status", "Cole ou abra uma fórmula do desktop."); ultimo = null; return; }
    const c = creditoSel(), mapa = mapaEfetivo();
    ultimo = window.CONVERSOR.converter(fonte, {
      cadastro: $("#cv-cad").value,
      credito: c ? { abreviatura: c.abreviatura, descricao: c.descricao, receitas: c.receitas || [] } : { abreviatura: $("#cv-credito").value.trim() || null, receitas: [] },
      mapa, ano: $("#cv-ano").value.trim(), autor: $("#cv-autor").value.trim()
    });
    // tabela de mapeamento (mantém o foco do campo que está sendo editado)
    const foco = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.chave : null;
    const linhas = [], dls = [];
    let faltam = 0;
    ultimo.refs.forEach((r, i) => {
      const v = mapa[r.chave] || "", ops = opcoesPara(r, mapa), dl = "cv-dl-" + i;
      const fora = !!(v && ops && ops.length && !ops.some(x => x[0] === v));
      if (!v || fora) faltam++;
      dls.push(`<datalist id="${dl}">${(ops || []).map(x => `<option value="${esc(x[0])}">${esc(x[1])}</option>`).join("")}</datalist>`);
      const ph = r.tipo === "opcao" ? (mapa[r.sugestao] ? "opção de " + mapa[r.sugestao] : "escolha antes o campo do grupo") : r.tipo === "indexador" ? "sigla, ex.: URM" : r.tipo === "tabela" ? "código da tabela de cálculo" : r.tipo === "beneficio" ? "descrição do benefício fiscal" : "nome exato no Cloud";
      linhas.push(`<tr><td>${esc(r.rotulo)}<br><small>${esc(r.chave)}</small></td><td><input data-chave="${esc(r.chave)}" list="${dl}" value="${esc(v)}" placeholder="${esc(ph)}" class="${!v || fora ? "nao-achado" : ""}" aria-label="${esc(r.rotulo)}"></td></tr>`);
    });
    $("#cv-mapa").innerHTML = linhas.join(""); $("#cv-dls").innerHTML = dls.join("");
    $("#cv-mapa-wrap").hidden = !ultimo.refs.length;
    if (foco) { const el = raiz.querySelector(`[data-chave="${CSS.escape(foco)}"]`); if (el) { el.focus(); const n = el.value.length; try { el.setSelectionRange(n, n); } catch (e) {} } }
    const d = o.getDados();
    status("#cv-status", `${ultimo.tipoFormula === "acrescimos" ? "Fórmula de juro/multa (vai para Acréscimos). " : ""}${ultimo.refs.length} códigos do desktop · ${faltam ? faltam + " sem nome no Cloud" : "todos ligados"} · ${ultimo.pendencias.length} pendências.${d ? "" : " Sem dados da entidade: as sugestões aparecem depois de carregar os dados."}`);
    $("#cv-msgs").innerHTML = ultimo.pendencias.map(x => `<div class="msg warn">${esc(x)}</div>`).join("") + ultimo.notas.map(x => `<div class="msg">${esc(x)}</div>`).join("");
    $("#cv-code").innerHTML = o.hl(ultimo.codigo);
  }
  const agenda = () => { clearTimeout(timer); timer = setTimeout(rodar, 250); };

  function prepararCreditos() {
    $("#cv-dl-cred").innerHTML = creditos().map(c => `<option value="${esc(c.abreviatura)}">${esc(c.descricao || "")} · ${esc(c.tipoCadastro || "")}</option>`).join("");
  }
  $("#cv-fonte").addEventListener("input", agenda);
  ["#cv-ano", "#cv-autor"].forEach(s => $(s).addEventListener("input", agenda));
  $("#cv-cad").addEventListener("change", rodar);
  $("#cv-credito").addEventListener("input", () => {
    const c = creditoSel();
    if (c && ({ IMOVEIS: 1, ECONOMICOS: 1, RECEITAS_DIVERSAS: 1, PROJETOS: 1 })[c.tipoCadastro]) $("#cv-cad").value = c.tipoCadastro;
    agenda();
  });
  $("#cv-arquivo").addEventListener("change", async e => {
    const f = e.target.files[0]; if (!f) return;
    let t = await f.text();
    if (t.includes("\uFFFD")) { try { t = new TextDecoder("windows-1252").decode(await f.arrayBuffer()); } catch (x) {} }
    $("#cv-fonte").value = t;
    const m = f.name.match(/^\d+_(.+?)_(lancamento|juro|multa)/i);
    if (m && !$("#cv-credito").value) { $("#cv-credito").value = m[1]; $("#cv-credito").dispatchEvent(new Event("input")); }
    rodar(); e.target.value = "";
  });
  $("#cv-mapa").addEventListener("change", e => {
    const ch = e.target.dataset.chave; if (!ch) return;
    const m = Object.assign({}, o.getMapa() || {}); const v = e.target.value.trim();
    if (v) m[ch] = v; else delete m[ch];
    o.setMapa(m); rodar();
  });
  $("#cv-copiar").addEventListener("click", async () => { if (!ultimo) return; try { await o.copiar(ultimo.codigo); status("#cv-status2", "Código copiado."); } catch (e) { status("#cv-status2", "Não foi possível copiar: " + e.message, true); } });
  if (o.inserir) $("#cv-inserir").addEventListener("click", async () => {
    if (!ultimo) return;
    try { const r = await o.inserir(ultimo.codigo); status("#cv-status2", r && r.ok ? "Código inserido no editor. Revise as pendências e salve no Cloud." : (r && r.motivo) + " Use Copiar código.", !(r && r.ok)); }
    catch (e) { status("#cv-status2", "Não foi possível inserir: " + e.message, true); }
  });
  $("#cv-revisar").addEventListener("click", () => {
    if (!ultimo) return;
    o.revisar({ codigo: ultimo.codigo, original: $("#cv-fonte").value, pendencias: ultimo.pendencias, notas: ultimo.notas, cadastro: NOMES_CAD[$("#cv-cad").value], tipo: ultimo.tipoFormula === "acrescimos" ? "Acréscimos" : "Cálculo" }, s => status("#cv-status2", s));
  });
  prepararCreditos(); rodar();
  return { atualizar() { prepararCreditos(); rodar(); } };
};
})();
