---
name: formulas-tributos-cloud
description: Cria, revisa e reescreve fórmulas (BFC-Script) do Betha Tributos Cloud — cálculo de IPTU, ISS, alvará, taxas e receitas diversas, desconto de parcelamento/REFIS, convênio bancário (código de barras), acréscimos, dívida ativa, ITBI e os demais tipos da tela Configurando > Fórmulas. Use sempre que o usuário colar ou mencionar uma fórmula do Tributos Cloud, pedir para corrigir um cálculo que está saindo errado, atualizar valores de lei/decreto para um novo exercício, converter regra do desktop (Integra) para o Cloud, ou padronizar/documentar fórmulas — mesmo que não diga "BFC-Script" nem "fórmula".
---

# Fórmulas do Tributos Cloud

Esta skill gera código de fórmula para o usuário **colar no editor do Cloud**. Ela não grava nada no
sistema. O trabalho é: entender a regra, achar o que está errado ou frágil, reescrever no padrão da
casa e entregar o código completo, com o que mudou e como conferir.

Três princípios guiam tudo, porque cada um evita um tipo de prejuízo real:

1. **Não invente variável nem função.** Cada tipo de fórmula tem um catálogo próprio de variáveis e
   classes. Um nome que não existe só aparece como erro no editor (no melhor caso) ou como cálculo
   errado em todos os lançamentos (no pior). Use o catálogo da seção 6; se o tipo não estiver lá,
   leia o catálogo no Cloud (seção 7) ou peça ao usuário a aba **Variáveis** do editor.
2. **Reescrever não é mudar a regra.** Padronizar preserva o resultado do cálculo. Toda mudança de
   comportamento (corrigir bug, mudar faixa, novo valor de decreto) é listada à parte e explicada.
3. **Número de lei fica em PARÂMETROS.** Alíquotas, percentuais, valores em URM, faixas e datas de
   corte ficam todos no topo, com o artigo da lei ao lado. Quem atualiza no ano seguinte não deve
   precisar ler o cálculo.

## 1. Fluxo de trabalho

1. **Contexto.** Descubra (do que foi colado ou perguntando, no máximo uma pergunta por vez):
   tipo da fórmula (tela), crédito tributário e tipo de cadastro (IMOVEIS, ECONOMICOS, receita
   diversa), exercício, base legal. Se o usuário colou só o código, deduza o tipo pelo `retornar`
   e pelas variáveis usadas (seção 5).
2. **Diagnóstico.** Leia a fórmula inteira antes de mexer. Classifique cada achado:
   - **Erro** — calcula errado ou pode derrubar o cálculo (nulo, condição impossível, variável
     inexistente, faixa com buraco ou sobreposição, arredondamento no lugar errado).
   - **Risco** — funciona hoje, mas quebra com dado diferente (campo adicional vazio, tabela sem
     valor, indexador não cadastrado no ano).
   - **Manutenção** — número mágico, nome obscuro, `se` aninhado longo, código morto, comentário
     que mente.
   - **Dúvida de regra** — o código faz algo que a lei talvez não diga. Não corrija sozinho:
     pergunte e deixe o comportamento atual até a resposta.
3. **Reescrita** no padrão (seção 2), usando só o catálogo do tipo.
4. **Revisão** com o checklist (seção 8). Releia o código final como se fosse colá-lo agora.
5. **Entrega** no formato da seção 9.

Se o usuário pedir uma fórmula nova a partir de uma lei, faça o mesmo fluxo: extraia da lei as
faixas, alíquotas e exceções numa tabela, confirme a tabela com ele e só então escreva o código.

## 2. Padrão da casa

Quatro blocos fixos, sempre nesta ordem. Todo bloco aparece, mesmo que curto, para que qualquer
fórmula seja lida do mesmo jeito.

```
// ============================================================
// <NOME DA FÓRMULA EM MAIÚSCULAS>
// Tipo      : <tipo da tela> | Crédito: <abreviatura> | Exercício: <ano>
// O que faz : <uma ou duas linhas, em linguagem de negócio>
// Base legal: <Lei/Decreto nº ____/____, art. __>
// Histórico : <dd/mm/aaaa> - <nome> - <o que mudou e por quê>
//             (manter as 5 últimas; a mais recente primeiro)
// ============================================================

// ---------- PARÂMETROS (altere somente aqui) ----------
// valores definidos em lei/decreto; um por linha, com o artigo ao lado

// ---------- ENTRADAS E VALIDAÇÕES ----------
// leitura de campos adicionais, tabelas e indexadores; suspender se faltar dado obrigatório

// ---------- CÁLCULO ----------
// a regra, passo a passo, com comentário do "porquê" (não do "o quê")

// ---------- RESULTADO ----------
// arredondamento final e retornar / lancamento.criarReceita
```

Convenções:

- **Nomes** em português, camelCase, sem acento: `percDescontoJuros`, `vlTerreno`, `qtdParcelas`,
  `dtCorte`, `ehConstruido`, `temColetaLixo`. Prefixos: `perc` (percentual em fração: 0.95 = 95%),
  `vl` (valor em R$), `qtd`, `dt`, `eh`/`tem` (booleanos), `fator`, `aliq`. Não reuse nomes das
  variáveis do sistema (`ano`, `imovel`, `lancamento`, `guia`...) para outra coisa.
- **Percentual** sempre como fração e com o significado no comentário (`0.95 // 95% de desconto`).
- **Ponto e vírgula** no fim de cada instrução, chaves sempre, mesmo em `se` de uma linha.
- **Identificação nas mensagens**: monte no início `ident = "Imovel " + imovel.codigo + " (" + ano + "): ";`
  (ou o equivalente para econômico/contribuinte) e use em todo `suspender`, para o erro dizer
  qual cadastro falhou.
- **Dado obrigatório ausente → `suspender` com mensagem clara**, juntando todos os faltantes numa
  só mensagem. Não zere em silêncio: um zero silencioso vira lançamento errado, enquanto uma
  suspensão vira uma correção de cadastro.
- **Arredonde só no fim**, em 2 casas (`Numeros.arredonda(x, 2)`), no bloco RESULTADO.
- **Comentários** explicam o porquê e citam o artigo; o que o código faz já está no código. Código
  comentado ("dados para teste") sai da versão final ou vai para um bloco marcado no fim.
- **Faixas e enquadramentos**: em vez de 10 `se/senao` aninhados, use uma tabela de parâmetros e
  um `percorrer` (seção 4.4). Para até 3 casos, `se/senao` aninhado é mais legível.

## 3. Exemplo de referência (aprovado pelo usuário)

Desconto para parcelamento, reescrito sem mudar a regra:

```
// ============================================================
// DESCONTO DE PARCELAMENTO
// Tipo      : Desconto para parcelamentos | Crédito: todos | Exercício: 2026
// O que faz : desconto sobre juros e multa conforme o nº de parcelas
// Base legal: Lei nº ____/____, art. __
// Histórico : 05/11/2026 - <nome> - padronização, sem mudança de regra
// ============================================================

// ---------- PARÂMETROS (altere somente aqui) ----------
percDescontoAVista    = 1.00;  // parcela única: 100% de juros e multa
percDescontoParcelado = 0.95;  // 2 ou mais parcelas: 95% de juros e multa

// ---------- ENTRADAS E VALIDAÇÕES ----------
// sem validações: as variáveis vêm sempre preenchidas pelo sistema

// ---------- CÁLCULO ----------
descontoTributo  = 0.00;  // sem desconto sobre o principal
descontoCorrecao = 0.00;  // sem desconto sobre a correção
descontoMulta    = 0.00;
descontoJuros    = 0.00;

se (qtdParcelas == 1) {
  // pagamento à vista
  descontoJuros = vlTotalJuros * percDescontoAVista;
  descontoMulta = vlTotalMulta * percDescontoAVista;
} senao {
  se (qtdParcelas > 1) {
    // parcelado; qtdParcelas <= 0 não recebe desconto
    descontoJuros = vlTotalJuros * percDescontoParcelado;
    descontoMulta = vlTotalMulta * percDescontoParcelado;
  }
}

// ---------- RESULTADO ----------
retornar TRIBUTO: descontoTributo, CORRECAO: descontoCorrecao, MULTA: descontoMulta, JUROS: descontoJuros;
```

## 4. A linguagem (BFC-Script) no contexto das fórmulas

### 4.1 Sintaxe básica
- Atribuição sem declaração: `x = 10;`. Todas as variáveis são do script inteiro (inclusive as
  criadas dentro de `se` e `percorrer`).
- Números decimais com ponto: `0.005`. Texto com aspas duplas ou simples; concatenação com `+`.
- Comentários: `//` e `/* ... */`.
- Comparação `== != < <= > >=`; lógicos `&& || !`.
- Condicional: `se (cond) { ... } senao { ... }`. **Não existe `senao se`** documentado: aninhe
  `se` dentro do `senao`.
- Propriedades sem parâmetro podem ser lidas sem parênteses (`imovel.codigo`,
  `economico.porteDaEmpresa`); funções com parâmetro usam parênteses (`Datas.ano(dt)`).
- `retornar CHAVE: valor, CHAVE2: valor;` devolve um mapa ao sistema (nomes exatos da seção 5).
- `imprimir x;` escreve no console (aba Logs) — use para depurar e retire da versão final.

### 4.2 Nulos
- `nulo` é a ausência de valor. Ler propriedade de algo nulo derruba a execução.
- Navegação segura: `imovel.inscricaoImobiliaria?.campo2` (repita `?.` em cada nível que pode ser nulo).
- Valor padrão: `x = CamposAdicionais.valor(imovel, "Área do Terreno", ano) ?: 0;`
- `valorOpcao` pode vir nulo: use `(CamposAdicionais.valorOpcao(...) ?: false)`.
- Teste explícito para dado obrigatório: `se (urm == nulo || urm == 0) { suspender(...) }`.

### 4.3 Interromper
- `suspender("mensagem")` aborta a fórmula para aquele cadastro e mostra a mensagem. Não é
  capturado por `tentar/tratar`.
- `Utilitarios.emitirErro(msg)` (fórmula de cálculo) registra erro no cálculo; não está documentado
  se interrompe. Prefira `suspender` quando o cálculo não deve seguir.

### 4.4 Laços e tabelas de parâmetros
- `percorrer(lista) { ... }` com `item` e `indice` implícitos; renomeie com `{ faixa -> ... }`.
  `percorrer(de: 1, ate: n) { ... }` conta a partir de 1; `lista[0]` conta a partir de 0.
- Lista literal `[1, 2, 3]`, mapa literal `[chave: valor]`, acrescentar com `lista << x`.
- Padrão para enquadramento por opção de campo adicional (substitui o `se` aninhado longo):

```
// ---------- PARÂMETROS ----------
// [opção do campo "TX LICENÇA/FISCALIZAÇÃO", fator em URM]  (Lei __, anexo __)
enquadramentos = [
  ["101", 0.9],
  ["102", 1.5],
  ["103", 3.0]
];

// ---------- CÁLCULO ----------
fatorUrm = 0;
percorrer(enquadramentos) { faixa ->
  se (fatorUrm == 0 && (CamposAdicionais.valorOpcao(economico, "TX LICENÇA/FISCALIZAÇÃO", faixa[0], ano) ?: false)) {
    fatorUrm = faixa[1];
  }
}
se (fatorUrm == 0) {
  suspender(ident + "enquadramento da taxa de licença não informado.");
}
```

- Padrão para faixas numéricas (até X, alíquota Y), com limites em ordem crescente e a última
  faixa aberta:

```
// [limite superior da faixa em R$ (nulo = sem limite), alíquota]  (Lei __, art. __)
faixas = [
  [50000.00,  0.005],
  [150000.00, 0.008],
  [nulo,      0.010]
];
aliquota = nulo;
percorrer(faixas) { faixa ->
  se (aliquota == nulo && (faixa[0] == nulo || vlVenal <= faixa[0])) {
    aliquota = faixa[1];
  }
}
```

Variável atribuída dentro do `percorrer` vale fora dele, mas confirme no console na primeira vez
que usar o padrão numa entidade; se der erro, volte ao `se/senao` aninhado.

### 4.5 Datas e números
- `Datas.data(2026, 4, 1)` — sem zero à esquerda (`04` não compila).
- `Datas.hoje()`, `Datas.diferencaDias(menor, maior)`, `Datas.diferencaMeses(...)`,
  `Datas.adicionaDias(d, n)`, `Datas.adicionaMeses(d, n)`, `Datas.ano/mes/dia(d)`.
- `Numeros.arredonda(v, 2)`, `Numeros.trunca(v, 2)`, `Numeros.teto(v)`, `Numeros.piso(v)`,
  `Numeros.maximo(a, b)`, `Numeros.minimo(a, b)`, `Numeros.numero(texto)`, `Numeros.ehNumero(texto)`.

## 5. Tipos de fórmula e o que cada um devolve

Na tela Configurando > Fórmulas há 11 tipos. Cada fórmula é um registro `scriptArrecadacao` com
um `tipoScript`.

| Tela | tipoScript | Como devolve o resultado |
|---|---|---|
| Cálculo | `GERACAO_CREDITO` | Sem `retornar`: cria receitas com `lancamento.criarReceita("ABREV", valor)` |
| Desconto para parcelamentos | `DESCONTO_PARCELAMENTO` | `retornar TRIBUTO:, CORRECAO:, MULTA:, JUROS:` — **valores do desconto em R$**, não percentuais |
| Convênio bancário | `CONVENIO_BANCARIO` | `retornar codigoBarras:, representacaoNumerica:, nossoNumero:` |
| Acréscimos | `ACRESCIMO` | correção, juros e multa da parcela vencida (confirmar os nomes no catálogo) |
| Dívida ativa | `DIVIDA_ATIVA` | confirmar no catálogo |
| Impostos federais | `IMPOSTOS_FEDERAIS` | confirmar no catálogo |
| ITBI | `ITBI` | valor venal (terreno, construção, benfeitorias) e transferência de créditos; confirmar |
| Redução da base de cálculo do ISSQN | `REDUCAO_BASE_CALC_ISSQN` | registro único por entidade; confirmar |
| Desconto para guia unificada | confirmar | confirmar no catálogo |
| Manutenção de dívida ativa | confirmar | confirmar no catálogo |
| Requerimento da manutenção de cálculo | confirmar | confirmar no catálogo |

Também existem `VALIDACAO_CADASTRAL` e `BENEFICIO_FISCAL` no sistema.

Para as linhas marcadas "confirmar": antes de escrever, obtenha o catálogo daquele tipo (seção 7)
ou uma fórmula existente do mesmo tipo. Não deduza o contrato de retorno por analogia.

Observações de negócio (ajuda Betha):
- Desconto para parcelamento só vale se a configuração correspondente do parcelamento estiver ativa.
- Parcela do tipo integral (cota única) nunca é inscrita em dívida ativa.
- Fórmula de cálculo errada afeta todos os lançamentos do período: valide a regra com o município.

## 6. Catálogo de variáveis e classes (lido do Cloud, entidade 804, nov/2026)

As variáveis da fórmula de **cálculo** mudam com o tipo de cadastro do crédito. Confira a qual
grupo a fórmula pertence antes de usar uma variável.

### 6.1 Classes comuns (todos os tipos)
- **Datas**: adicionaDias, adicionaMeses, adicionaHoras/Minutos/Segundos, ano, mes, dia, hora,
  minuto, segundo, data(ano, mes, dia), dataHora(ano, mes, dia, hora, min), diaSemana (domingo = 1),
  diferencaAnos/Meses/Dias/Horas/Minutos/Segundos(menor, maior), ehData, extenso, hoje,
  nomeDiaSemana, nomeMes, periodo(ini, fim), removeDias, removeMeses, formatar(data, formato).
- **Numeros**: absoluto, arredonda(v, casas), trunca(v, casas), teto, piso, maximo, minimo,
  numero(texto), ehNumero, potencia, raiz, resto(dividendo, divisor), seZero(v1, v2, ...),
  exponencial, logaritmo, logaritmo10, fatorial, randomico, seno, coseno, tangente, pi.
- **Caracteres**: capitaliza, direita(t, n), esquerda(t, n), subTexto(t, inicio, tamanho),
  tamanho, vazio, maiusculo, minusculo, posicao(t, expr[, ini]), substituir(t, de, para),
  removeEspacos(/Direita/Esquerda), repetir, sobrepor, equivalente, expressao, dividir.

### 6.2 Cálculo — comum a todos os cadastros
Variáveis: `ano` (exercício da fórmula), `lancamento`, `creditoTributario`, `dataLancamento`,
`usuario`, `tabelasCalculos`, `complementar` (cálculo complementar), e em imóveis/econômicos
`formaPagamento` e `quantidadeParcelas`.
- `lancamento.criarReceita(abrev, valor)`, `criarReceita(abrev, valor, beneficio)`,
  `criarReceita(abrev, valor, beneficio, percConcessao)`; `recuperarReceitaLancada(abrev)`;
  `indexador(ind)`; `comAFormaDePagamentoParcelada(cod)`, `comAFormaDePagamentoIntegral(cod)`;
  `calcularDescontoSobreValorLancadoSemBeneficio()`; ISS: `paraOsServicos(opcao)`,
  `paraOServico(atividade)`, `competenciasEntre(ini, fim)`, `competenciasAPartirDe(ini)`,
  `competenciasDoAno(ano)`; imóveis: `valorLancadoEnglobadosReceita(imovel.codigo, abrev)`.
- `tabelasCalculos.getValor(ano, codTabela, imovel.codigo)`, `getValorAgrupamento(ano, cod, imovel.codigo, agrup)`,
  `getIndexador(ano, cod, imovel.codigo)`, `dadosDaTabelaAplicado(ano, cod, imovel.codigo)`,
  `getValorAplicado(conjunto)`, `getIndexadorAplicado(conjunto)`.
- `creditoTributario`: codigo, abreviatura, descricao, tipoCadastro, indexador, creditosTributariosRec, calculaImoveisRurais.
- **CamposAdicionais**: `valor(ref, nome, ano)`, `valor(ref, nome, ano, agrup)`,
  `valor(ref, nome)` (valor **gerado neste cálculo**), `valorOpcao(ref, nome, opcao, ano[, agrup])`,
  `preencherCampoAdicional(ref, nome, valor, ano)`, `preencherCampoAdicionalAgrupamento(...)`,
  `lotePossuiCampoAdicionalInformado(imovel, nome, opcao, ano)`.
- **Utilitarios**: `buscaValorDoIndexadorPorSiglaNumaDataEspecifica(sigla, data)`,
  `buscaMovimentacoesDoIndexadorPorSiglaEmUmPeriodo(sigla, ini, fim)`, `buscaIndexadorPorNomeESigla`,
  `ehMoedaCorrente(sigla)`, `ehFeriado(data)`, `proximoDiaUtil(data)`, `buscaBeneficioFiscal(descricao)`,
  `existeLancamento(ref, data)`, `emitirErro(msg)`,
  `valorGeradoLancadoPorCreditoTributarioParaReferente(codCredito, codRef, listaAbrev, ano, consideraComplementar)`.
- **TabelasAuxiliares**: `buscarRegistrosDaTabela(cod)`, `buscarRegistroDaTabelaPorCampo(cod, nCampo, valor)`,
  `valorDoCampoPorDescricao(registro, descricaoCampo)`.
- **Agrupamentos**: `buscaAgrupamento(ref, nome)`, `buscaAgrupamentoParcelamento(ref, nome)`,
  `buscaCamposAdicionaisDoAgrupamento(agrup)`.
- **ConfiguracoesParcelas** (imóveis) / **ConfiguracoesParcela** (econômicos):
  `buscaConfiguracaoPorAbreviaturaEAno(abrev, ano)`.

### 6.3 Cálculo — crédito de IMÓVEIS (ex.: IPTU)
`imovel`: codigo, unidade, situacao (ATIVADO/DESATIVADO), tipoImovel (RURAL/URBANO), contribuinte,
inscricaoImobiliaria (campo1, campo2...), setor, quadra, lote, logradouro, bairro, secao, face,
localidade, loteamento, condominio, agrupamento, testadas, nroTestadas, maiorTestada, matricula,
inscricaoAnterior, inscricaoIncra, denominacao, nroImovel, complemento, apartamento, bloco, cep,
latitude, longitude, dataConstrucao. Também `lancamentosEnglobados` (lista).
- **Imoveis**: `getEhEnglobado(imovel)`, `buscarImoveisDoContribuinte(contribuinte.codigo)`, `buscarImovelPeloCodigo(cod)`.
- **UtilitariosImoveis**: `buscaPlantaDeValoresDoImovel(ano, imovel.codigo)`, `buscaPlantaDeValoresDoImovelAno(imovel.codigo)`,
  `buscaPlantaDeValores(ano, logradouro, secao, face)`, `buscaSecaoDoImovel(imovel, ano)`,
  `buscaSecao(logradouro, secao, face, ano)`, `testadasAtivasNoAno(imovel.codigo, ano)`,
  `imoveisDoMesmoLote(imovel.codigo, ano)`, `englobados(imovel.codigo)`, `ehEnglobado(imovel.codigo)`,
  `buscaImovelPrincipalDoEnglobamento(imovel.codigo)`, `existeITBI(imovel.codigo)`,
  `existeContribuicaoDeMelhorias(imovel.codigo)`.

### 6.4 Cálculo — crédito de ECONÔMICOS (ex.: ISS, alvará)
Extras: `dataBase`, `opcoesListaServico` (MAIOR_ALIQUOTA, MENOR_ALIQUOTA, TODOS),
`configuracaoTaxaExpediente.valorTaxaExpediente`.
`economico`: codigo, contribuinte, situacao / situacaoAtual (ATIVADO, INICIO, REINICIO...),
porteDaEmpresa, regimeCobrancaIss, dataInicioOuReinicio, dataBase, cnaePrincipal, cnaesSecundarias,
quantidadeCnaesSecundarias, cnaes, servicoPrincipal, listaServicosSecundarios,
quantidadeServicosSecundarios, servicos, economicoPrincipal, agrupamento, logradouro, loteamento,
condominio, complemento, apartamento, bloco, cep.
- **UtilitariosEconomicos** (o parâmetro aparece como `economico.codEconomico` na ajuda; o catálogo
  expõe `economico.codigo` — confira no console): `buscaEconomicoPeloCodigo(cod)`,
  `buscaEconomicoPeloCodigoEDataBase(cod, data)`, `buscaSituacaoDoEconomicoEmUmaData(cod, data)`,
  `buscaEconomicosPeloContribuinte(contrib)`, `buscaUltimaMovimentacao(cod)`,
  `buscaUltimaMovimentacaoPorTipo(cod, tipo)`, `buscaMovimentacoes(cod)`,
  `buscaValoresListaServicos(cod, data)`, `buscaValoresISSListaServicos(cod, data)`,
  `buscaServicoComMaiorAliquota(cod, data)`, `buscaServicoComMenorAliquota(cod, data)`.
- **Atividades**: `buscaValorAlvara(atividade, dataBase)`, `somaValorAlvara(economico, dataBase)`,
  `buscaMaiorValorAlvara(codAtiv, dataBase)`, `buscaMenorValorAlvara(codAtiv, dataBase)`,
  `buscaAtividadeEconomica(cnae)`, `buscaMovimentacaoPorData(ativ, data)`, `buscaMovimentacoes(ativ)`.

### 6.5 Cálculo — RECEITAS DIVERSAS
Variáveis: `ano`, `imovel`, `economico`, `receitaDiversa`, `configuracaoLancamento`, `lancamento`,
`creditoTributario`, `dataLancamento`, `usuario`, `tabelasCalculos`, `complementar`.
- `receitaDiversa`: codigo, contribuinte, tipoDeServico, descricaoServico, nroProcesso, data, camposAdicionais.
- `configuracaoLancamento`: receitas (lista de receitas e valores informados), totalLancado,
  qtdParcelas, dataVencimento, intervaloVenctos, qtdDiasMeses, observacao, dataCriacao, codigo,
  `alterarVencimento(data)`.
- **UtilitariosReceitasDiversas**: `receitasDiversasContribuinte(contribuinte.codigo, ano[, possuiLancamento])`, `buscaImovel(cod)`.

### 6.6 Desconto para parcelamentos
Totais (Numeros): `qtdParcelas`, `vlTotalDevido`, `vlTotalLancado`, `vlTotalJuros`, `vlTotalMulta`,
`vlTotalCorrecao` (da dívida/lançamento) e `vlTotalLancadoParcelar`, `vlTotalJurosParcelar`,
`vlTotalMultaParcelar`, `vlTotalCorrecaoParcelar` (do que está sendo parcelado);
`dtVctoPrimeiraParcela`; `ehLancamentoInscrito`; `tipoDesconto` (JUROS, MULTA, CORRECAO, TRIBUTO).
Objetos: `configuracaoParcelamento` (descricao, ato, qtdMaxParcelas, exigirEntrada, percEntrada,
cobrarJuros, dtValidadeInicial/Final, dtVencimentoInicial/Final, vlMinimoFisica/Juridica, tipoLancamento...),
`creditoTributario`, `contribuinte` (codigo, nome, cpfCnpj, optanteDoSimples, porteEmpresa,
camposAdicionais, situacao), `divida` (anoDivida, dataVencimentoDivida, dataInscricao, valorInscrito,
valorSaldo, valorJuros, valorMulta, valorCorrecao, situacao, status, imovel, economico, dividasReceitas...),
`dividaReceita`, `guia` (vencimento, nroParcela, cotaUnica, valorLancado, valorDoJuro, valorDaMulta,
valorDaCorrecao, receitasDaGuia...), `guiaReceita`, `parcelamentoAnterior` (quantidadeDeParcelas,
situacao, valorDaEntrada, parcelas, contribuinte...).
Classes extras: `CamposAdicionais` (valor/valorOpcao), `dadosContribuinte.buscarPorCodigo(cod)`,
`lancamentos.getPossuiGuiasVencidas(imovel, data)` / `getPossuiGuiasAVencer(imovel, data)` / `getPossuiGuias(imovel)`,
`situacaoFinanceira` (quantidadeParcelasVencidasPor..., qtdDividasAtivasVencidasPor...).

### 6.7 Convênio bancário
Variáveis: `valorDoDocumento`, `dataDeVencimento`, `numeroDeBaixa`, `nroDaparcela`, `contaUnica`
(cota única), `Convenio` (cedente, dvCedente, carteira, contaBancaria, dvContaBancaria,
numeroBanco, nomeBanco, numeroAgencia, codigoAgencia, digitoVerificadorAgencia, mensagens, creditos),
`TipoRetorno`.
**Utilitarios** (versão do convênio): `completarAEsquerda(dig, char, qtd)`, `completarADireita(...)`,
`somenteNumeros(dig)`, `somatorioModulo10(dig)`, `somatorioModulo11(dig, base)`, `fatorVencimento(data)`.

## 7. Ler fórmulas e catálogos direto do Cloud (somente leitura)

Quando houver navegador com o usuário logado no Tributos Cloud (ou ele puder colar no console do
DevTools), estas leituras dispensam pedir cópia manual. **Nunca chame `save`, `PUT`, `POST` ou
`DELETE`**: gravar é sempre o usuário, pelo editor, depois de revisar.

API: `https://tributos.betha.cloud/tributos/v1/api/arrecadacao/`
- `GET scriptArrecadacao?limit=100&offset=0` — lista as fórmulas (paginado: `content`, `hasNext`).
  Campos úteis: `id`, `tipoScript`, `ano`, `disponivel`, `creditoTributario.abreviatura`,
  `script.descricao`, `script.script` (o código), `atos` (lei vinculada), `usuario`, `ultimaAtualizacao`.
- `GET scriptArrecadacao/{id}` — uma fórmula.
- `OPTIONS scriptArrecadacao/{id}/script` — catálogo: `variables`, `classes` (com `methods[].info`:
  name, parameters, returnType, comment) e `scaffolds` (trechos-modelo).

Trecho para o console (usa a sessão da própria tela, sem copiar token):

```js
const inj = angular.element(document.body).injector();
const R = inj.get('Restangular'), base = inj.get('URL_BASE_API_ARRECADACAO');
const svc = inj.get('tributos.commons.ScriptsArrecadacaoService');
let todas = [], off = 0;
while (true) { const r = (await svc.getAll({limit: 100, offset: off})).plain();
  todas = todas.concat(r.content); if (!r.hasNext) break; off += 100; }
console.table(todas.map(f => ({id: f.id, tipo: f.tipoScript, ano: f.ano, descricao: f.script?.descricao})));
// catálogo de uma fórmula:
const id = todas[0].id;
const cat = (await R.allUrl('x', base + 'scriptArrecadacao/' + id + '/script').options()).plain();
const strip = s => (s || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
console.log([...cat.variables, ...cat.classes].map(x => '- ' + x.name + ': ' + strip(x.description) + '\n' +
  (x.methods || []).map(m => '    .' + m.info?.name + '(' + (m.info?.parameters || []).map(p => p.name).join(', ') + ')  ' + strip(m.info?.comment)).join('\n')).join('\n'));
```

Se o tipo pedido não tiver nenhuma fórmula cadastrada na entidade, o catálogo não pode ser lido por
`id`: peça ao usuário que crie a fórmula vazia pela tela (ou abra uma de outra entidade) e copie a
aba **Variáveis** do editor.

## 8. Armadilhas conhecidas e checklist de revisão

Armadilhas vistas em fórmulas reais:
- **`it` é palavra reservada** (closure do Groovy, que roda por baixo do BFC-Script): uma variável
  chamada `it` perde o valor atribuído dentro de `se { }` e zera o cálculo sem erro. Evite também
  `item` e `indice` fora de `percorrer`. Foi o que zerou o Imposto Territorial no IPTU de Barão.
- **"vlLancado: O valor lançado não pode ser nulo"**: alguma conta recebeu nulo. Proteja leituras de
  campo adicional e tabela (`?: 0`, ou `?: 1` em fator multiplicativo só quando a lei permitir o fator
  neutro) e arredonde antes do `criarReceita`.
- **Reler campo adicional gravado na mesma execução** pode voltar vazio: use a variável já calculada
  (ou `CamposAdicionais.valor(ref, nome)` sem ano, que lê o gerado neste cálculo).
- **`imovel.setor` vazio no cálculo** em algumas entidades: o setor pode estar num campo da
  `inscricaoImobiliaria` (ex.: `campo2`, texto → `Numeros.numero`). Confirme com `imprimir`.
- **Tabela de cálculo sem valor** para o imóvel: `getValor` devolve nulo. Junte os códigos faltantes
  e suspenda com uma mensagem só.
- **Indexador (URM/UFM) não cadastrado no exercício**: valide `nulo` e `0` e suspenda.
- **Códigos de enum não batem com a tela** (porte "MEI" × nome por extenso, S/N × SIM/NAO,
  letra × nome). Antes de comparar, confirme o valor real com `imprimir`.
- **Condição impossível** (mesma variável comparada com dois valores com `&&`), comum em exemplos
  copiados da ajuda: troque por `||` ou revise a intenção.
- **Data-sentinela do desktop** (`1900-01-01` = "sem data") ao converter regras do Integra: trate
  explicitamente.
- **Cópia de fórmula para o ano seguinte**: atualize cabeçalho, parâmetros do novo decreto e o
  histórico; confira o `ano` vinculado à fórmula.
- **Desconto devolvido como percentual**: a fórmula de desconto de parcelamento devolve o valor do
  desconto em R$ (`vlTotalJuros * 0.95`), não `0.95`.

Checklist antes de entregar:
- [ ] Toda variável e função usada existe no catálogo do tipo (e do tipo de cadastro).
- [ ] Os quatro blocos estão presentes, nesta ordem; nenhum número de lei fora de PARÂMETROS.
- [ ] Cabeçalho com tipo, crédito, exercício, base legal e histórico atualizado.
- [ ] Todo dado obrigatório é validado; todo `suspender` diz qual cadastro e o que falta.
- [ ] Nenhuma leitura que possa vir nula é usada em conta sem proteção.
- [ ] Faixas sem buraco nem sobreposição; limites (`<` × `<=`) conferidos com a lei.
- [ ] Arredondamento só no RESULTADO, em 2 casas.
- [ ] O `retornar` (ou os `criarReceita`) usa exatamente os nomes/abreviaturas esperados.
- [ ] Nenhum `imprimir` de depuração nem código de teste esquecido.
- [ ] Para reescrita: o resultado é o mesmo do original em todos os ramos, salvo as mudanças listadas.

## 9. Formato da entrega

Responda em português, nesta ordem:

1. **Diagnóstico** — lista curta dos achados, cada um marcado como Erro, Risco, Manutenção ou
   Dúvida de regra, com a linha ou o trecho.
2. **Código** — a fórmula completa num único bloco, pronta para colar (nunca trechos soltos para o
   usuário montar).
3. **O que mudou** — tabela: mudança | muda o resultado? (sim/não) | motivo.
4. **Como conferir no Cloud** — 2 a 4 casos concretos para testar antes de liberar (ex.: um imóvel
   construído, um terreno, um isento, um com campo vazio), com o valor esperado quando der para
   calcular à mão.
5. **Pendências** — perguntas de regra que ficaram em aberto e o que o código faz enquanto isso.

Se a fórmula for longa (cálculo de IPTU, por exemplo), mantenha a mesma estrutura: não omita partes
do código com "..." — o usuário vai colar o bloco inteiro.
