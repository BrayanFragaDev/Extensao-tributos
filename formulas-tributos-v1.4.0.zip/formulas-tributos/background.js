// Abre o painel lateral ao clicar no ícone e o habilita só no Tributos Cloud.
const ORIGEM = "https://tributos.betha.cloud/";

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

async function ajustar(tabId, url) {
  if (!tabId) return;
  const ativo = !!url && url.startsWith(ORIGEM);
  try { await chrome.sidePanel.setOptions({ tabId, path: "panel.html", enabled: ativo }); } catch (e) {}
}

chrome.tabs.onUpdated.addListener((tabId, info, tab) => { if (info.url || info.status === "complete") ajustar(tabId, tab.url); });
chrome.tabs.onActivated.addListener(async ({ tabId }) => { try { const t = await chrome.tabs.get(tabId); ajustar(tabId, t.url); } catch (e) {} });
