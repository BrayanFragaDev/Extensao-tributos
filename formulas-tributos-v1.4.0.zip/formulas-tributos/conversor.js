/* Conversor de fórmulas do Tributos desktop (SQL Anywhere / Integra) para BFC-Script do Tributos Cloud.
   Sem DOM. Uso:
     const r = CONVERSOR.converter(textoDesktop, contexto)
   contexto = {
     cadastro: "IMOVEIS" | "ECONOMICOS" | "RECEITAS_DIVERSAS" | "PROJETOS",
     credito:  { abreviatura, descricao, receitas: [{ codigo, abreviatura }] },
     mapa:     { "<chave>": "<nome no Cloud>" },   // ver CONVERSOR.chaves
     ano, autor
   }
   Devolve { codigo, refs: [{ chave, tipo, rotulo, sugestao }], pendencias: [texto], tipoFormula }.
   No desktop as opções são códigos (grupo 100, item 101); no Cloud são nomes de campo adicional
   e de opção. Cada código encontrado vira uma "ref" que o usuário mapeia uma vez por entidade. */
(function () {
"use strict";

const REF_POR_CADASTRO = { IMOVEIS: "imovel", ECONOMICOS: "economico", RECEITAS_DIVERSAS: "receitaDiversa", PROJETOS: "obra" };
const PALAVRAS = new Set(["set", "if", "elseif", "else", "end", "declare", "call", "raiserror", "message", "select", "return", "then", "for", "loop", "while", "begin"]);
const RESERVADAS = new Set(["it", "item", "indice", "ano", "imovel", "economico", "receitadiversa", "obra", "lancamento", "nulo", "se", "senao",
  "percorrer", "retornar", "suspender", "imprimir", "in", "as", "def", "class", "new", "true", "false", "null", "this", "super", "return",
  "if", "else", "for", "while", "usuario", "complementar", "datalancamento", "creditotributario", "tabelascalculos", "ident", "dtbasecampos", "receita", "receitas"]);
const VARS_SISTEMA = { w_ano: "ano", w_complementa: "complementar", w_venc_ini: "dataLancamento" };
const TIPO_OPC = { dbf_fc_ret_opc_economico: "bce", dbf_fc_existe_opc_bci: "bci", dbf_fc_existe_opc_bcc: "bcc", dbf_fc_existe_opc_projeto: "projeto" };
const NOME_TIPO = { bce: "BCE (econômico)", bci: "BCI (imóvel)", bcc: "BCC (contribuinte)", projeto: "projeto/obra" };

/* ---------- utilidades ---------- */
const semAcento = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "");
function nomeSeguro(n) {
  const base = semAcento(n).replace(/[^A-Za-z0-9_]/g, "");
  const partes = base.split("_").filter(Boolean);
  let c = partes.map((p, i) => i ? p[0].toUpperCase() + p.slice(1).toLowerCase() : p.toLowerCase()).join("") || "v";
  if (/^[0-9]/.test(c)) c = "v" + c;
  if (RESERVADAS.has(c.toLowerCase())) c = c + "Local";
  return c;
}
const aspas = s => '"' + String(s).replace(/\s+/g, " ").trim().replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';

function parensOk(s) { let d = 0; for (const ch of s) { if (ch === "(") d++; if (ch === ")") { d--; if (d < 0) return false; } } return d === 0; }

/* ---------- léxico ---------- */
function lexico(texto) {
  const t = String(texto || "").replace(/\r\n?/g, "\n");
  const toks = [];
  let i = 0;
  while (i < t.length) {
    const c = t[i];
    if (c === "\n") { toks.push({ k: "nl" }); i++; continue; }
    if (c === " " || c === "\t") { i++; continue; }
    if (t.startsWith("%%", i) || t.startsWith("--", i) || t.startsWith("//", i)) {
      const f = t.indexOf("\n", i); const fim = f < 0 ? t.length : f;
      toks.push({ k: "com", v: t.slice(i + 2, fim).trim() }); i = fim; continue;
    }
    if (t.startsWith("/*", i)) {
      const f = t.indexOf("*/", i + 2); const fim = f < 0 ? t.length : f + 2;
      t.slice(i + 2, f < 0 ? t.length : f).split("\n").forEach(l => toks.push({ k: "com", v: l.trim() }));
      i = fim; continue;
    }
    if (c === "'") {
      let j = i + 1, s = "";
      while (j < t.length) { if (t[j] === "'" && t[j + 1] === "'") { s += "'"; j += 2; continue; } if (t[j] === "'") break; s += t[j++]; }
      toks.push({ k: "str", v: s }); i = j + 1; continue;
    }
    if (c === '"') { // identificador entre aspas no SQL
      const j = t.indexOf('"', i + 1); toks.push({ k: "id", v: t.slice(i + 1, j < 0 ? t.length : j) }); i = j < 0 ? t.length : j + 1; continue;
    }
    if (/[0-9]/.test(c) || (c === "." && /[0-9]/.test(t[i + 1] || ""))) {
      const m = t.slice(i).match(/^[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?/); toks.push({ k: "num", v: m[0] }); i += m[0].length; continue;
    }
    if (/[A-Za-z_À-ſ@#]/.test(c)) {
      const m = t.slice(i).match(/^[A-Za-z_À-ſ@#][A-Za-z0-9_À-ſ@#$]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*/);
      toks.push({ k: "id", v: m[0] }); i += m[0].length; continue;
    }
    const dois = t.slice(i, i + 2);
    if (["<>", "<=", ">=", "!=", "||"].includes(dois)) { toks.push({ k: "op", v: dois }); i += 2; continue; }
    toks.push({ k: "op", v: c }); i++;
  }
  return toks;
}

/* ---------- conversão ---------- */
function converter(texto, ctx) {
  ctx = ctx || {};
  const cadastro = ctx.cadastro || "IMOVEIS";
  const REF = REF_POR_CADASTRO[cadastro] || "imovel";
  const anoCampos = cadastro === "ECONOMICOS" ? "dtBaseCampos" : "ano";
  const mapa = ctx.mapa || {};
  const refs = new Map(), pendencias = [], notas = new Set();
  const locais = new Map();      // nome desktop (minúsculo) -> nome seguro
  const porteVars = new Set();
  const atribuidas = new Set(), usadasAntes = new Set();
  let usaIdent = false, usaDtBase = cadastro === "ECONOMICOS";
  const toks = lexico(texto);
  const ehAcrescimo = toks.some(x => x.k === "id" && /^p_(valor|vcto|pgto|valor_juro|valor_multa|sub_rec)$/i.test(x.v));

  function ref(chave, tipo, rotulo, sugestao) {
    if (!refs.has(chave)) refs.set(chave, { chave, tipo, rotulo, sugestao: sugestao || "" });
    const v = mapa[chave];
    if (v === undefined || v === "") return null;
    return v;
  }
  function pend(msg) { if (!pendencias.includes(msg)) pendencias.push(msg); }
  function local(nome) {
    const k = nome.toLowerCase();
    if (!locais.has(k)) locais.set(k, nomeSeguro(nome));
    return locais.get(k);
  }
  function receitaAbrev(cod) {
    const c = String(cod).trim();
    const viaMapa = mapa["rec:" + c];
    if (viaMapa) return viaMapa;
    const r = ((ctx.credito && ctx.credito.receitas) || []).find(x => String(x.codigo) === c);
    if (r) return r.abreviatura;
    ref("rec:" + c, "receita", "Receita " + c + " do desktop", "");
    pend(`Receita ${c}: abreviatura no Cloud não encontrada no crédito. Informe no mapeamento.`);
    return "<receita " + c + ">";
  }

  /* --- leitor de tokens --- */
  let p = 0;
  const peek = (o = 0) => toks[p + o];
  const ehPal = (t, ...ps) => t && t.k === "id" && ps.includes(t.v.toLowerCase());
  function pulaNl() { while (peek() && peek().k === "nl") p++; }

  // coleta tokens de uma expressão até um terminador
  function coletaExpr(paraEm) {
    const out = []; let prof = 0;
    while (p < toks.length) {
      const t = peek();
      if (t.k === "com") { p++; continue; }
      if (prof === 0) {
        if (t.k === "op" && t.v === ";") break;
        if (paraEm && ehPal(t, ...paraEm)) break;
        if (t.k === "nl") {
          if (!out.length) { p++; continue; }  // expressão que começa na linha seguinte
          const ult = out[out.length - 1];
          let j = p; while (toks[j] && (toks[j].k === "nl" || toks[j].k === "com")) j++;
          const prox = toks[j];
          const ultOp = ult && ult.k === "op" && !")".includes(ult.v);
          const proxOp = prox && prox.k === "op" && !"(".includes(prox.v) && prox.v !== ";";
          if (!ultOp && !proxOp && !(paraEm && paraEm.length)) break;
          if (paraEm && paraEm.length && prox && ehPal(prox, ...PALAVRAS) && !ultOp) break;
          p++; continue;
        }
      } else if (t.k === "nl") { p++; continue; }
      if (t.k === "op" && t.v === "(") prof++;
      if (t.k === "op" && t.v === ")") prof--;
      out.push(t); p++;
    }
    return out;
  }

  // traduz uma lista de tokens de expressão
  function semParensRedundantes(ts) {
    // "(" f( ... ) ")"  ->  f( ... )   (assim "= 2001" fica logo depois da chamada)
    for (let k = 0; k < ts.length - 3; k++) {
      if (!(ts[k].k === "op" && ts[k].v === "(" && ts[k + 1].k === "id" && ts[k + 2].k === "op" && ts[k + 2].v === "(")) continue;
      let d = 0, j = k + 2;
      for (; j < ts.length; j++) { if (ts[j].v === "(" && ts[j].k === "op") d++; if (ts[j].v === ")" && ts[j].k === "op") { d--; if (d === 0) break; } }
      if (ts[j + 1] && ts[j + 1].k === "op" && ts[j + 1].v === ")") { ts = ts.slice(0, k).concat(ts.slice(k + 1, j + 1), ts.slice(j + 2)); k = -1; }
    }
    return ts;
  }
  function expr(ts, ehCond) {
    ts = semParensRedundantes(ts);
    let i = 0;
    function args() { // espera "(" em ts[i]
      const lista = []; let atual = [], prof = 0; i++;
      while (i < ts.length) {
        const t = ts[i];
        if (t.k === "op" && t.v === "(") prof++;
        if (t.k === "op" && t.v === ")") { if (prof === 0) { i++; break; } prof--; }
        if (t.k === "op" && t.v === "," && prof === 0) { lista.push(atual); atual = []; i++; continue; }
        atual.push(t); i++;
      }
      if (atual.length || lista.length) lista.push(atual);
      return lista;
    }
    const txt = a => a.map(t => t.k === "str" ? "'" + t.v + "'" : t.v).join(" ");
    const numDe = a => { const s = a.map(t => t.v).join(""); return /^-?\d+$/.test(s) ? s : null; };
    const out = [];
    while (i < ts.length) {
      const t = ts[i];
      if (t.k === "str") {
        const d = t.v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        out.push(d ? `Datas.data(${+d[1]}, ${+d[2]}, ${+d[3]})` : aspas(t.v)); i++; continue;
      }
      if (t.k === "num") { out.push(t.v.startsWith(".") ? "0" + t.v : t.v); i++; continue; }
      if (t.k === "op") {
        const v = t.v;
        if (v === "=") out.push("=="); else if (v === "<>") out.push("!="); else if (v === "||") out.push("+"); else out.push(v);
        i++; continue;
      }
      // identificador
      const nome = t.v.replace(/^bethadba\./i, ""), low = nome.toLowerCase();
      const seguinte = ts[i + 1];
      if (low === "and") { out.push("&&"); i++; continue; }
      if (low === "or") { out.push("||"); i++; continue; }
      if (low === "not") { out.push("!"); i++; continue; }
      if (low === "is") {
        const neg = ts[i + 1] && ts[i + 1].v && ts[i + 1].v.toLowerCase() === "not";
        out.push(neg ? "!= nulo" : "== nulo"); i += neg ? 3 : 2; continue;
      }
      if (low === "null") { out.push("nulo"); i++; continue; }
      if (seguinte && seguinte.k === "op" && seguinte.v === "(") {
        i++; const a = args(); const A = a.map(x => expr(x, false));
        const r = funcao(low, a, A, ts, () => i, v => { i = v; });
        out.push(r); continue;
      }
      // comparação de porte do MEI
      if (porteVars.has(low) && ts[i + 1] && ts[i + 1].v === "=" && ts[i + 2] && ts[i + 2].k === "num") {
        const v = local(nome), cod = ts[i + 2].v;
        if (cod === "5") out.push(`(${v} == "MEI" || ${v} == "MICROEMPREENDEDOR_INDIVIDUAL")`);
        else { out.push(`${v} == ${cod}`); pend(`Porte da empresa comparado com o código ${cod} do desktop: troque pelo texto do enum no Cloud.`); }
        i += 3; continue;
      }
      if (VARS_SISTEMA[low]) { out.push(VARS_SISTEMA[low]); if (low === "w_venc_ini") notas.add("w_venc_ini (vencimento inicial) não existe no Cloud; foi trocado por dataLancamento."); i++; continue; }
      if (low === "w_codigo") { out.push(REF); i++; continue; }
      if (/^w_/.test(low) && !locais.has(low)) { pend(`Variável do desktop "${nome}" não tem equivalente no Cloud (linha com ${txt(ts).slice(0, 60)}).`); out.push(nomeSeguro(nome)); i++; continue; }
      if (ehAcrescimo && /^p_/.test(low)) {
        const m = { p_valor: "(receita.valor - receita.beneficio)", p_vcto: "dataVencimento", p_pgto: "dataBase", p_sub_rec: "creditoTributario.abreviatura" }[low];
        if (m) { out.push(m); if (low === "p_sub_rec") notas.add("p_sub_rec virou creditoTributario.abreviatura: compare com a abreviatura do crédito, não com o código da sub-receita."); i++; continue; }
      }
      const nm = local(nome);
      if (!atribuidas.has(nm)) usadasAntes.add(nm);
      out.push(nm); i++;
    }
    return out.join(" ").replace(/\( /g, "(").replace(/ \)/g, ")").replace(/ ,/g, ",").replace(/! =/g, "!=").replace(/= =/g, "==");

    // --- funções do desktop ---
    function funcao(low, a, A, ts, getI, setI) {
      const comparacao = () => { // consome "= N" ou "<> N" logo após a chamada
        const j = getI(), op = ts[j], n = ts[j + 1];
        if (op && op.k === "op" && (op.v === "=" || op.v === "<>" || op.v === "!=") && n && n.k === "num") { setI(j + 2); return { neg: op.v !== "=", item: n.v }; }
        return null;
      };
      if (TIPO_OPC[low]) {
        const tipo = TIPO_OPC[low], grupo = numDe(a[1] || []);
        const dono = tipo === "bcc" ? REF + ".contribuinte" : tipo === "bci" ? (REF === "obra" ? "obra.imovel" : "imovel") : tipo === "projeto" ? "obra" : REF;
        const cmp = comparacao();
        const campo = ref(`${tipo}:${grupo}`, "campo", `Grupo ${grupo} do ${NOME_TIPO[tipo]}`);
        if (!campo) pend(`Grupo ${grupo} do ${NOME_TIPO[tipo]}: escolha o campo adicional do Cloud no mapeamento.`);
        if (cmp) {
          const opcao = ref(`${tipo}:${grupo}:${cmp.item}`, "opcao", `Item ${cmp.item} (grupo ${grupo})`, `${tipo}:${grupo}`);
          if (!opcao) pend(`Item ${cmp.item} do grupo ${grupo}: escolha a opção do campo no mapeamento (no Cloud as opções são por nome).`);
          const s = `(CamposAdicionais.valorOpcao(${dono}, ${aspas(campo || "<campo do grupo " + grupo + ">")}, ${aspas(opcao || "<opção do item " + cmp.item + ">")}, ${tipo === "bci" || tipo === "bcc" ? "ano" : anoCampos}) ?: false)`;
          if (tipo === "bce") usaDtBase = true;
          return cmp.neg ? "!" + s : s;
        }
        const opCmp = ts[getI()] && ts[getI()].k === "op" && ["<", ">", "<=", ">="].includes(ts[getI()].v) ? ts[getI()].v + " " + ((ts[getI() + 1] || {}).v || "") : "";
        pend(opCmp ? `${low}(…, ${grupo}) ${opCmp}: compara faixa de códigos de item; no Cloud teste cada opção com valorOpcao e junte com ||.` : `${low}(…, ${grupo}) usado sem comparar com um item: no Cloud só dá para testar uma opção por vez (valorOpcao). Reescreva testando cada opção.`);
        return `/* PENDENTE ${low}(grupo ${grupo}) */ 0`;
      }
      switch (low) {
        case "dbf_fc_retbci_valor": {
          const item = numDe(a[1] || []); const campo = ref(`bci:${item}`, "campo", `Item de valor ${item} do BCI`);
          if (!campo) pend(`Item de valor ${item} do BCI: escolha o campo adicional (numérico) do imóvel.`);
          return `(CamposAdicionais.valor(${REF === "obra" ? "obra.imovel" : "imovel"}, ${aspas(campo || "<campo do item " + item + ">")}, ano) ?: 0)`;
        }
        case "dbf_fc_retprojeto_valor": {
          const item = numDe(a[1] || []); const campo = ref(`projeto:${item}`, "campo", `Item de valor ${item} do projeto`);
          if (!campo) pend(`Item ${item} do projeto: escolha o campo adicional da obra.`);
          return `(CamposAdicionais.valor(obra, ${aspas(campo || "<campo do item " + item + ">")}, ano) ?: 0)`;
        }
        case "dbf_fc_valor_base": {
          const n = numDe(a[1] || []); const cred = (ctx.credito && ctx.credito.abreviatura) || "credito";
          const campo = ref(`base:${cred}:${n}`, "campo", `Base ${n} do tipo de serviço (${cred})`);
          if (!campo) pend(`Base ${n} (${cred}): escolha o campo adicional que guarda o valor informado.`);
          return `(CamposAdicionais.valor(${REF}, ${aspas(campo || "<campo da base " + n + ">")}, ${anoCampos}) ?: 0)`;
        }
        case "dbf_fc_valor_idx": {
          const cod = numDe(a[0] || []) || A[0]; const sigla = ref(`idx:${cod}`, "indexador", `Indexador ${cod} do desktop`, "URM");
          if (!sigla) pend(`Indexador ${cod} do desktop: informe a sigla no Cloud (ex.: URM).`);
          let data = A[1] || "Datas.hoje()";
          const m = data.match(/^ano \+ "-(\d{2})-(\d{2})"$/); if (m) data = `Datas.data(ano, ${+m[1]}, ${+m[2]})`;
          return `Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(${aspas(sigla || "<sigla " + cod + ">")}, ${data})`;
        }
        case "dbf_fc_valor_tab": {
          const tipo = numDe(a[0] || []), tab = numDe(a[2] || []), col = numDe(a[3] || []);
          const cod = ref(`tab:${tipo}:${tab}:${col}`, "tabela", `Tabela ${tab}, coluna ${col} (tabelas_${tipo === "2" ? "ii" : "i"})`);
          if (!cod) pend(`Tabela ${tab} coluna ${col} do desktop: informe o código da tabela de cálculo no Cloud.`);
          return `tabelasCalculos.getValor(ano, ${cod || "0 /* código da tabela " + tab + " */"}, imovel.codigo)`;
        }
        case "dbf_fc_cria_bci_valor": case "dbf_fc_cria_bcc_valor": {
          const tipo = low === "dbf_fc_cria_bci_valor" ? "bci" : "bcc";
          const item = numDe(a[1] || []); const campo = ref(`${tipo}:${item}`, "campo", `Item de valor ${item} do ${NOME_TIPO[tipo]}`);
          if (!campo) pend(`Item de valor ${item} do ${NOME_TIPO[tipo]}: escolha o campo adicional que recebe o valor.`);
          const dono = tipo === "bcc" ? REF + ".contribuinte" : (REF === "obra" ? "obra.imovel" : "imovel");
          return `CamposAdicionais.preencherCampoAdicional(${dono}, ${aspas(campo || "<campo do item " + item + ">")}, ${A[2]}, ano)`;
        }
        case "dbf_fc_ret_data_inicio_ativ": case "dbf_fc_ret_data_reinicio_ativ":
          notas.add("Datas de início e reinício do desktop viraram economico.dataInicioOuReinicio, que já devolve o reinício quando existe. Revise o IF que escolhia entre as duas.");
          return "economico.dataInicioOuReinicio";
        case "dbf_fc_ret_proxdiautil": return `Utilitarios.proximoDiaUtil(${A[0]})`;
        case "dbf_eh_feriado": return `Utilitarios.ehFeriado(${A[0]})`;
        case "isnull": case "coalesce": return `(${A[0]} ?: ${A[1]})`;
        case "day": return `Datas.dia(${A[0]})`;
        case "month": return `Datas.mes(${A[0]})`;
        case "year": return `Datas.ano(${A[0]})`;
        case "today": case "now": case "getdate": return "Datas.hoje()";
        case "months": return /^-?\d+$/.test(String(A[1]).trim()) ? `Datas.adicionaMeses(${A[0]}, ${A[1]})` : `Datas.diferencaMeses(${A[0]}, ${A[1]})`;
        case "days": return `Datas.diferencaDias(${A[0]}, ${A[1]})`;
        case "years": return `Datas.diferencaAnos(${A[0]}, ${A[1]})`;
        case "round": return `Numeros.arredonda(${A[0]}, ${A[1] || 0})`;
        case "truncnum": case "truncate": return `Numeros.trunca(${A[0]}, ${A[1] || 0})`;
        case "abs": return `Numeros.absoluto(${A[0]})`;
        case "ceiling": return `Numeros.teto(${A[0]})`;
        case "floor": return `Numeros.piso(${A[0]})`;
        case "power": return `Numeros.potencia(${A[0]}, ${A[1]})`;
        case "greater": return `Numeros.maximo(${A[0]}, ${A[1]})`;
        case "lesser": return `Numeros.minimo(${A[0]}, ${A[1]})`;
        case "upper": case "ucase": return `Caracteres.maiusculo(${A[0]})`;
        case "lower": case "lcase": return `Caracteres.minusculo(${A[0]})`;
        case "trim": return `Caracteres.removeEspacos(${A[0]})`;
        case "left": return `Caracteres.esquerda(${A[0]}, ${A[1]})`;
        case "right": return `Caracteres.direita(${A[0]}, ${A[1]})`;
        case "length": return `Caracteres.tamanho(${A[0]})`;
        case "substr": case "substring": return `Caracteres.subTexto(${A[0]}, ${A[1]} - 1, ${A[2] || "Caracteres.tamanho(" + A[0] + ")"})`;
        case "dbf_fc_cria_rec": return `/*CRIA_REC*/${a.map(txt).join("|")}`;
        case "dbf_fc_cria_rec_aliq":
          pend("dbf_fc_cria_rec_aliq (ISS variável por alíquota) não tem equivalente: no Cloud o ISS variável vem da declaração de serviços.");
          return "/* PENDENTE dbf_fc_cria_rec_aliq */ 0";
        case "dbf_fc_cria_desc_imo": case "dbf_fc_cria_desc_ped":
          pend(`${low}: desconto no Cloud é configurado na forma de pagamento do crédito, não na fórmula.`);
          return `/* PENDENTE ${low} */ 0`;
        case "dbf_fc_ret_ativ_principal":
          notas.add("Atividade principal: use economico.cnaePrincipal ou economico.servicoPrincipal.");
          return "economico.cnaePrincipal";
        default:
          pend(`Função ${low}() do desktop sem equivalente conhecido.`);
          return `/* PENDENTE ${low}(${A.join(", ")}) */ 0`;
      }
    }
  }

  /* --- comandos --- */
  const linhas = [];
  let nivel = 0, pilha = [];
  const emite = s => linhas.push("  ".repeat(Math.max(0, nivel)) + s);

  function criaReceita(marcador) {
    const partes = marcador.replace("/*CRIA_REC*/", "").split("|");
    const cod = (partes[0] || "").replace(/\s/g, "");
    const valor = expr(lexico(partes[1] || "0").filter(t => t.k !== "nl"), false);
    const isen = (partes[3] || "").trim();
    const abrev = receitaAbrev(cod);
    if (isen && !/^null$/i.test(isen)) {
      const literal = /^\d+$/.test(isen.replace(/\s/g, ""));
      const chave = "benef:" + isen.replace(/\s/g, "").toLowerCase();
      const b = ref(chave, "beneficio", literal ? `Isenção ${isen} do desktop` : `Isenção (variável ${isen})`, "");
      if (!b) pend(`Isenção ${isen} do desktop: informe a descrição do benefício fiscal no Cloud.`);
      const comBenef = `lancamento.criarReceita(${aspas(abrev)}, ${valor}, Utilitarios.buscaBeneficioFiscal(${aspas(b || "<benefício " + isen + ">")}), 100);`;
      if (literal) return comBenef;
      // no desktop a isenção é um código numa variável: 0 ou nulo = sem isenção
      const v = expr(lexico(isen), false);
      return [`se (${v} != nulo && ${v} != 0) {`, "  " + comBenef, "} senao {", `  lancamento.criarReceita(${aspas(abrev)}, ${valor});`, "}"];
    }
    if (partes[2] && !/^\s*null\s*$/i.test(partes[2])) notas.add("O 3º parâmetro de dbf_fc_cria_rec (configuração de parcelas) não vai para a fórmula: no Cloud vem da forma de pagamento do crédito.");
    return `lancamento.criarReceita(${aspas(abrev)}, ${valor});`;
  }

  function comando() {
    pulaNl();
    const t = peek(); if (!t) return;
    if (t.k === "com") {
      p++;
      const v = t.v.replace(/^[*\s]+$/, "");
      const lixo = /^[wp]_\w+\s*-+>/i.test(v) || /dbp_raiserror|OBSERVA[CÇ][AÃ]O|^-- F[oó]rmula de Lan[cç]amento/i.test(v) || /^\*+$/.test(t.v.trim());
      if (!lixo && v) emite("// " + v);
      return;
    }
    if (t.k === "op" && t.v === ";") { p++; return; }
    if (t.k !== "id") { coletaExpr(); p++; return; }
    const kw = t.v.toLowerCase();
    if (kw === "declare") { p++; while (peek() && !(peek().k === "op" && peek().v === ";") && peek().k !== "nl") { const x = peek(); if (x.k === "id" && !locais.has(x.v.toLowerCase()) && toks[p - 1].v.toLowerCase() === "declare") local(x.v); p++; } return; }
    if (kw === "set") {
      p++; const alvo = peek(); p++;
      if (peek() && peek().v === "=") p++;
      const ts = coletaExpr();
      const low = alvo.v.toLowerCase();
      // SET x = (SELECT ...)
      if (ts.some(x => x.k === "id" && x.v.toLowerCase() === "select")) { selectParaAtribuicao(ts, alvo.v); return; }
      if (ehAcrescimo && (low === "p_valor_juro" || low === "p_valor_multa")) { emite(`receita.${low === "p_valor_juro" ? "comJuro" : "comMulta"}(${expr(ts)});`); return; }
      const e = expr(ts, false);
      if (e.startsWith("/*CRIA_REC*/")) { const r = criaReceita(e); (Array.isArray(r) ? r : [r]).forEach(emite); return; }
      if (low === "ret") { emite(e + ";"); return; }
      emite(`${local(alvo.v)} = ${e};`);
      atribuidas.add(local(alvo.v));
      return;
    }
    if (kw === "if" || kw === "elseif") {
      p++; const ts = coletaExpr(["then"]); if (ehPal(peek(), "then")) p++;
      let c = expr(ts, true);
      while (/^\(.*\)$/.test(c) && parensOk(c.slice(1, -1))) c = c.slice(1, -1);
      if (kw === "if") { emite(`se (${c}) {`); nivel++; pilha.push(0); }
      else { nivel--; emite("} senao {"); nivel++; emite(`se (${c}) {`); nivel++; pilha[pilha.length - 1]++; }
      return;
    }
    if (kw === "else") { p++; nivel--; emite("} senao {"); nivel++; return; }
    if (kw === "end") {
      p++; if (ehPal(peek(), "if")) p++;
      const extra = pilha.pop() || 0;
      for (let k = 0; k <= extra; k++) { nivel--; emite("}"); }
      return;
    }
    if (kw === "raiserror") {
      p++; const ts = coletaExpr(); const msg = ts.filter(x => x.k === "str").map(x => x.v).join(" ") || "erro no cálculo";
      usaIdent = true; emite(`suspender(ident + ${aspas(msg)});`); return;
    }
    if (kw === "call") {
      p++; const ts = coletaExpr(); const s = ts.map(x => x.v).join("");
      if (/dbp_raiserror/i.test(s)) { const msg = ts.filter(x => x.k === "str").map(x => x.v).join(" ") || "erro no cálculo"; usaIdent = true; emite(`suspender(ident + ${aspas(msg)});`); }
      else { emite(`// PENDENTE: CALL ${ts.map(x => x.k === "str" ? "'" + x.v + "'" : x.v).join(" ")}`); pend("Chamada CALL sem equivalente: " + s.slice(0, 80)); }
      return;
    }
    if (kw === "message") { p++; const ts = coletaExpr(); emite(`// (MESSAGE do desktop removido: ${ts.map(x => x.k === "str" ? "'" + x.v + "'" : x.v).join(" ").slice(0, 100)})`); return; }
    if (kw === "select") { const ts = coletaExpr(); selectInto(ts); return; }
    if (kw === "return") { p++; coletaExpr(); emite("// PENDENTE: RETURN do desktop (nas fórmulas de cálculo use suspender para interromper)"); pend("RETURN no desktop: revise o fluxo."); return; }
    if (["for", "loop", "while"].includes(kw)) { const ts = coletaExpr(); emite(`// PENDENTE (laço SQL): ${ts.map(x => x.v).join(" ").slice(0, 120)}`); pend("Laço FOR/WHILE do SQL: reescreva com percorrer."); return; }
    // atribuição sem SET ou comando desconhecido
    const ts = coletaExpr();
    emite(`// PENDENTE: ${ts.map(x => x.k === "str" ? "'" + x.v + "'" : x.v).join(" ").slice(0, 160)}`);
    pend("Trecho não reconhecido: " + ts.map(x => x.v).join(" ").slice(0, 80));
  }

  function selectInto(ts) {
    const s = ts.map(x => x.k === "str" ? "'" + x.v + "'" : x.v).join(" ");
    const m = s.match(/select\s+(.+?)\s+into\s+(\S+)\s+from\s+(\S+)/i);
    if (m) { if (atribuicaoConhecida(m[1], m[2], m[3])) return; }
    emite(`// PENDENTE (consulta SQL sem equivalente direto): ${s.slice(0, 200)}`);
    pend("Consulta SELECT do desktop: " + s.slice(0, 100));
  }
  function selectParaAtribuicao(ts, alvo) {
    const s = ts.map(x => x.k === "str" ? "'" + x.v + "'" : x.v).join(" ");
    const m = s.match(/select\s+(\S+)\s+from\s+(\S+)/i);
    if (m && atribuicaoConhecida(m[1], alvo, m[2])) return;
    emite(`${local(alvo)} = nulo;  // PENDENTE (consulta SQL): ${s.slice(0, 160)}`); atribuidas.add(local(alvo));
    pend("Consulta SELECT do desktop: " + s.slice(0, 100));
  }
  function atribuicaoConhecida(coluna, alvo, tabela) {
    atribuidas.add(local(alvo));
    const col = coluna.toLowerCase().trim(), tab = tabela.toLowerCase().replace("bethadba.", "");
    if (col === "porte_empresa" && /pessoas_juridicas/.test(tab)) {
      porteVars.add(alvo.toLowerCase()); emite(`${local(alvo)} = economico.porteDaEmpresa;  // texto do enum no Cloud`);
      notas.add("Porte da empresa: no desktop era código (5 = MEI); no Cloud é texto. Confirme o valor do MEI com imprimir."); return true;
    }
    if (col === "i_pessoas" && /economicos/.test(tab)) { emite(`${local(alvo)} = economico.contribuinte;`); return true; }
    if (col === "i_pessoas" && /imoveis/.test(tab)) { emite(`${local(alvo)} = imovel.contribuinte;`); return true; }
    if (/^campo\d$/.test(col) && /imoveis/.test(tab)) {
      const v = local(alvo);
      emite(`${v} = imovel.inscricaoImobiliaria?.${col};  // no Cloud vem como texto`);
      emite(`se (${v} != nulo && Numeros.ehNumero("" + ${v})) {`, ); emite(`  ${v} = Numeros.numero("" + ${v});`); emite("}");
      notas.add(`${col} do imóvel virou imovel.inscricaoImobiliaria.${col}; o texto é convertido em número quando possível. Confira com imprimir.`); return true;
    }
    if (col === "tipo" && /economicos/.test(tab)) {
      emite(`${local(alvo)} = economico.regimeCobrancaIss;  // desktop: 'F' fixo / 'H' homologado`);
      notas.add("Tipo do econômico ('F'/'H') virou economico.regimeCobrancaIss. No Cloud o valor é texto do enum (provavelmente FIXO/HOMOLOGADO): confirme com imprimir e ajuste as comparações.");
      pend("Comparações com 'F'/'H' do tipo do econômico: troque pelo valor real de economico.regimeCobrancaIss.");
      return true;
    }
    if (col === "setor" && /imoveis/.test(tab)) { emite(`${local(alvo)} = imovel.setor;`); return true; }
    return false;
  }

  while (p < toks.length) { const antes = p; comando(); if (p === antes) p++; }
  while (nivel > 0) { nivel--; emite("}"); pend("Bloco IF sem END IF no desktop: fechado automaticamente."); }

  /* --- montagem no padrão --- */
  const cred = ctx.credito || {};
  const hoje = (() => { const d = new Date(); return [d.getDate(), d.getMonth() + 1, d.getFullYear()].map((x, i) => i < 2 ? String(x).padStart(2, "0") : x).join("/"); })();
  const L = [
    "// ============================================================",
    "// " + ((cred.descricao || cred.abreviatura || "FÓRMULA CONVERTIDA DO DESKTOP").toUpperCase()),
    `// Tipo      : ${ehAcrescimo ? "Acréscimos" : "Cálculo"} | Crédito: ${cred.abreviatura || "____"} | Exercício: ${ctx.ano || "____"}`,
    "// O que faz : convertida automaticamente da fórmula do Tributos desktop",
    "// Base legal: Lei nº ____/____, art. __",
    `// Histórico : ${hoje} - ${ctx.autor || "<nome>"} - conversão desktop → Cloud (rascunho; revisar pendências)`,
    "// ============================================================",
    ""
  ];
  if (pendencias.length) {
    L.push("// PENDÊNCIAS DA CONVERSÃO (resolva antes de liberar):");
    pendencias.forEach(x => L.push("//  - " + x));
    L.push("");
  }
  L.push("// ---------- ENTRADAS E VALIDAÇÕES ----------");
  if (usaIdent || true) {
    const idTxt = { imovel: '"Imovel " + imovel.codigo', economico: '"Economico " + economico.codigo', receitaDiversa: '"Receita diversa " + receitaDiversa.codigo', obra: '"Obra " + obra.codigo' }[REF];
    L.push(`ident = ${idTxt} + " (" + ano + "): ";`);
  }
  if (usaDtBase && cadastro === "ECONOMICOS") L.push("// em econômicos o campo adicional é lido por data, não por ano", "dtBaseCampos = dataBase ?: Datas.data(ano, 1, 1);");
  const antes = [...usadasAntes].filter(v => !["receita"].includes(v));
  if (antes.length) {
    L.push("// variáveis lidas antes de receber valor no desktop (lá valiam nulo); no BFC-Script precisam existir antes do uso");
    antes.forEach(v => L.push(`${v} = nulo;`));
    pend("Variáveis usadas antes de receber valor: " + antes.join(", ") + ". Foram iniciadas com nulo; confira se o desktop dependia disso.");
  }
  L.push("", "// ---------- CÁLCULO (convertido do desktop) ----------");
  let corpo = linhas;
  if (ehAcrescimo) {
    corpo = ["percorrer(receitas) { receita ->", ...linhas.map(l => "  " + l), "}"];
    notas.add("Fórmula de juro/multa: no Cloud fica no módulo de acréscimos e trata juro e multa no mesmo script, percorrendo as receitas.");
  }
  // remove linhas em branco repetidas
  const limpo = []; corpo.forEach(l => { if (l.trim() === "" && limpo.length && limpo[limpo.length - 1].trim() === "") return; limpo.push(l); });
  L.push(...limpo);
  let codigo = L.join("\n").replace(/\n{3,}/g, "\n\n") + "\n";
  // IF do desktop que escolhia entre data de reinício e de início: no Cloud é uma propriedade só
  codigo = codigo.replace(/^( *)se \(economico\.dataInicioOuReinicio (?:==|!=) Datas\.data\(1900, 1, 1\)\) \{\n *(\w+) = economico\.dataInicioOuReinicio;\n *\} senao \{\n *\2 = economico\.dataInicioOuReinicio;\n *\}\n/gm,
    "$1// reinício quando houver, senão início (o desktop escolhia entre as duas datas)\n$1$2 = economico.dataInicioOuReinicio;\n");
  return { codigo, refs: [...refs.values()], pendencias, notas: [...notas], tipoFormula: ehAcrescimo ? "acrescimos" : "calculo" };
}


/* Mapeamentos já conhecidos por entidade (chave = "db<base>-ent<entidade>").
   Barão do Triunfo: tirado da conversão manual (MAPEAMENTO.md) e conferido com o cadastro do Cloud em 05/11/2026. */
const SEMENTES = {
  "db447-ent804": {
    "idx:2": "URM",
    "bce:100": "TX LICENÇA/FISCALIZAÇÃO",
    "bce:100:101": "Comércio / Industria (ME)", "bce:100:102": "Comércio / Industria (EPP)", "bce:100:103": "Comércio / Industria(EGP)",
    "bce:100:104": "Indústria", "bce:100:105": "Prestador de Serviço", "bce:100:106": "Autônomo (Curso Superior)",
    "bce:100:107": "Autônomo (Curso Médio)", "bce:100:108": "Autônomo (Outros)", "bce:100:109": "Ambulante Perm. (Sem Veículo)",
    "bce:100:110": "Ambulante Perm. (Com Veículo)", "bce:100:111": "Ambulante Perm. (Tendas, Estandes)",
    "bci:1000": "OCUPAÇÃO", "bci:1000:1006": "Construído",
    "bci:300": "COLETA DE LIXO", "bci:300:301": "Sim",
    "bci:500": "TAXA DE LIMPEZA E CONSERVAÇÃO", "bci:500:501": "Sim",
    "bci:2000": "UTILIZAÇÃO DO IMÓVEL", "bci:2000:2003": "Comercial/Serviço", "bci:2000:2004": "Industrial",
    "bci:2000:2001": "Terreno Sem Uso", "bci:2000:2002": "Residencial",
    "bci:100": "IMUNE/ISENTO IPTU", "bci:100:101": "Sim",
    "bci:16499": "Área do Terreno", "bci:16699": "Área da Unidade", "bci:16899": "Área Total da Edificação",
    "bci:16599": "Fração Ideal", "bci:17099": "Valor Venal Terreno", "bci:17299": "Valor Venal Prédio",
    "bci:17499": "Valor Venal do Imóvel", "bci:17899": "Valor Imposto Territorial", "bci:18099": "Valor Imposto Predial", "bci:18299": "Valor IPTU",
    "tab:1:1:1": "122", "tab:1:2:1": "123", "tab:1:3:1": "124", "tab:1:4:1": "125", "tab:1:5:1": "127", "tab:1:6:1": "126",
    "tab:2:1:1": "115", "tab:2:2:1": "116", "tab:2:3:1": "117", "tab:2:4:1": "118", "tab:2:5:1": "119", "tab:2:6:1": "120", "tab:2:7:1": "121",
    "benef:isencao": "Créditos tributários"
  }
};
window.CONVERSOR = { converter, REF_POR_CADASTRO, nomeSeguro, SEMENTES };
})();
