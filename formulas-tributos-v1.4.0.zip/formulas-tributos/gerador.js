/* Gerador de fórmulas — modelos e utilidades (sem DOM). */
(function () {
"use strict";
/* ---------- utilidades ---------- */
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const q = s => '"' + String(s ?? "").replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
const num = v => { const n = parseFloat(String(v).replace(",", ".")); return isNaN(n) ? null : n; };
function fx(n, min = 2, max = 6) {            // número BFC: ponto decimal, ao menos 2 casas
  if (n === null || n === undefined) return "nulo";
  let s = Number(n).toFixed(max).replace(/0+$/, "");
  const [i, d = ""] = s.split(".");
  return i + "." + (d + "0".repeat(min)).slice(0, Math.max(min, d.length));
}
const frac = p => fx(num(p) === null ? 0 : num(p) / 100);
const pad = (s, n) => (s + " ".repeat(n)).slice(0, Math.max(n, s.length));
const hoje = () => { const d = new Date(); return [d.getDate(), d.getMonth() + 1, d.getFullYear()].map((x, i) => i < 2 ? String(x).padStart(2, "0") : x).join("/"); };

function header(s, tipo, credito, oQueFaz) {
  return [
    "// ============================================================",
    "// " + (s.nome || "FÓRMULA").toUpperCase(),
    "// Tipo      : " + tipo + " | Crédito: " + (credito || "____") + " | Exercício: " + (s.ano || "____"),
    "// O que faz : " + oQueFaz,
    "// Base legal: " + (s.lei || "Lei nº ____/____, art. __"),
    "// Histórico : " + hoje() + " - " + (s.autor || "<nome>") + " - " + (s.motivo || "criação pelo gerador"),
    "// ============================================================",
    ""
  ];
}
const sec = t => "// ---------- " + t + " ----------";

/* ---------- campos comuns ---------- */
const comuns = [
  { k: "nome", l: "Nome da fórmula", t: "text" },
  { k: "ano", l: "Exercício", t: "number", half: true },
  { k: "autor", l: "Seu nome (histórico)", t: "text", half: true },
  { k: "lei", l: "Base legal", t: "text", ph: "Lei nº 857/2026, art. 3º" },
  { k: "motivo", l: "Motivo da alteração (histórico)", t: "text", ph: "criação pelo gerador" }
];

/* ---------- MODELO 1: desconto de parcelamento ---------- */
const mDesconto = {
  id: "desconto", titulo: "Desconto de parcelamento / REFIS", sub: "Desconto em juros, multa, correção e tributo por faixa de parcelas", tipo: "DESCONTO_PARCELAMENTO",
  campos: [
    { grupo: "Identificação", itens: comuns },
    { grupo: "Regra", itens: [
      { k: "base", l: "Desconto calculado sobre", t: "select", ops: [["total", "Totais da dívida/lançamento (vlTotalJuros...)"], ["parcelar", "Só o que está sendo parcelado (vlTotalJurosParcelar...)"]] },
      { k: "faixas", l: "Faixas de parcelas (percentuais de desconto)", t: "rows", cols: [["de", "Parcelas de"], ["ate", "até"], ["j", "% juros"], ["m", "% multa"], ["c", "% correção"], ["t", "% tributo"]] },
      { k: "limite", l: "Adesão válida até (opcional)", t: "date" }
    ] }
  ],
  padrao: { nome: "REFIS 2026", ano: 2026, base: "total", lei: "", limite: "",
    faixas: [{ de: 1, ate: 1, j: 100, m: 100, c: 0, t: 0 }, { de: 2, ate: 12, j: 80, m: 80, c: 0, t: 0 }, { de: 13, ate: 60, j: 50, m: 50, c: 0, t: 0 }] },
  avisos(s) {
    const w = [], f = (s.faixas || []).map(r => ({ de: num(r.de), ate: num(r.ate) })).filter(r => r.de !== null && r.ate !== null).sort((a, b) => a.de - b.de);
    if (!f.length) w.push("Informe ao menos uma faixa de parcelas.");
    f.forEach((r, i) => {
      if (r.de > r.ate) w.push(`Faixa ${r.de}–${r.ate}: "de" é maior que "até".`);
      if (i && r.de <= f[i - 1].ate) w.push(`Faixas ${f[i - 1].de}–${f[i - 1].ate} e ${r.de}–${r.ate} se sobrepõem: vale a que aparece primeiro na lista.`);
      if (i && r.de > f[i - 1].ate + 1) w.push(`Buraco entre ${f[i - 1].ate} e ${r.de} parcelas: nessas quantidades não há desconto.`);
    });
    (s.faixas || []).forEach(r => ["j", "m", "c", "t"].forEach(k => { const v = num(r[k]); if (v !== null && (v < 0 || v > 100)) w.push("Percentual fora de 0 a 100 numa faixa."); }));
    return [...new Set(w)];
  },
  gerar(s) {
    const b = s.base === "parcelar"
      ? { t: "vlTotalLancadoParcelar", c: "vlTotalCorrecaoParcelar", m: "vlTotalMultaParcelar", j: "vlTotalJurosParcelar" }
      : { t: "vlTotalLancado", c: "vlTotalCorrecao", m: "vlTotalMulta", j: "vlTotalJuros" };
    const rows = (s.faixas || []).filter(r => num(r.de) !== null && num(r.ate) !== null);
    const L = header(s, "Desconto para parcelamentos", "todos", "desconto sobre juros, multa, correção e tributo conforme o nº de parcelas");
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push("// Cada faixa: [parcelas de, parcelas até, desc. juros, desc. multa, desc. correção, desc. tributo]");
    L.push("// Percentuais em fração: 0.95 = 95% de desconto sobre o valor.");
    L.push("faixasDesconto = [");
    rows.forEach((r, i) => {
      const linha = `  [${num(r.de)}, ${num(r.ate)}, ${frac(r.j)}, ${frac(r.m)}, ${frac(r.c)}, ${frac(r.t)}]` + (i < rows.length - 1 ? "," : "");
      L.push(pad(linha, 46) + `// ${num(r.de) === num(r.ate) ? num(r.de) + (num(r.de) === 1 ? " parcela (à vista)" : " parcelas") : num(r.de) + " a " + num(r.ate) + " parcelas"}`);
    });
    L.push("];");
    const lim = s.limite ? s.limite.split("-").map(Number) : null;
    if (lim) L.push(`dtFimAdesao = Datas.data(${lim[0]}, ${lim[1]}, ${lim[2]});  // último dia para aderir com desconto`);
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push(`// Base: ${s.base === "parcelar" ? "somente os valores que estão sendo parcelados" : "totais da dívida ou do lançamento do exercício"}.`);
    L.push("faixaAplicada = nulo;");
    L.push("percorrer(faixasDesconto) { faixa ->");
    L.push("  se (faixaAplicada == nulo && qtdParcelas >= faixa[0] && qtdParcelas <= faixa[1]) {");
    L.push("    faixaAplicada = faixa;");
    L.push("  }");
    L.push("}");
    if (lim) {
      L.push("// fora do prazo de adesão não há desconto (compara com o dia seguinte ao limite, porque hoje() traz a hora)");
      L.push("se (Datas.hoje() >= Datas.adicionaDias(dtFimAdesao, 1)) {");
      L.push("  faixaAplicada = nulo;");
      L.push("}");
    }
    L.push("", sec("CÁLCULO"));
    L.push("descontoTributo  = 0.00;", "descontoCorrecao = 0.00;", "descontoMulta    = 0.00;", "descontoJuros    = 0.00;", "");
    L.push("// quantidade de parcelas fora das faixas: sem desconto");
    L.push("se (faixaAplicada != nulo) {");
    L.push(`  descontoJuros    = ${b.j} * faixaAplicada[2];`);
    L.push(`  descontoMulta    = ${b.m} * faixaAplicada[3];`);
    L.push(`  descontoCorrecao = ${b.c} * faixaAplicada[4];`);
    L.push(`  descontoTributo  = ${b.t} * faixaAplicada[5];`);
    L.push("}");
    L.push("", sec("RESULTADO"));
    L.push("descontoTributo  = Numeros.arredonda(descontoTributo, 2);", "descontoCorrecao = Numeros.arredonda(descontoCorrecao, 2);", "descontoMulta    = Numeros.arredonda(descontoMulta, 2);", "descontoJuros    = Numeros.arredonda(descontoJuros, 2);", "");
    L.push("retornar TRIBUTO: descontoTributo, CORRECAO: descontoCorrecao, MULTA: descontoMulta, JUROS: descontoJuros;");
    return L.join("\n");
  },
  notas: ["Lembre de ativar a configuração de desconto no parcelamento: sem ela, a fórmula não é usada.", "A variável atribuída dentro do percorrer vale fora dele. Na primeira vez, confira com imprimir faixaAplicada no console."]
};

/* ---------- MODELO 2: taxa por enquadramento (econômicos) ---------- */
const mEnquadramento = {
  id: "enquadramento", titulo: "Taxa por enquadramento (econômicos)", sub: "Alvará, licença, fiscalização: fator em URM conforme opção de campo adicional", tipo: "GERACAO_CREDITO · ECONOMICOS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:ECONOMICOS" }] },
    { grupo: "Enquadramento", itens: [
      { k: "campo", l: "Campo adicional do econômico", t: "text", lista: "campo:ECONOMICOS" },
      { k: "sigla", l: "Indexador", t: "text", half: true, lista: "indexador" },
      { k: "receita", l: "Receita da taxa", t: "text", half: true, lista: "receita:credito" },
      { k: "enq", l: "Opções e fator (quantas vezes o indexador, por ano)", t: "rows", cols: [["op", "Opção do campo", "opcao:campo"], ["fator", "Fator"]] }
    ] },
    { grupo: "Regras opcionais", itens: [
      { k: "prop", l: "Proporcional aos meses a partir do início da atividade", t: "check" },
      { k: "receitaInicio", l: "Receita diferente no ano de início (ex.: alvará × fiscalização)", t: "text", ph: "deixe vazio para usar sempre a mesma", lista: "receita:credito" },
      { k: "mei", l: "MEI não paga (suspende o cálculo)", t: "check" },
      { k: "exp", l: "Taxa de expediente (% do indexador, 0 = não cobra)", t: "number", half: true },
      { k: "receitaExp", l: "Receita da taxa de expediente", t: "text", half: true, lista: "receita:credito" }
    ] }
  ],
  padrao: { nome: "Taxa de Licença e Fiscalização 2026", ano: 2026, credito: "ALVAR", campo: "TX LICENÇA/FISCALIZAÇÃO", sigla: "URM", receita: "TXFIS", receitaInicio: "TXALV",
    enq: [{ op: "101", fator: 0.9 }, { op: "102", fator: 1.5 }, { op: "103", fator: 3 }, { op: "105", fator: 2 }, { op: "108", fator: 1 }],
    prop: true, mei: true, exp: 6, receitaExp: "TXEXP" },
  avisos(s) {
    const w = [], ops = (s.enq || []).map(r => String(r.op || "").trim()).filter(Boolean);
    if (!ops.length) w.push("Informe ao menos uma opção de enquadramento.");
    if (new Set(ops).size !== ops.length) w.push("Há opção repetida na tabela: vale a primeira.");
    (s.enq || []).forEach(r => { if (String(r.op || "").trim() && !(num(r.fator) > 0)) w.push(`Opção ${r.op}: fator vazio ou zero.`); });
    if (!s.campo) w.push("Informe o nome do campo adicional exatamente como no cadastro, com acentos.");
    if (!s.receita) w.push("Informe a abreviatura da receita.");
    if (num(s.exp) > 0 && !s.receitaExp) w.push("Taxa de expediente sem abreviatura de receita.");
    return w;
  },
  gerar(s) {
    const rows = (s.enq || []).filter(r => String(r.op || "").trim());
    const exp = num(s.exp) > 0;
    const L = header(s, "Cálculo", s.credito, "taxa anual em " + (s.sigla || "URM") + " conforme o enquadramento do econômico" + (s.prop ? ", proporcional aos meses de atividade no ano de início" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push(`siglaIndexador     = ${q(s.sigla || "URM")};`);
    L.push(`campoEnquadramento = ${q(s.campo)};`);
    L.push(`receitaTaxa        = ${q(s.receita)};`);
    if (s.prop && s.receitaInicio) L.push(`receitaAnoInicio   = ${q(s.receitaInicio)};  // usada quando a atividade começou no próprio exercício`);
    if (exp) { L.push(`percTaxaExpediente = ${frac(s.exp)};  // ${num(s.exp)}% do indexador`); L.push(`receitaExpediente  = ${q(s.receitaExp)};`); }
    L.push("// [opção do campo de enquadramento, fator em " + (s.sigla || "URM") + " por ano]");
    L.push("enquadramentos = [");
    rows.forEach((r, i) => L.push(`  [${q(String(r.op).trim())}, ${fx(num(r.fator) ?? 0, 1)}]` + (i < rows.length - 1 ? "," : "")));
    L.push("];");
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Economico " + economico.codigo + " (" + ano + "): ";', "");
    if (s.mei) {
      L.push("// confirme com imprimir o valor que o porte devolve nesta entidade");
      L.push("porte = economico.porteDaEmpresa;");
      L.push('se (porte == "MEI" || porte == "MICROEMPREENDEDOR_INDIVIDUAL") {');
      L.push('  suspender(ident + "MEI nao paga esta taxa.");');
      L.push("}", "");
    }
    L.push("vlIndexador = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
    L.push("se (vlIndexador == nulo || vlIndexador == 0) {");
    L.push('  suspender(ident + "valor do indexador " + siglaIndexador + " nao cadastrado para " + ano + ".");');
    L.push("}", "");
    L.push("fatorIndexador = 0;");
    L.push("percorrer(enquadramentos) { opcao ->");
    L.push("  se (fatorIndexador == 0 && (CamposAdicionais.valorOpcao(economico, campoEnquadramento, opcao[0], ano) ?: false)) {");
    L.push("    fatorIndexador = opcao[1];");
    L.push("  }");
    L.push("}");
    L.push("se (fatorIndexador == 0) {");
    L.push('  suspender(ident + "enquadramento nao informado no campo " + campoEnquadramento + ".");');
    L.push("}");
    if (s.prop) {
      L.push("", "dtInicio = economico.dataInicioOuReinicio;");
      L.push("se (dtInicio == nulo) {");
      L.push('  suspender(ident + "data de inicio ou reinicio da atividade nao informada.");');
      L.push("}");
      L.push("ehAnoInicio = (Datas.ano(dtInicio) == ano);");
    }
    L.push("", sec("CÁLCULO"));
    if (s.prop) {
      L.push("// ano de início: cobra do mês de início até dezembro; demais anos: 12 meses");
      L.push("mesesDevidos = 12;");
      L.push("se (ehAnoInicio) {");
      L.push("  mesesDevidos = 13 - Datas.mes(dtInicio);");
      L.push("}");
      L.push("vlTaxa = ((vlIndexador * fatorIndexador) / 12) * mesesDevidos;");
    } else {
      L.push("vlTaxa = vlIndexador * fatorIndexador;");
    }
    if (exp) L.push("vlExpediente = vlIndexador * percTaxaExpediente;");
    if (s.prop && s.receitaInicio) {
      L.push("", "receitaLancar = receitaTaxa;");
      L.push("se (ehAnoInicio) {");
      L.push("  receitaLancar = receitaAnoInicio;");
      L.push("}");
    }
    L.push("", sec("RESULTADO"));
    L.push("vlTaxa = Numeros.arredonda(vlTaxa, 2);");
    if (exp) L.push("vlExpediente = Numeros.arredonda(vlExpediente, 2);");
    L.push("");
    L.push(`lancamento.criarReceita(${s.prop && s.receitaInicio ? "receitaLancar" : "receitaTaxa"}, vlTaxa);`);
    if (exp) { L.push("se (vlExpediente > 0) {", "  lancamento.criarReceita(receitaExpediente, vlExpediente);", "}"); }
    return L.join("\n");
  },
  notas: ["O nome do campo adicional e das opções tem de ser idêntico ao cadastro, inclusive acentos e espaços.", "Confira se a data de início deve vir de economico.dataInicioOuReinicio ou de um campo adicional, como em algumas migrações."]
};

/* ---------- MODELO 3: faixas de valor (imóveis) ---------- */
const mFaixas = {
  id: "faixas", titulo: "Imposto ou taxa por faixas de valor (imóveis)", sub: "Alíquota conforme a faixa do valor de um campo adicional, com mínimo e isenção", tipo: "GERACAO_CREDITO · IMOVEIS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:IMOVEIS" }] },
    { grupo: "Base e faixas", itens: [
      { k: "campo", l: "Campo adicional com a base de cálculo", t: "text", lista: "campo:IMOVEIS" },
      { k: "receita", l: "Receita lançada", t: "text", half: true, lista: "receita:credito" },
      { k: "minimo", l: "Valor mínimo em R$ (0 = sem mínimo)", t: "number", half: true },
      { k: "faixas", l: "Faixas (limite vazio = sem limite; use na última)", t: "rows", cols: [["lim", "Até (R$)"], ["aliq", "Alíquota %"]] }
    ] },
    { grupo: "Isenção (opcional)", itens: [
      { k: "isCampo", l: "Campo adicional da isenção", t: "text", lista: "campo:IMOVEIS" },
      { k: "isOpcao", l: "Opção que isenta", t: "text", half: true, lista: "opcao:isCampo" },
      { k: "isBenef", l: "Benefício fiscal (descrição)", t: "text", half: true }
    ] }
  ],
  padrao: { nome: "IPTU Territorial 2026", ano: 2026, credito: "IPTU", campo: "Valor Venal do Imóvel", receita: "I.T.", minimo: 0,
    faixas: [{ lim: 50000, aliq: 0.5 }, { lim: 150000, aliq: 0.8 }, { lim: "", aliq: 1 }], isCampo: "IMUNE/ISENTO IPTU", isOpcao: "Sim", isBenef: "Créditos tributários" },
  avisos(s) {
    const w = [], f = s.faixas || [];
    if (!f.length) w.push("Informe ao menos uma faixa.");
    let ant = -Infinity, aberta = false;
    f.forEach((r, i) => {
      const l = num(r.lim);
      if (num(r.aliq) === null) w.push(`Faixa ${i + 1}: alíquota vazia.`);
      if (aberta) w.push(`Faixa ${i + 1} vem depois de uma faixa sem limite e nunca será usada.`);
      if (l === null) aberta = true; else { if (l <= ant) w.push(`Faixa ${i + 1}: limites precisam estar em ordem crescente.`); ant = l; }
    });
    if (f.length && !aberta) w.push("A última faixa tem limite: valores acima dele suspendem o cálculo. Deixe o limite da última vazio se a lei não tiver teto.");
    if ((s.isCampo && !s.isOpcao) || (!s.isCampo && s.isOpcao)) w.push("Isenção incompleta: informe o campo e a opção.");
    return w;
  },
  gerar(s) {
    const f = s.faixas || [];
    const isento = s.isCampo && s.isOpcao;
    const minimo = num(s.minimo) > 0 ? num(s.minimo) : 0;
    const L = header(s, "Cálculo", s.credito, "alíquota por faixa sobre " + (s.campo || "a base de cálculo") + (minimo ? ", com valor mínimo" : "") + (isento ? ", com isenção por campo adicional" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push(`campoBase = ${q(s.campo)};`);
    L.push(`receita   = ${q(s.receita)};`);
    if (minimo) L.push(`vlMinimo  = ${fx(minimo)};`);
    L.push("// [limite superior da faixa em R$ (nulo = sem limite), alíquota em fração]");
    L.push("faixas = [");
    f.forEach((r, i) => {
      const l = num(r.lim), a = num(r.aliq) ?? 0;
      const linha = `  [${l === null ? "nulo" : fx(l)}, ${fx(a / 100, 3)}]` + (i < f.length - 1 ? "," : "");
      L.push(pad(linha, 30) + `// ${l === null ? "acima da faixa anterior" : "até R$ " + l.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}: ${a.toLocaleString("pt-BR")}%`);
    });
    L.push("];");
    if (isento) { L.push(`campoIsencao     = ${q(s.isCampo)};`); L.push(`opcaoIsencao     = ${q(s.isOpcao)};`); L.push(`beneficioIsencao = ${q(s.isBenef || "")};`); }
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Imovel " + imovel.codigo + " (" + ano + "): ";', "");
    L.push("vlBase = CamposAdicionais.valor(imovel, campoBase, ano);");
    L.push("se (vlBase == nulo) {");
    L.push('  suspender(ident + "campo " + campoBase + " sem valor.");');
    L.push("}");
    if (isento) L.push("", "ehIsento = (CamposAdicionais.valorOpcao(imovel, campoIsencao, opcaoIsencao, ano) ?: false);");
    L.push("", sec("CÁLCULO"));
    L.push("aliquota = nulo;");
    L.push("percorrer(faixas) { faixa ->");
    L.push("  se (aliquota == nulo && (faixa[0] == nulo || vlBase <= faixa[0])) {");
    L.push("    aliquota = faixa[1];");
    L.push("  }");
    L.push("}");
    L.push("se (aliquota == nulo) {");
    L.push('  suspender(ident + "valor " + vlBase + " acima da ultima faixa.");');
    L.push("}", "");
    L.push("vlImposto = vlBase * aliquota;");
    if (minimo) { L.push("se (vlImposto > 0 && vlImposto < vlMinimo) {", "  vlImposto = vlMinimo;", "}"); }
    L.push("", sec("RESULTADO"));
    L.push("vlImposto = Numeros.arredonda(vlImposto, 2);", "");
    L.push("se (vlImposto > 0) {");
    if (isento) {
      L.push("  se (ehIsento) {");
      L.push("    beneficio = Utilitarios.buscaBeneficioFiscal(beneficioIsencao);");
      L.push("    lancamento.criarReceita(receita, vlImposto, beneficio, 100);");
      L.push("  } senao {");
      L.push("    lancamento.criarReceita(receita, vlImposto);");
      L.push("  }");
    } else L.push("  lancamento.criarReceita(receita, vlImposto);");
    L.push("}");
    return L.join("\n");
  },
  notas: ["Se o campo da base for texto no cadastro, troque a leitura por Numeros.numero(...).", "A alíquota da faixa vale sobre o valor inteiro (não é progressiva por parcela de valor). Para progressão por degraus, peça na aba Revisar com IA."]
};

/* ---------- MODELO 4: receita diversa de valor fixo ---------- */
const mReceita = {
  id: "receita", titulo: "Receita diversa de valor fixo", sub: "Certidões, serviços e ressarcimentos: valor em indexador ou R$, opcionalmente por quantidade", tipo: "GERACAO_CREDITO · RECEITAS DIVERSAS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:RECEITAS_DIVERSAS" }] },
    { grupo: "Valores", itens: [
      { k: "sigla", l: "Indexador (vazio = valores em R$)", t: "text", half: true, lista: "indexador" },
      { k: "qtd", l: "Campo adicional de quantidade (opcional)", t: "text", half: true, lista: "campo:*" },
      { k: "recs", l: "Receitas e valores", t: "rows", cols: [["abrev", "Abreviatura", "receita:credito"], ["valor", "Valor"]] }
    ] }
  ],
  padrao: { nome: "Taxa de Certidão Negativa 2026", ano: 2026, credito: "CERT", sigla: "URM", qtd: "", recs: [{ abrev: "TXCERT", valor: 0.5 }, { abrev: "TXEXP", valor: 0.06 }] },
  avisos(s) {
    const w = [], r = (s.recs || []).filter(x => String(x.abrev || "").trim());
    if (!r.length) w.push("Informe ao menos uma receita.");
    r.forEach(x => { if (!(num(x.valor) > 0)) w.push(`Receita ${x.abrev}: valor vazio ou zero.`); });
    if (s.qtd) w.push("Quantidade por campo adicional: confirme no console que CamposAdicionais.valor aceita receitaDiversa nesta entidade.");
    return w;
  },
  gerar(s) {
    const r = (s.recs || []).filter(x => String(x.abrev || "").trim());
    const ind = String(s.sigla || "").trim();
    const L = header(s, "Cálculo", s.credito, "lança receitas de valor fixo" + (ind ? " em " + ind : " em R$") + (s.qtd ? ", multiplicadas pela quantidade informada" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    if (ind) L.push(`siglaIndexador = ${q(ind)};`);
    if (s.qtd) L.push(`campoQuantidade = ${q(s.qtd)};`);
    L.push(`// [abreviatura da receita, valor em ${ind || "R$"}]`);
    L.push("receitasFixas = [");
    r.forEach((x, i) => L.push(`  [${q(String(x.abrev).trim())}, ${fx(num(x.valor) ?? 0)}]` + (i < r.length - 1 ? "," : "")));
    L.push("];");
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Receita diversa " + receitaDiversa.codigo + " (" + ano + "): ";', "");
    if (ind) {
      L.push("vlIndexador = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
      L.push("se (vlIndexador == nulo || vlIndexador == 0) {");
      L.push('  suspender(ident + "valor do indexador " + siglaIndexador + " nao cadastrado para " + ano + ".");');
      L.push("}");
    } else L.push("vlIndexador = 1;  // valores já estão em R$");
    if (s.qtd) {
      L.push("", "quantidade = CamposAdicionais.valor(receitaDiversa, campoQuantidade, ano) ?: 0;");
      L.push("se (quantidade <= 0) {");
      L.push('  suspender(ident + "quantidade nao informada no campo " + campoQuantidade + ".");');
      L.push("}");
    } else L.push("quantidade = 1;");
    L.push("", sec("CÁLCULO"));
    L.push("// cada receita: valor do parâmetro x indexador x quantidade");
    L.push("valoresCalculados = [];");
    L.push("percorrer(receitasFixas) { rec ->");
    L.push("  valoresCalculados << [rec[0], rec[1] * vlIndexador * quantidade];");
    L.push("}");
    L.push("", sec("RESULTADO"));
    L.push("percorrer(valoresCalculados) { calc ->");
    L.push("  vlReceita = Numeros.arredonda(calc[1], 2);");
    L.push("  se (vlReceita > 0) {");
    L.push("    lancamento.criarReceita(calc[0], vlReceita);");
    L.push("  }");
    L.push("}");
    return L.join("\n");
  },
  notas: ["As abreviaturas precisam existir como receitas do crédito tributário."]
};




/* ---------- MODELO 5: IPTU completo (padrão Barão do Triunfo) ---------- */
const mIptu = {
  id: "iptu", titulo: "IPTU completo (venal + TCL + TLC)", sub: "Valor venal por setor e fatores de tabela, IPTU por alíquota, TCL por utilização, TLC e isenção", tipo: "GERACAO_CREDITO · IMOVEIS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:IMOVEIS" }, { k: "sigla", l: "Indexador", t: "text", half: true, lista: "indexador" }] },
    { grupo: "Campos adicionais lidos", itens: [
      { k: "cAreaTerreno", l: "Área do terreno", t: "text", lista: "campo:IMOVEIS" },
      { k: "cAreaUnidade", l: "Área da unidade", t: "text", lista: "campo:IMOVEIS" },
      { k: "cAreaTotal", l: "Área total da edificação", t: "text", lista: "campo:IMOVEIS" },
      { k: "cOcupacao", l: "Ocupação", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "oConstruido", l: "Opção \"construído\"", t: "text", half: true, lista: "opcao:cOcupacao" },
      { k: "cColeta", l: "Coleta de lixo", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "oColeta", l: "Opção que cobra", t: "text", half: true, lista: "opcao:cColeta" },
      { k: "cLimpeza", l: "Limpeza e conservação", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "oLimpeza", l: "Opção que cobra", t: "text", half: true, lista: "opcao:cLimpeza" },
      { k: "cUtilizacao", l: "Utilização do imóvel (define a TCL)", t: "text", lista: "campo:IMOVEIS" },
      { k: "cIsencao", l: "Isenção", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "oIsencao", l: "Opção que isenta", t: "text", half: true, lista: "opcao:cIsencao" }
    ] },
    { grupo: "Setor e valor do m² do terreno", itens: [
      { k: "setorCampo", l: "Setor lido de", t: "select", ops: [["campo1", "Inscrição imobiliária: campo 1"], ["campo2", "Inscrição imobiliária: campo 2"], ["campo3", "Inscrição imobiliária: campo 3"], ["campo4", "Inscrição imobiliária: campo 4"], ["setor", "imovel.setor"]] },
      { k: "setores", l: "Valor do m² do terreno por setor (decreto do exercício)", t: "rows", cols: [["setor", "Setor"], ["vl", "R$ por m²"]] }
    ] },
    { grupo: "Alíquotas do IPTU (%)", itens: [
      { k: "aTerrNaoConst", l: "Terreno, não construído", t: "number", half: true },
      { k: "aTerrConst", l: "Terreno, construído", t: "number", half: true },
      { k: "aPredio", l: "Prédio", t: "number", half: true }
    ] },
    { grupo: "Tabelas de cálculo (códigos)", itens: [
      { k: "tSituacao", l: "Situação", t: "number", half: true, lista: "tabela" },
      { k: "tPedologia", l: "Pedologia", t: "number", half: true, lista: "tabela" },
      { k: "tTopografia", l: "Topografia", t: "number", half: true, lista: "tabela" },
      { k: "tNivel", l: "Nível", t: "number", half: true, lista: "tabela" },
      { k: "tConservacao", l: "Conservação", t: "number", half: true, lista: "tabela" },
      { k: "tVlM2Predio", l: "Valor do m² do prédio", t: "number", half: true, lista: "tabela" },
      { k: "tPontuacao", l: "Tabelas somadas na pontuação (separe por vírgula)", t: "text" },
      { k: "divPontuacao", l: "Divisor da pontuação", t: "number", half: true }
    ] },
    { grupo: "Taxas", itens: [
      { k: "tcl", l: "TCL: utilização e fator em indexador (vale a primeira que bater)", t: "rows", cols: [["uso", "Utilização", "opcao:cUtilizacao"], ["fator", "Fator"]] },
      { k: "ocupColeta", l: "Ocupações que também pagam TCL, além de construído", t: "rows", cols: [["op", "Opção da ocupação", "opcao:cOcupacao"]] },
      { k: "fTlc", l: "TLC: fator em indexador", t: "number", half: true }
    ] },
    { grupo: "Receitas e benefício", itens: [
      { k: "rIT", l: "Imposto territorial", t: "text", half: true, lista: "receita:credito" },
      { k: "rIP", l: "Imposto predial", t: "text", half: true, lista: "receita:credito" },
      { k: "rTCL", l: "Coleta de lixo", t: "text", half: true, lista: "receita:credito" },
      { k: "rTLC", l: "Limpeza e conservação", t: "text", half: true, lista: "receita:credito" },
      { k: "benef", l: "Benefício fiscal da isenção", t: "text", half: true },
      { k: "percBenef", l: "% de concessão", t: "number", half: true }
    ] },
    { grupo: "Campos adicionais gravados (deixe vazio para não gravar)", itens: [
      { k: "gFracao", l: "Fração ideal", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gPontuacao", l: "Pontuação", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVVT", l: "Valor venal do terreno", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVVP", l: "Valor venal do prédio", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVVI", l: "Valor venal do imóvel", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVIT", l: "Valor imposto territorial", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVIP", l: "Valor imposto predial", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVIPTU", l: "Valor IPTU", t: "text", half: true, lista: "campo:IMOVEIS" }
    ] }
  ],
  padrao: {
    nome: "IPTU - Imposto Predial e Territorial Urbano", ano: 2026, credito: "IPTU", sigla: "URM",
    lei: "CTM art. 14 (alíquotas); Decreto nº ____/2025 (m² por setor); Lei nº ____ (TCL e TLC)",
    cAreaTerreno: "Área do Terreno", cAreaUnidade: "Área da Unidade", cAreaTotal: "Área Total da Edificação",
    cOcupacao: "OCUPAÇÃO", oConstruido: "Construido", cColeta: "COLETA DE LIXO", oColeta: "Sim",
    cLimpeza: "TAXA DE LIMPEZA E CONSERVAÇÃO", oLimpeza: "Sim", cUtilizacao: "UTILIZAÇÃO DO IMÓVEL",
    cIsencao: "IMUNE/ISENTO IPTU", oIsencao: "Sim",
    setorCampo: "campo2", setores: [{ setor: 1, vl: 6.10 }, { setor: 2, vl: 4.83 }, { setor: 3, vl: 3.41 }],
    aTerrNaoConst: 2, aTerrConst: 0.5, aPredio: 0.5,
    tSituacao: 122, tPedologia: 123, tTopografia: 124, tNivel: 125, tConservacao: 126, tVlM2Predio: 127,
    tPontuacao: "115, 116, 117, 118, 119, 120, 121", divPontuacao: 100,
    tcl: [{ uso: "Comercial/Serviço", fator: 0.12 }, { uso: "Industrial", fator: 0.17 }, { uso: "Terreno Sem Uso", fator: 0.084 }, { uso: "Residencial", fator: 0.084 }],
    ocupColeta: [{ op: "Ruínas" }, { op: "Em Demolição" }, { op: "Paralisada" }, { op: "Em Andamento" }],
    fTlc: 0.03, rIT: "I.T.", rIP: "I.P.", rTCL: "TCL", rTLC: "TLC", benef: "Créditos tributários", percBenef: 100,
    gFracao: "Fração Ideal", gPontuacao: "PONTUAÇÃO DO IMÓVEL", gVVT: "Valor Venal Terreno", gVVP: "Valor Venal Prédio",
    gVVI: "Valor Venal do Imóvel", gVIT: "Valor Imposto Territorial", gVIP: "Valor Imposto Predial", gVIPTU: "Valor IPTU"
  },
  avisos(s) {
    const w = [];
    ["cAreaTerreno", "cAreaUnidade", "cAreaTotal", "cOcupacao", "oConstruido"].forEach(k => { if (!String(s[k] || "").trim()) w.push("Preencha os campos adicionais de área e ocupação: são obrigatórios no cálculo."); });
    const st = (s.setores || []).filter(r => String(r.setor ?? "").trim() !== "");
    if (!st.length) w.push("Informe ao menos um setor com o valor do m².");
    const vistos = new Set(); st.forEach(r => { const k = String(r.setor).trim(); if (vistos.has(k)) w.push(`Setor ${k} repetido: vale o primeiro.`); vistos.add(k); if (!(num(r.vl) > 0)) w.push(`Setor ${k}: valor do m² vazio ou zero.`); });
    ["aTerrNaoConst", "aTerrConst", "aPredio"].forEach(k => { if (num(s[k]) === null) w.push("Alíquota vazia."); });
    ["tSituacao", "tPedologia", "tTopografia", "tNivel", "tConservacao", "tVlM2Predio"].forEach(k => { if (!Number.isInteger(num(s[k]))) w.push("Código de tabela de cálculo vazio ou não inteiro."); });
    const pts = String(s.tPontuacao || "").split(/[,;\s]+/).filter(Boolean);
    if (pts.some(x => !/^\d+$/.test(x))) w.push("Tabelas da pontuação: use só números separados por vírgula.");
    if (pts.length && !(num(s.divPontuacao) > 0)) w.push("Divisor da pontuação vazio ou zero.");
    ["rIT", "rIP", "rTCL", "rTLC"].forEach(k => { if (!String(s[k] || "").trim()) w.push("Informe as quatro abreviaturas de receita."); });
    if (s.cIsencao && !s.benef) w.push("Isenção sem descrição do benefício fiscal.");
    if (num(s.aTerrConst) !== null && num(s.aTerrNaoConst) !== null && num(s.aTerrConst) !== num(s.aTerrNaoConst))
      w.push(`Confira no CTM: imóvel construído paga ${num(s.aTerrConst).toLocaleString("pt-BR")}% sobre o venal do terreno e não construído ${num(s.aTerrNaoConst).toLocaleString("pt-BR")}%.`);
    return [...new Set(w)];
  },
  gerar(s) {
    const L = header(s, "Cálculo", s.credito, "calcula o valor venal (terreno + prédio), o IPTU, a TCL e a TLC e lança as receitas " + [s.rIT, s.rIP, s.rTCL, s.rTLC].join(", "));
    const st = (s.setores || []).filter(r => String(r.setor ?? "").trim() !== "");
    const pts = String(s.tPontuacao || "").split(/[,;\s]+/).filter(x => /^\d+$/.test(x));
    const setorNumerico = st.length > 0 && st.every(r => /^\d+$/.test(String(r.setor).trim()));
    const tcl = (s.tcl || []).filter(r => String(r.uso || "").trim());
    const ocs = (s.ocupColeta || []).map(r => String(r.op || "").trim()).filter(Boolean);
    const temIsencao = s.cIsencao && s.oIsencao;
    const tab = k => Number.isInteger(num(s[k])) ? num(s[k]) : 0;
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push(`siglaIndexador = ${q(s.sigla || "URM")};`, "");
    L.push("// [setor tributário, valor do m² do terreno em R$] (decreto do exercício)");
    L.push("valoresM2Terreno = [");
    st.forEach((r, i) => L.push(`  [${setorNumerico ? num(r.setor) : q(String(r.setor).trim())}, ${fx(num(r.vl) ?? 0)}]` + (i < st.length - 1 ? "," : "")));
    L.push("];", "");
    L.push("// alíquotas do IPTU");
    L.push(`aliqTerrenoNaoConstruido = ${fx(num(s.aTerrNaoConst) / 100, 3)};  // ${num(s.aTerrNaoConst)}% sobre o venal do terreno, imóvel não construído`);
    L.push(`aliqTerrenoConstruido    = ${fx(num(s.aTerrConst) / 100, 3)};  // ${num(s.aTerrConst)}% sobre o venal do terreno, imóvel construído`);
    L.push(`aliqPredio               = ${fx(num(s.aPredio) / 100, 3)};  // ${num(s.aPredio)}% sobre o venal do prédio`, "");
    L.push("// códigos das tabelas de cálculo desta entidade");
    L.push(`tabSituacao    = ${tab("tSituacao")};`, `tabPedologia   = ${tab("tPedologia")};`, `tabTopografia  = ${tab("tTopografia")};`, `tabNivel       = ${tab("tNivel")};`, `tabConservacao = ${tab("tConservacao")};`, `tabVlM2Predio  = ${tab("tVlM2Predio")};`);
    L.push(`tabelasPontuacao = [${pts.join(", ")}];  // soma = pontuação`);
    L.push(`divisorPontuacao = ${fx(num(s.divPontuacao) || 100, 1)};  // pontuação ÷ divisor = fator do prédio`, "");
    L.push(`// Taxa de Coleta de Lixo: fator em ${s.sigla || "URM"} conforme a utilização (vale a primeira que bater)`);
    L.push("fatoresTcl = [");
    tcl.forEach((r, i) => L.push(`  [${q(String(r.uso).trim())}, ${fx(num(r.fator) ?? 0, 2)}]` + (i < tcl.length - 1 ? "," : "")));
    L.push("];");
    L.push(`// além de ${q(s.oConstruido)}, estas ocupações também pagam TCL`);
    L.push(`ocupacoesComColeta = [${ocs.map(q).join(", ")}];`, "");
    L.push(`fatorTlc = ${fx(num(s.fTlc) ?? 0, 2)};  // Taxa de Limpeza e Conservação, em ${s.sigla || "URM"}`, "");
    if (temIsencao) { L.push(`beneficioIsencao = ${q(s.benef)};`, `percIsencao      = ${num(s.percBenef) ?? 100};`, ""); }
    L.push("// nomes dos campos adicionais e receitas");
    L.push(`campoAreaTerreno = ${q(s.cAreaTerreno)};`, `campoAreaUnidade = ${q(s.cAreaUnidade)};`, `campoAreaTotal   = ${q(s.cAreaTotal)};`);
    L.push(`campoOcupacao    = ${q(s.cOcupacao)};`, `opcaoConstruido  = ${q(s.oConstruido)};`);
    L.push(`campoColeta      = ${q(s.cColeta)};`, `opcaoColeta      = ${q(s.oColeta)};`);
    L.push(`campoLimpeza     = ${q(s.cLimpeza)};`, `opcaoLimpeza     = ${q(s.oLimpeza)};`);
    L.push(`campoUtilizacao  = ${q(s.cUtilizacao)};`);
    if (temIsencao) L.push(`campoIsencao     = ${q(s.cIsencao)};`, `opcaoIsencao     = ${q(s.oIsencao)};`);
    L.push(`receitaIT  = ${q(s.rIT)};`, `receitaIP  = ${q(s.rIP)};`, `receitaTCL = ${q(s.rTCL)};`, `receitaTLC = ${q(s.rTLC)};`);

    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Imovel " + imovel.codigo + " (exercicio " + ano + "): ";', "");
    L.push("vlUrm = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
    L.push("se (vlUrm == nulo || vlUrm == 0) {", '  suspender(ident + "valor do indexador " + siglaIndexador + " nao foi informado para o exercicio " + ano + ".");', "}", "");
    L.push("areaTerreno     = CamposAdicionais.valor(imovel, campoAreaTerreno, ano) ?: 0;");
    L.push("areaUnidade     = CamposAdicionais.valor(imovel, campoAreaUnidade, ano) ?: 0;");
    L.push("areaTotalPredio = CamposAdicionais.valor(imovel, campoAreaTotal, ano) ?: 0;", "");
    L.push("ehConstruido = (CamposAdicionais.valorOpcao(imovel, campoOcupacao, opcaoConstruido, ano) ?: false);", "");
    L.push("se (ehConstruido) {");
    L.push("  se (areaTotalPredio == 0) {", '    suspender(ident + "Area Total da Edificacao deve ser maior que zero para calcular a fracao ideal.");', "  }");
    L.push("  se (areaUnidade == 0) {", '    suspender(ident + "Area da Unidade nao informada para imovel construido.");', "  }");
    L.push("}", "");
    if (s.setorCampo === "setor") {
      L.push("// setor lido de imovel.setor");
      L.push("setorTxt = \"\";", "se (imovel.setor != nulo) {", "  setorTxt = \"\" + imovel.setor;", "}");
    } else {
      L.push(`// setor lido do ${s.setorCampo} da inscrição imobiliária; imovel.setor é a segunda opção`);
      L.push("setorTxt = \"\";");
      L.push(`se (imovel.inscricaoImobiliaria != nulo && imovel.inscricaoImobiliaria.${s.setorCampo} != nulo) {`, `  setorTxt = "" + imovel.inscricaoImobiliaria.${s.setorCampo};`, "}");
      L.push("se (setorTxt == \"\" && imovel.setor != nulo) {", "  setorTxt = \"\" + imovel.setor;", "}");
    }
    if (setorNumerico) {
      L.push("// setor numérico: \"01\" e \"1\" valem o mesmo setor");
      L.push("setor = nulo;", "se (setorTxt != \"\" && Numeros.ehNumero(setorTxt)) {", "  setor = Numeros.numero(setorTxt);", "}", "");
      L.push("vlM2Terreno = nulo;");
      L.push("percorrer(valoresM2Terreno) { faixa ->");
      L.push("  se (vlM2Terreno == nulo && setor != nulo && setor == faixa[0]) {", "    vlM2Terreno = faixa[1];", "  }");
      L.push("}");
    } else {
      L.push("", "vlM2Terreno = nulo;");
      L.push("percorrer(valoresM2Terreno) { faixa ->");
      L.push("  se (vlM2Terreno == nulo && setorTxt == faixa[0]) {", "    vlM2Terreno = faixa[1];", "  }");
      L.push("}");
    }
    L.push("se (vlM2Terreno == nulo) {", `  suspender(ident + "Setor tributario '" + setorTxt + "' sem valor do m2 (esperado ${st.map(r => String(r.setor).trim()).join(", ")}).");`, "}", "");
    L.push("// fatores corretivos do terreno: obrigatórios para todo imóvel");
    L.push("fatorSituacao   = tabelasCalculos.getValor(ano, tabSituacao,   imovel.codigo);");
    L.push("fatorPedologia  = tabelasCalculos.getValor(ano, tabPedologia,  imovel.codigo);");
    L.push("fatorTopografia = tabelasCalculos.getValor(ano, tabTopografia, imovel.codigo);");
    L.push("fatorNivel      = tabelasCalculos.getValor(ano, tabNivel,      imovel.codigo);", "");
    L.push("faltando = \"\";");
    L.push('se (fatorSituacao   == nulo) { faltando = faltando + " Situacao(" + tabSituacao + ")"; }');
    L.push('se (fatorPedologia  == nulo) { faltando = faltando + " Pedologia(" + tabPedologia + ")"; }');
    L.push('se (fatorTopografia == nulo) { faltando = faltando + " Topografia(" + tabTopografia + ")"; }');
    L.push('se (fatorNivel      == nulo) { faltando = faltando + " Nivel(" + tabNivel + ")"; }');
    L.push("se (faltando != \"\") {", '  suspender(ident + "Fatores do terreno sem valor na tabela de calculo:" + faltando);', "}", "");
    L.push("// fatores do prédio: só exigidos quando o imóvel é construído");
    L.push("vlM2Predio = 0;", "fatorConservacao = 0;", "pontos = 0;");
    L.push("se (ehConstruido) {");
    L.push("  vlM2Predio       = tabelasCalculos.getValor(ano, tabVlM2Predio,  imovel.codigo);");
    L.push("  fatorConservacao = tabelasCalculos.getValor(ano, tabConservacao, imovel.codigo);", "");
    L.push("  faltando = \"\";");
    L.push('  se (vlM2Predio       == nulo) { faltando = faltando + " Valor m2 Predio(" + tabVlM2Predio + ")"; }');
    L.push('  se (fatorConservacao == nulo) { faltando = faltando + " Conservacao(" + tabConservacao + ")"; }');
    L.push("  se (faltando != \"\") {", '    suspender(ident + "Fatores do predio sem valor na tabela de calculo:" + faltando);', "  }", "");
    L.push("  // item da pontuação ausente conta como 0 ponto");
    L.push("  percorrer(tabelasPontuacao) { codTabela ->", "    pontos = pontos + (tabelasCalculos.getValor(ano, codTabela, imovel.codigo) ?: 0);", "  }");
    L.push("}", "");
    L.push("// dados das taxas e da isenção");
    L.push("temOcupacaoComColeta = ehConstruido;");
    L.push("percorrer(ocupacoesComColeta) { ocupacao ->", "  se (CamposAdicionais.valorOpcao(imovel, campoOcupacao, ocupacao, ano) ?: false) {", "    temOcupacaoComColeta = true;", "  }", "}");
    L.push("temColetaLixo = (CamposAdicionais.valorOpcao(imovel, campoColeta, opcaoColeta, ano) ?: false);");
    L.push("temLimpeza    = (CamposAdicionais.valorOpcao(imovel, campoLimpeza, opcaoLimpeza, ano) ?: false);");
    L.push(temIsencao ? "ehIsento      = (CamposAdicionais.valorOpcao(imovel, campoIsencao, opcaoIsencao, ano) ?: false);" : "ehIsento      = false;  // sem campo de isenção configurado");

    L.push("", sec("CÁLCULO"));
    L.push("// fração ideal: construído divide o terreno pela participação da unidade no prédio");
    L.push("fracaoIdeal = areaTerreno;", "se (ehConstruido) {", "  fracaoIdeal = (areaTerreno * areaUnidade) / areaTotalPredio;", "}", "");
    L.push("vlVenalTerreno = fracaoIdeal * vlM2Terreno * fatorSituacao * fatorPedologia * fatorTopografia * fatorNivel;", "");
    L.push("vlVenalPredio = 0;", "se (ehConstruido) {", "  // usa \"pontos\" direto, sem reler o campo gravado nesta mesma execução", "  fatorPontuacao = pontos / divisorPontuacao;", "  vlVenalPredio  = vlM2Predio * areaUnidade * fatorConservacao * fatorPontuacao;", "}", "");
    L.push("vlVenalImovel = vlVenalTerreno + vlVenalPredio;", "");
    L.push("// IPTU; \"vlIT\" e não \"it\", que é reservado no BFC-Script (Groovy)");
    L.push("vlIT = 0;", "vlIP = 0;", "se (ehConstruido) {", "  vlIT = vlVenalTerreno * aliqTerrenoConstruido;", "  vlIP = vlVenalPredio * aliqPredio;", "} senao {", "  vlIT = vlVenalTerreno * aliqTerrenoNaoConstruido;", "}", "vlIptu = vlIT + vlIP;", "");
    L.push("// TCL: precisa de coleta e de uma ocupação que gere lixo; vale a primeira utilização que bater");
    L.push("vlTCL = 0;", "se (temColetaLixo && temOcupacaoComColeta) {", "  fatorTclAplicado = nulo;", "  percorrer(fatoresTcl) { faixa ->",
      "    se (fatorTclAplicado == nulo && (CamposAdicionais.valorOpcao(imovel, campoUtilizacao, faixa[0], ano) ?: false)) {", "      fatorTclAplicado = faixa[1];", "    }", "  }",
      "  se (fatorTclAplicado != nulo) {", "    vlTCL = fatorTclAplicado * vlUrm;", "  }", "}", "");
    L.push("vlTLC = 0;", "se (temLimpeza) {", "  vlTLC = fatorTlc * vlUrm;", "}");

    L.push("", sec("RESULTADO"));
    const grav = [["gFracao", "fracaoIdeal", true], ["gVVT", "vlVenalTerreno"], ["gPontuacao", "pontos", true], ["gVVP", "vlVenalPredio"], ["gVVI", "vlVenalImovel"], ["gVIT", "vlIT"], ["gVIP", "vlIP"], ["gVIPTU", "vlIptu"]]
      .filter(g => String(s[g[0]] || "").trim());
    if (grav.length) {
      L.push("// campos adicionais gravados para consulta no cadastro (valores sem arredondar)");
      grav.forEach(([k, v, soConstruido]) => {
        const linha = `CamposAdicionais.preencherCampoAdicional(imovel, ${q(s[k])}, ${v}, ano);`;
        if (soConstruido) L.push("se (ehConstruido) {", "  " + linha, "}"); else L.push(linha);
      });
      L.push("");
    }
    L.push("// arredondamento e garantia final contra nulo");
    L.push("vlIT  = Numeros.arredonda(vlIT  ?: 0, 2);", "vlIP  = Numeros.arredonda(vlIP  ?: 0, 2);", "vlTCL = Numeros.arredonda(vlTCL ?: 0, 2);", "vlTLC = Numeros.arredonda(vlTLC ?: 0, 2);", "");
    L.push("// só cria receita com valor > 0");
    if (temIsencao) {
      L.push("se (ehIsento) {", "  beneficio = Utilitarios.buscaBeneficioFiscal(beneficioIsencao);",
        "  se (vlIT  > 0) { lancamento.criarReceita(receitaIT,  vlIT,  beneficio, percIsencao); }",
        "  se (vlIP  > 0) { lancamento.criarReceita(receitaIP,  vlIP,  beneficio, percIsencao); }",
        "  se (vlTCL > 0) { lancamento.criarReceita(receitaTCL, vlTCL, beneficio, percIsencao); }",
        "  se (vlTLC > 0) { lancamento.criarReceita(receitaTLC, vlTLC, beneficio, percIsencao); }", "} senao {");
      ["IT", "IP", "TCL", "TLC"].forEach(r => L.push(`  se (vl${r}${" ".repeat(3 - r.length + 1)}> 0) { lancamento.criarReceita(receita${r}, vl${r}); }`));
      L.push("}");
    } else ["IT", "IP", "TCL", "TLC"].forEach(r => L.push(`se (vl${r} > 0) { lancamento.criarReceita(receita${r}, vl${r}); }`));
    return L.join("\n");
  },
  notas: ["Modelo baseado no IPTU de Barão do Triunfo (registro 511404). Com os valores padrão, o resultado é o mesmo da fórmula em produção.", "Setores só com números são comparados como número, como na fórmula original (\"01\" = 1). Com letras, a comparação é pelo texto exato.", "Teste o percorrer da pontuação numa simulação: se a pontuação vier 0 num imóvel com pontos, avise."]
};

function hl(code) {
  return code.split("\n").map(line => {
    const ci = line.indexOf("//");
    let body = ci >= 0 ? line.slice(0, ci) : line, com = ci >= 0 ? line.slice(ci) : "";
    if (/^\s*\/?\*/.test(line)) { body = ""; com = line; }
    let out = esc(body).replace(/(&quot;[^&]*?&quot;|"[^"]*")/g, '<span class="s">$1</span>')
      .replace(/\b(se|senao|percorrer|retornar|suspender|nulo|imprimir)\b/g, '<span class="k">$1</span>');
    return out + (com ? `<span class="c">${esc(com)}</span>` : "");
  }).join("\n");
}
window.GF = { MODELOS: [mIptu, mDesconto, mEnquadramento, mFaixas, mReceita], hl, esc, num, hoje };
})();
