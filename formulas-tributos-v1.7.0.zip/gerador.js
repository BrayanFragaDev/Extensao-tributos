/* Gerador de fórmulas — modelos e utilidades (sem DOM). */
(function () {
"use strict";
/* ---------- utilidades ---------- */
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const q = s => '"' + String(s ?? "").replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
const num = v => { const n = parseFloat(String(v).replace(",", ".")); return isNaN(n) ? null : n; };
function fx(n, min = 2, max = 6) {            // número BFC: ponto decimal, ao menos 2 casas
  if (n === null || n === undefined) return "nulo";
  let s = Number(n).toFixed(max).replace(/0+$/, "");
  const [i, d = ""] = s.split(".");
  return i + "." + (d + "0".repeat(min)).slice(0, Math.max(min, d.length));
}
const frac = p => fx(num(p) === null ? 0 : num(p) / 100);
const pad = (s, n) => (s + " ".repeat(n)).slice(0, Math.max(n, s.length));
const hoje = () => { const d = new Date(); return [d.getDate(), d.getMonth() + 1, d.getFullYear()].map((x, i) => i < 2 ? String(x).padStart(2, "0") : x).join("/"); };

function header(s, tipo, credito, oQueFaz) {
  return [
    "// ============================================================",
    "// " + (s.nome || "FÓRMULA").toUpperCase(),
    "// Tipo      : " + tipo + " | Crédito: " + (credito || "____") + " | Exercício: " + (s.ano || "____"),
    "// O que faz : " + oQueFaz,
    "// Base legal: " + (s.lei || "Lei nº ____/____, art. __"),
    "// Histórico : " + hoje() + " - " + (s.autor || "<nome>") + " - " + (s.motivo || "criação pelo gerador"),
    "// ============================================================",
    ""
  ];
}
const sec = t => "// ---------- " + t + " ----------";

/* ---------- campos comuns ---------- */
const comuns = [
  { k: "nome", l: "Nome da fórmula", t: "text" },
  { k: "ano", l: "Exercício", t: "number", half: true },
  { k: "autor", l: "Seu nome (histórico)", t: "text", half: true },
  { k: "lei", l: "Base legal", t: "text", ph: "Lei nº 857/2026, art. 3º" },
  { k: "motivo", l: "Motivo da alteração (histórico)", t: "text", ph: "criação pelo gerador" }
];

/* ---------- MODELO 1: desconto de parcelamento ---------- */
const mDesconto = {
  id: "desconto", titulo: "Desconto de parcelamento / REFIS", sub: "Desconto em juros, multa, correção e tributo por faixa de parcelas", tipo: "DESCONTO_PARCELAMENTO",
  campos: [
    { grupo: "Identificação", itens: comuns },
    { grupo: "Regra", itens: [
      { k: "base", l: "Desconto calculado sobre", t: "select", ops: [["total", "Totais da dívida/lançamento (vlTotalJuros...)"], ["parcelar", "Só o que está sendo parcelado (vlTotalJurosParcelar...)"]] },
      { k: "faixas", l: "Faixas de parcelas (percentuais de desconto)", t: "rows", cols: [["de", "Parcelas de"], ["ate", "até"], ["j", "% juros"], ["m", "% multa"], ["c", "% correção"], ["t", "% tributo"]] },
      { k: "limite", l: "Adesão válida até (opcional)", t: "date" }
    ] }
  ],
  padrao: { nome: "REFIS 2026", ano: 2026, base: "total", lei: "", limite: "",
    faixas: [{ de: 1, ate: 1, j: 100, m: 100, c: 0, t: 0 }, { de: 2, ate: 12, j: 80, m: 80, c: 0, t: 0 }, { de: 13, ate: 60, j: 50, m: 50, c: 0, t: 0 }] },
  avisos(s) {
    const w = [], f = (s.faixas || []).map(r => ({ de: num(r.de), ate: num(r.ate) })).filter(r => r.de !== null && r.ate !== null).sort((a, b) => a.de - b.de);
    if (!f.length) w.push("Informe ao menos uma faixa de parcelas.");
    f.forEach((r, i) => {
      if (r.de > r.ate) w.push(`Faixa ${r.de}–${r.ate}: "de" é maior que "até".`);
      if (i && r.de <= f[i - 1].ate) w.push(`Faixas ${f[i - 1].de}–${f[i - 1].ate} e ${r.de}–${r.ate} se sobrepõem: vale a que aparece primeiro na lista.`);
      if (i && r.de > f[i - 1].ate + 1) w.push(`Buraco entre ${f[i - 1].ate} e ${r.de} parcelas: nessas quantidades não há desconto.`);
    });
    (s.faixas || []).forEach(r => ["j", "m", "c", "t"].forEach(k => { const v = num(r[k]); if (v !== null && (v < 0 || v > 100)) w.push("Percentual fora de 0 a 100 numa faixa."); }));
    return [...new Set(w)];
  },
  gerar(s) {
    const b = s.base === "parcelar"
      ? { t: "vlTotalLancadoParcelar", c: "vlTotalCorrecaoParcelar", m: "vlTotalMultaParcelar", j: "vlTotalJurosParcelar" }
      : { t: "vlTotalLancado", c: "vlTotalCorrecao", m: "vlTotalMulta", j: "vlTotalJuros" };
    const rows = (s.faixas || []).filter(r => num(r.de) !== null && num(r.ate) !== null);
    const L = header(s, "Desconto para parcelamentos", "todos", "desconto sobre juros, multa, correção e tributo conforme o nº de parcelas");
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push("// Cada faixa: [parcelas de, parcelas até, desc. juros, desc. multa, desc. correção, desc. tributo]");
    L.push("// Percentuais em fração: 0.95 = 95% de desconto sobre o valor.");
    L.push("faixasDesconto = [");
    rows.forEach((r, i) => {
      const linha = `  [${num(r.de)}, ${num(r.ate)}, ${frac(r.j)}, ${frac(r.m)}, ${frac(r.c)}, ${frac(r.t)}]` + (i < rows.length - 1 ? "," : "");
      L.push(pad(linha, 46) + `// ${num(r.de) === num(r.ate) ? num(r.de) + (num(r.de) === 1 ? " parcela (à vista)" : " parcelas") : num(r.de) + " a " + num(r.ate) + " parcelas"}`);
    });
    L.push("];");
    const lim = s.limite ? s.limite.split("-").map(Number) : null;
    if (lim) L.push(`dtFimAdesao = Datas.data(${lim[0]}, ${lim[1]}, ${lim[2]});  // último dia para aderir com desconto`);
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push(`// Base: ${s.base === "parcelar" ? "somente os valores que estão sendo parcelados" : "totais da dívida ou do lançamento do exercício"}.`);
    L.push("faixaAplicada = nulo;");
    L.push("percorrer(faixasDesconto) { faixa ->");
    L.push("  se (faixaAplicada == nulo && qtdParcelas >= faixa[0] && qtdParcelas <= faixa[1]) {");
    L.push("    faixaAplicada = faixa;");
    L.push("  }");
    L.push("}");
    if (lim) {
      L.push("// fora do prazo de adesão não há desconto (compara com o dia seguinte ao limite, porque hoje() traz a hora)");
      L.push("se (Datas.hoje() >= Datas.adicionaDias(dtFimAdesao, 1)) {");
      L.push("  faixaAplicada = nulo;");
      L.push("}");
    }
    L.push("", sec("CÁLCULO"));
    L.push("descontoTributo  = 0.00;", "descontoCorrecao = 0.00;", "descontoMulta    = 0.00;", "descontoJuros    = 0.00;", "");
    L.push("// quantidade de parcelas fora das faixas: sem desconto");
    L.push("se (faixaAplicada != nulo) {");
    L.push(`  descontoJuros    = ${b.j} * faixaAplicada[2];`);
    L.push(`  descontoMulta    = ${b.m} * faixaAplicada[3];`);
    L.push(`  descontoCorrecao = ${b.c} * faixaAplicada[4];`);
    L.push(`  descontoTributo  = ${b.t} * faixaAplicada[5];`);
    L.push("}");
    L.push("", sec("RESULTADO"));
    L.push("descontoTributo  = Numeros.arredonda(descontoTributo, 2);", "descontoCorrecao = Numeros.arredonda(descontoCorrecao, 2);", "descontoMulta    = Numeros.arredonda(descontoMulta, 2);", "descontoJuros    = Numeros.arredonda(descontoJuros, 2);", "");
    L.push("retornar TRIBUTO: descontoTributo, CORRECAO: descontoCorrecao, MULTA: descontoMulta, JUROS: descontoJuros;");
    return L.join("\n");
  },
  notas: ["Lembre de ativar a configuração de desconto no parcelamento: sem ela, a fórmula não é usada.", "A variável atribuída dentro do percorrer vale fora dele. Na primeira vez, confira com imprimir faixaAplicada no console."]
};

/* ---------- MODELO 2: taxa por enquadramento (econômicos) ---------- */
const mEnquadramento = {
  id: "enquadramento", titulo: "Taxa por enquadramento (econômicos)", sub: "Alvará, licença, fiscalização: fator em URM conforme opção de campo adicional", tipo: "GERACAO_CREDITO · ECONOMICOS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:ECONOMICOS" }] },
    { grupo: "Enquadramento", itens: [
      { k: "campo", l: "Campo adicional do econômico", t: "text", lista: "campo:ECONOMICOS" },
      { k: "sigla", l: "Indexador", t: "text", half: true, lista: "indexador" },
      { k: "receita", l: "Receita da taxa", t: "text", half: true, lista: "receita:credito" },
      { k: "enq", l: "Opções e fator (quantas vezes o indexador, por ano)", t: "rows", cols: [["op", "Opção do campo", "opcao:campo"], ["fator", "Fator"]] }
    ] },
    { grupo: "Regras opcionais", itens: [
      { k: "prop", l: "Proporcional aos meses a partir do início da atividade", t: "check" },
      { k: "receitaInicio", l: "Receita diferente no ano de início (ex.: alvará × fiscalização)", t: "text", ph: "deixe vazio para usar sempre a mesma", lista: "receita:credito" },
      { k: "mei", l: "MEI não paga (suspende o cálculo)", t: "check" },
      { k: "exp", l: "Taxa de expediente (% do indexador, 0 = não cobra)", t: "number", half: true },
      { k: "receitaExp", l: "Receita da taxa de expediente", t: "text", half: true, lista: "receita:credito" }
    ] }
  ],
  padrao: { nome: "Taxa de Licença e Fiscalização 2026", ano: 2026, credito: "ALVAR", campo: "TX LICENÇA/FISCALIZAÇÃO", sigla: "URM", receita: "TXFIS", receitaInicio: "TXALV",
    enq: [{ op: "101", fator: 0.9 }, { op: "102", fator: 1.5 }, { op: "103", fator: 3 }, { op: "105", fator: 2 }, { op: "108", fator: 1 }],
    prop: true, mei: true, exp: 6, receitaExp: "TXEXP" },
  avisos(s) {
    const w = [], ops = (s.enq || []).map(r => String(r.op || "").trim()).filter(Boolean);
    if (!ops.length) w.push("Informe ao menos uma opção de enquadramento.");
    if (new Set(ops).size !== ops.length) w.push("Há opção repetida na tabela: vale a primeira.");
    (s.enq || []).forEach(r => { if (String(r.op || "").trim() && !(num(r.fator) > 0)) w.push(`Opção ${r.op}: fator vazio ou zero.`); });
    if (!s.campo) w.push("Informe o nome do campo adicional exatamente como no cadastro, com acentos.");
    if (!s.receita) w.push("Informe a abreviatura da receita.");
    if (num(s.exp) > 0 && !s.receitaExp) w.push("Taxa de expediente sem abreviatura de receita.");
    return w;
  },
  gerar(s) {
    const rows = (s.enq || []).filter(r => String(r.op || "").trim());
    const exp = num(s.exp) > 0;
    const L = header(s, "Cálculo", s.credito, "taxa anual em " + (s.sigla || "URM") + " conforme o enquadramento do econômico" + (s.prop ? ", proporcional aos meses de atividade no ano de início" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push(`siglaIndexador     = ${q(s.sigla || "URM")};`);
    L.push(`campoEnquadramento = ${q(s.campo)};`);
    L.push(`receitaTaxa        = ${q(s.receita)};`);
    if (s.prop && s.receitaInicio) L.push(`receitaAnoInicio   = ${q(s.receitaInicio)};  // usada quando a atividade começou no próprio exercício`);
    if (exp) { L.push(`percTaxaExpediente = ${frac(s.exp)};  // ${num(s.exp)}% do indexador`); L.push(`receitaExpediente  = ${q(s.receitaExp)};`); }
    L.push("// [opção do campo de enquadramento, fator em " + (s.sigla || "URM") + " por ano]");
    L.push("enquadramentos = [");
    rows.forEach((r, i) => L.push(`  [${q(String(r.op).trim())}, ${fx(num(r.fator) ?? 0, 1)}]` + (i < rows.length - 1 ? "," : "")));
    L.push("];");
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Economico " + economico.codigo + " (" + ano + "): ";');
    L.push("// em econômicos o campo adicional é lido por data, não por ano (com o ano dá erro 793)", "dtBaseCampos = dataBase ?: Datas.data(ano, 1, 1);", "");
    if (s.mei) {
      L.push("// confirme com imprimir o valor que o porte devolve nesta entidade");
      L.push("porte = \"\" + economico.porteDaEmpresa;");
      L.push('se (porte == "MEI" || porte == "MICROEMPREENDEDOR_INDIVIDUAL") {');
      L.push('  suspender(ident + "MEI nao paga esta taxa.");');
      L.push("}", "");
    }
    L.push("vlIndexador = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
    L.push("se (vlIndexador == nulo || vlIndexador == 0) {");
    L.push('  suspender(ident + "valor do indexador " + siglaIndexador + " nao cadastrado para " + ano + ".");');
    L.push("}", "");
    L.push("fatorIndexador = 0;");
    L.push("percorrer(enquadramentos) { opcao ->");
    L.push("  se (fatorIndexador == 0 && (CamposAdicionais.valorOpcao(economico, campoEnquadramento, opcao[0], dtBaseCampos) ?: false)) {");
    L.push("    fatorIndexador = opcao[1];");
    L.push("  }");
    L.push("}");
    L.push("se (fatorIndexador == 0) {");
    L.push('  suspender(ident + "enquadramento nao informado no campo " + campoEnquadramento + ".");');
    L.push("}");
    if (s.prop) {
      L.push("", "dtInicio = economico.dataInicioOuReinicio;");
      L.push("se (dtInicio == nulo) {");
      L.push('  suspender(ident + "data de inicio ou reinicio da atividade nao informada.");');
      L.push("}");
      L.push("ehAnoInicio = (Datas.ano(dtInicio) == ano);");
    }
    L.push("", sec("CÁLCULO"));
    if (s.prop) {
      L.push("// ano de início: cobra do mês de início até dezembro; demais anos: 12 meses");
      L.push("mesesDevidos = 12;");
      L.push("se (ehAnoInicio) {");
      L.push("  mesesDevidos = 13 - Datas.mes(dtInicio);");
      L.push("}");
      L.push("vlTaxa = ((vlIndexador * fatorIndexador) / 12) * mesesDevidos;");
    } else {
      L.push("vlTaxa = vlIndexador * fatorIndexador;");
    }
    if (exp) L.push("vlExpediente = vlIndexador * percTaxaExpediente;");
    if (s.prop && s.receitaInicio) {
      L.push("", "receitaLancar = receitaTaxa;");
      L.push("se (ehAnoInicio) {");
      L.push("  receitaLancar = receitaAnoInicio;");
      L.push("}");
    }
    L.push("", sec("RESULTADO"));
    L.push("vlTaxa = Numeros.arredonda(vlTaxa, 2);");
    if (exp) L.push("vlExpediente = Numeros.arredonda(vlExpediente, 2);");
    L.push("");
    L.push(`lancamento.criarReceita(${s.prop && s.receitaInicio ? "receitaLancar" : "receitaTaxa"}, vlTaxa);`);
    if (exp) { L.push("se (vlExpediente > 0) {", "  lancamento.criarReceita(receitaExpediente, vlExpediente);", "}"); }
    return L.join("\n");
  },
  notas: ["O nome do campo adicional e das opções tem de ser idêntico ao cadastro, inclusive acentos e espaços.", "Confira se a data de início deve vir de economico.dataInicioOuReinicio ou de um campo adicional, como em algumas migrações."]
};

/* ---------- MODELO 3: faixas de valor (imóveis) ---------- */
const mFaixas = {
  id: "faixas", titulo: "Imposto ou taxa por faixas de valor (imóveis)", sub: "Alíquota conforme a faixa do valor de um campo adicional, com mínimo e isenção", tipo: "GERACAO_CREDITO · IMOVEIS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:IMOVEIS" }] },
    { grupo: "Base e faixas", itens: [
      { k: "campo", l: "Campo adicional com a base de cálculo", t: "text", lista: "campo:IMOVEIS" },
      { k: "receita", l: "Receita lançada", t: "text", half: true, lista: "receita:credito" },
      { k: "minimo", l: "Valor mínimo em R$ (0 = sem mínimo)", t: "number", half: true },
      { k: "faixas", l: "Faixas (limite vazio = sem limite; use na última)", t: "rows", cols: [["lim", "Até (R$)"], ["aliq", "Alíquota %"]] }
    ] },
    { grupo: "Isenção (opcional)", itens: [
      { k: "isCampo", l: "Campo adicional da isenção", t: "text", lista: "campo:IMOVEIS" },
      { k: "isOpcao", l: "Opção que isenta", t: "text", half: true, lista: "opcao:isCampo" },
      { k: "isBenef", l: "Benefício fiscal (descrição)", t: "text", half: true }
    ] }
  ],
  padrao: { nome: "IPTU Territorial 2026", ano: 2026, credito: "IPTU", campo: "Valor Venal do Imóvel", receita: "I.T.", minimo: 0,
    faixas: [{ lim: 50000, aliq: 0.5 }, { lim: 150000, aliq: 0.8 }, { lim: "", aliq: 1 }], isCampo: "IMUNE/ISENTO IPTU", isOpcao: "Sim", isBenef: "Créditos tributários" },
  avisos(s) {
    const w = [], f = s.faixas || [];
    if (!f.length) w.push("Informe ao menos uma faixa.");
    let ant = -Infinity, aberta = false;
    f.forEach((r, i) => {
      const l = num(r.lim);
      if (num(r.aliq) === null) w.push(`Faixa ${i + 1}: alíquota vazia.`);
      if (aberta) w.push(`Faixa ${i + 1} vem depois de uma faixa sem limite e nunca será usada.`);
      if (l === null) aberta = true; else { if (l <= ant) w.push(`Faixa ${i + 1}: limites precisam estar em ordem crescente.`); ant = l; }
    });
    if (f.length && !aberta) w.push("A última faixa tem limite: valores acima dele suspendem o cálculo. Deixe o limite da última vazio se a lei não tiver teto.");
    if ((s.isCampo && !s.isOpcao) || (!s.isCampo && s.isOpcao)) w.push("Isenção incompleta: informe o campo e a opção.");
    return w;
  },
  gerar(s) {
    const f = s.faixas || [];
    const isento = s.isCampo && s.isOpcao;
    const minimo = num(s.minimo) > 0 ? num(s.minimo) : 0;
    const L = header(s, "Cálculo", s.credito, "alíquota por faixa sobre " + (s.campo || "a base de cálculo") + (minimo ? ", com valor mínimo" : "") + (isento ? ", com isenção por campo adicional" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push(`campoBase = ${q(s.campo)};`);
    L.push(`receita   = ${q(s.receita)};`);
    if (minimo) L.push(`vlMinimo  = ${fx(minimo)};`);
    L.push("// [limite superior da faixa em R$ (nulo = sem limite), alíquota em fração]");
    L.push("faixas = [");
    f.forEach((r, i) => {
      const l = num(r.lim), a = num(r.aliq) ?? 0;
      const linha = `  [${l === null ? "nulo" : fx(l)}, ${fx(a / 100, 3)}]` + (i < f.length - 1 ? "," : "");
      L.push(pad(linha, 30) + `// ${l === null ? "acima da faixa anterior" : "até R$ " + l.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}: ${a.toLocaleString("pt-BR")}%`);
    });
    L.push("];");
    if (isento) { L.push(`campoIsencao     = ${q(s.isCampo)};`); L.push(`opcaoIsencao     = ${q(s.isOpcao)};`); L.push(`beneficioIsencao = ${q(s.isBenef || "")};`); }
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Imovel " + imovel.codigo + " (" + ano + "): ";', "");
    L.push("vlBase = CamposAdicionais.valor(imovel, campoBase, ano);");
    L.push("se (vlBase == nulo) {");
    L.push('  suspender(ident + "campo " + campoBase + " sem valor.");');
    L.push("}");
    if (isento) L.push("", "ehIsento = (CamposAdicionais.valorOpcao(imovel, campoIsencao, opcaoIsencao, ano) ?: false);");
    L.push("", sec("CÁLCULO"));
    L.push("aliquota = nulo;");
    L.push("percorrer(faixas) { faixa ->");
    L.push("  se (aliquota == nulo && (faixa[0] == nulo || vlBase <= faixa[0])) {");
    L.push("    aliquota = faixa[1];");
    L.push("  }");
    L.push("}");
    L.push("se (aliquota == nulo) {");
    L.push('  suspender(ident + "valor " + vlBase + " acima da ultima faixa.");');
    L.push("}", "");
    L.push("vlImposto = vlBase * aliquota;");
    if (minimo) { L.push("se (vlImposto > 0 && vlImposto < vlMinimo) {", "  vlImposto = vlMinimo;", "}"); }
    L.push("", sec("RESULTADO"));
    L.push("vlImposto = Numeros.arredonda(vlImposto, 2);", "");
    L.push("se (vlImposto > 0) {");
    if (isento) {
      L.push("  se (ehIsento) {");
      L.push("    beneficio = Utilitarios.buscaBeneficioFiscal(beneficioIsencao);");
      L.push("    lancamento.criarReceita(receita, vlImposto, beneficio, 100);");
      L.push("  } senao {");
      L.push("    lancamento.criarReceita(receita, vlImposto);");
      L.push("  }");
    } else L.push("  lancamento.criarReceita(receita, vlImposto);");
    L.push("}");
    return L.join("\n");
  },
  notas: ["Se o campo da base for texto no cadastro, troque a leitura por Numeros.numero(...).", "A alíquota da faixa vale sobre o valor inteiro (não é progressiva por parcela de valor). Para progressão por degraus, peça na aba Revisar com IA."]
};

/* ---------- MODELO 4: receita diversa de valor fixo ---------- */
const mReceita = {
  id: "receita", titulo: "Receita diversa de valor fixo", sub: "Certidões, serviços e ressarcimentos: valor em indexador ou R$, opcionalmente por quantidade", tipo: "GERACAO_CREDITO · RECEITAS DIVERSAS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:RECEITAS_DIVERSAS" }] },
    { grupo: "Valores", itens: [
      { k: "sigla", l: "Indexador (vazio = valores em R$)", t: "text", half: true, lista: "indexador" },
      { k: "qtd", l: "Campo adicional de quantidade (opcional)", t: "text", half: true, lista: "campo:*" },
      { k: "recs", l: "Receitas e valores", t: "rows", cols: [["abrev", "Abreviatura", "receita:credito"], ["valor", "Valor"]] }
    ] }
  ],
  padrao: { nome: "Taxa de Certidão Negativa 2026", ano: 2026, credito: "CERT", sigla: "URM", qtd: "", recs: [{ abrev: "TXCERT", valor: 0.5 }, { abrev: "TXEXP", valor: 0.06 }] },
  avisos(s) {
    const w = [], r = (s.recs || []).filter(x => String(x.abrev || "").trim());
    if (!r.length) w.push("Informe ao menos uma receita.");
    r.forEach(x => { if (!(num(x.valor) > 0)) w.push(`Receita ${x.abrev}: valor vazio ou zero.`); });
    if (s.qtd) w.push("Quantidade por campo adicional: confirme no console que CamposAdicionais.valor aceita receitaDiversa nesta entidade.");
    return w;
  },
  gerar(s) {
    const r = (s.recs || []).filter(x => String(x.abrev || "").trim());
    const ind = String(s.sigla || "").trim();
    const L = header(s, "Cálculo", s.credito, "lança receitas de valor fixo" + (ind ? " em " + ind : " em R$") + (s.qtd ? ", multiplicadas pela quantidade informada" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    if (ind) L.push(`siglaIndexador = ${q(ind)};`);
    if (s.qtd) L.push(`campoQuantidade = ${q(s.qtd)};`);
    L.push(`// [abreviatura da receita, valor em ${ind || "R$"}]`);
    L.push("receitasFixas = [");
    r.forEach((x, i) => L.push(`  [${q(String(x.abrev).trim())}, ${fx(num(x.valor) ?? 0)}]` + (i < r.length - 1 ? "," : "")));
    L.push("];");
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Receita diversa " + receitaDiversa.codigo + " (" + ano + "): ";', "");
    if (ind) {
      L.push("vlIndexador = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
      L.push("se (vlIndexador == nulo || vlIndexador == 0) {");
      L.push('  suspender(ident + "valor do indexador " + siglaIndexador + " nao cadastrado para " + ano + ".");');
      L.push("}");
    } else L.push("vlIndexador = 1;  // valores já estão em R$");
    if (s.qtd) {
      L.push("", "quantidade = CamposAdicionais.valor(receitaDiversa, campoQuantidade, ano) ?: 0;");
      L.push("se (quantidade <= 0) {");
      L.push('  suspender(ident + "quantidade nao informada no campo " + campoQuantidade + ".");');
      L.push("}");
    } else L.push("quantidade = 1;");
    L.push("", sec("CÁLCULO"));
    L.push("// cada receita: valor do parâmetro x indexador x quantidade");
    L.push("valoresCalculados = [];");
    L.push("percorrer(receitasFixas) { rec ->");
    L.push("  valoresCalculados << [rec[0], rec[1] * vlIndexador * quantidade];");
    L.push("}");
    L.push("", sec("RESULTADO"));
    L.push("percorrer(valoresCalculados) { calc ->");
    L.push("  vlReceita = Numeros.arredonda(calc[1], 2);");
    L.push("  se (vlReceita > 0) {");
    L.push("    lancamento.criarReceita(calc[0], vlReceita);");
    L.push("  }");
    L.push("}");
    return L.join("\n");
  },
  notas: ["As abreviaturas precisam existir como receitas do crédito tributário."]
};

/* ---------- Cidadão Web: acréscimos em 3 scripts (correção, juros e multa) ---------- */
// Tipos de script do Cidadão Web (Cadastros > Scripts), lidos em Barão em nov/2026
const CW_TIPOS = {
  DIVIDA_ATIVA: { correcao: "12 - Cálculo de correções (lanctos, dívidas e acordos)", juros: "18 - Cálculo de juros para dívidas", multa: "19 - Cálculo de multa para dívidas" },
  DEBITO:       { correcao: "12 - Cálculo de correções (lanctos, dívidas e acordos)", juros: "10 - Cálculo de juros para lançamentos", multa: "11 - Cálculo de multa para lançamentos" },
  PARCELAMENTO: { correcao: "12 - Cálculo de correções (lanctos, dívidas e acordos)", juros: "16 - Cálculo de juros para acordos", multa: "17 - Cálculo de multa para acordos" }
};
function gerarCidadaoWeb(s) {
  const t = CW_TIPOS[s.tipoLanc] || CW_TIPOS.DIVIDA_ATIVA;
  const cods = String(s.semAcrescimoCod || "").split(",").map(x => x.trim()).filter(x => /^\d+$/.test(x));
  const faixas = (s.multaFaixas || []).filter(r => num(r.perc) !== null);
  const sigla = String(s.siglaCorrecao || "URM").trim() || "URM";
  const cab = (titulo, tipo, oQue) => [
    "// ============================================================",
    "// " + titulo.toUpperCase() + " - CIDADÃO WEB",
    "// Tipo do script: " + tipo,
    "// O que faz : " + oQue,
    "// Base legal: " + (s.lei || "Lei nº ____/____, art. __"),
    "// Histórico : " + hoje() + " - " + (s.autor || "<nome>") + " - " + (s.motivo || "gerado a partir da regra do Cloud"),
    "// ============================================================",
    ""
  ];
  const vencUtil = () => {
    const L = ["dtVencUtil = dtVencto;"];
    if (s.diaUtil) {
      L.push("// vencimento em sábado, domingo ou feriado passa para o próximo dia útil");
      L.push("percorrer (enquanto: { Datas.diaSemana(dtVencUtil) == 1 || Datas.diaSemana(dtVencUtil) == 7 || Feriados.ehFeriado(dtVencUtil) != 'N' }) {");
      L.push("  dtVencUtil = Datas.adicionaDias(dtVencUtil, 1);");
      L.push("}");
    }
    return L;
  };
  const isento = () => cods.length ? [
    "// receitas sem juros e multa (código da receita)",
    `codigosSemAcrescimo = [${cods.join(", ")}];`,
    "semAcrescimo = false;",
    "percorrer(codigosSemAcrescimo) { cod ->",
    "  se (codSubRec == cod || tipoReceita == cod) {",
    "    semAcrescimo = true;",
    "  }",
    "}"
  ] : ["semAcrescimo = false;"];
  const out = [];

  // 1) correção
  const C = cab("Correção monetária", t.correcao, s.modoCorrecao === "nenhuma" ? "sem correção (devolve zero)" : "correção pela variação da " + sigla + " do vencimento até o pagamento");
  C.push(sec("PARÂMETROS (altere somente aqui)"));
  if (s.modoCorrecao !== "nenhuma") {
    C.push(`siglaCorrecao = ${q(sigla)};`);
    C.push("", sec("ENTRADAS E VALIDAÇÕES"));
    C.push("vlIndiceVencimento = IndexadoresUtil.valorIndexador(siglaCorrecao, dtVencto) ?: 0;");
    C.push("vlIndicePagamento  = IndexadoresUtil.valorIndexador(siglaCorrecao, dtPagto) ?: 0;");
    C.push("", sec("CÁLCULO"));
    C.push("vlCorrecao = 0;");
    C.push("se (vlIndiceVencimento > 0 && vlIndicePagamento > 0) {");
    C.push("  // valor em R$ atualizado pela variação do índice");
    C.push("  vlCorrecao = (vlDevido / vlIndiceVencimento) * vlIndicePagamento - vlDevido;");
    C.push("}");
    C.push("se (vlCorrecao < 0) {", "  vlCorrecao = 0;", "}");
  } else {
    C.push("// sem parâmetros", "", sec("ENTRADAS E VALIDAÇÕES"), "// sem entradas", "", sec("CÁLCULO"), "vlCorrecao = 0;");
  }
  C.push("", sec("RESULTADO"), "vlCorrecao = Numeros.arredonda(vlCorrecao, 2);", "retornar valorCorrecao: vlCorrecao;");
  out.push(C.join("\n"));

  // 2) juros
  const J = cab("Juros de mora", t.juros, `${num(s.juroMes) ?? 0}% ao mês ${s.contagem === "fracao" ? "ou fração" : s.contagem === "cheiosMin1" ? "(meses cheios, mínimo 1)" : "(meses cheios)"}`);
  J.push(sec("PARÂMETROS (altere somente aqui)"));
  J.push(pad(`juroAoMes = ${frac(s.juroMes)};`, 40) + `// ${num(s.juroMes) ?? 0}% ao mês`);
  J.push("", sec("ENTRADAS E VALIDAÇÕES"));
  J.push(...vencUtil(), ...isento());
  J.push("", sec("CÁLCULO"));
  J.push("qtdMeses = 0;");
  J.push("se (dtPagto > dtVencUtil) {");
  J.push("  // diferencaMeses conta meses do calendário: ajusta pelo dia do vencimento");
  J.push("  qtdMeses = Datas.diferencaMeses(dtVencUtil, dtPagto);");
  if (s.contagem === "fracao") J.push("  se (Datas.adicionaMeses(dtVencUtil, qtdMeses) < dtPagto) {", "    qtdMeses = qtdMeses + 1;  // fração de mês conta como mês inteiro", "  }");
  else {
    J.push("  se (Datas.adicionaMeses(dtVencUtil, qtdMeses) > dtPagto) {", "    qtdMeses = qtdMeses - 1;  // o último mês ainda não completou", "  }");
    if (s.contagem === "cheiosMin1") J.push("  se (qtdMeses == 0) {", "    qtdMeses = 1;  // vencido há menos de um mês: cobra 1 mês", "  }");
  }
  J.push("}");
  J.push(`vlBase = vlDevido${s.base === "original" ? "" : " + (vlCorrecaoCalc ?: 0)"};  // valor ${s.base === "original" ? "original" : "corrigido"}`);
  J.push("vlJuros = 0;");
  J.push("se (!semAcrescimo && vlBase > 0) {", "  vlJuros = vlBase * qtdMeses * juroAoMes;", "}");
  J.push("", sec("RESULTADO"), "vlJuros = Numeros.arredonda(vlJuros, 2);", "retornar valorJuros: vlJuros;");
  out.push(J.join("\n"));

  // 3) multa
  const M = cab("Multa de mora", t.multa, s.modoMulta === "faixas" ? "multa por faixa de dias de atraso" : `${num(s.multaDia) ?? 0}% ao dia, teto de ${num(s.multaTeto) ?? 0}%`);
  M.push(sec("PARÂMETROS (altere somente aqui)"));
  if (s.modoMulta === "faixas") {
    M.push("// [atraso até (dias), multa]  nulo = sem limite; vale a primeira faixa que couber");
    M.push("faixasMulta = [");
    faixas.forEach((r, i) => M.push(pad(`  [${num(r.ate) === null ? "nulo" : num(r.ate)}, ${frac(r.perc)}]` + (i < faixas.length - 1 ? "," : ""), 40) + `// ${num(r.perc)}%` + (num(r.ate) === null ? " acima disso" : " até " + num(r.ate) + " dias")));
    M.push("];");
  } else {
    M.push(pad(`multaAoDia = ${frac(s.multaDia)};`, 40) + `// ${num(s.multaDia) ?? 0}% por dia de atraso`);
    M.push(pad(`multaTeto = ${frac(s.multaTeto)};`, 40) + `// teto de ${num(s.multaTeto) ?? 0}%`);
  }
  M.push("", sec("ENTRADAS E VALIDAÇÕES"));
  M.push(...vencUtil(), ...isento());
  M.push("", sec("CÁLCULO"));
  M.push("qtdDias = 0;", "se (dtPagto > dtVencUtil) {", "  qtdDias = Datas.diferencaDias(dtVencUtil, dtPagto);", "}");
  M.push("percMulta = 0;");
  if (s.modoMulta === "faixas") {
    M.push("se (qtdDias > 0) {", "  multaDefinida = false;", "  percorrer(faixasMulta) { faixa ->",
      "    se (!multaDefinida && (faixa[0] == nulo || qtdDias <= faixa[0])) {", "      percMulta = faixa[1];", "      multaDefinida = true;", "    }", "  }", "}");
  } else {
    M.push("se (qtdDias > 0) {", "  percMulta = multaAoDia * qtdDias;", "  se (percMulta > multaTeto) {", "    percMulta = multaTeto;", "  }", "}");
  }
  M.push(`vlBase = vlDevido${s.base === "original" ? "" : " + (vlCorrecaoCalc ?: 0)"};  // valor ${s.base === "original" ? "original" : "corrigido"}`);
  M.push("vlMulta = 0;", "se (!semAcrescimo && vlBase > 0) {", "  vlMulta = vlBase * percMulta;", "}");
  M.push("", sec("RESULTADO"), "vlMulta = Numeros.arredonda(vlMulta, 2);", "retornar valorMulta: vlMulta;");
  out.push(M.join("\n"));

  const sep = n => "\n\n// ####################################################################\n// ##### SCRIPT " + n + " DE 3 - cole somente o bloco abaixo no tipo indicado #####\n// ####################################################################\n\n";
  return sep(1).trimStart() + out[0] + sep(2) + out[1] + sep(3) + out[2];
}

/* ---------- MODELO 6: acréscimos moratórios (correção, juros e multa) ---------- */
const mAcrescimos = {
  id: "acrescimos", titulo: "Acréscimos moratórios (correção, juros e multa)", sub: "Dívida ativa, débito ou parcelamento: correção por indexador, juros ao mês e multa por atraso", tipo: "ACRESCIMO · calculo-acrescimos",
  campos: [
    { grupo: "Identificação", itens: [...comuns,
      { k: "tipoLanc", l: "Aplica-se a (tipo de lançamento da fórmula)", t: "select", ops: [["DIVIDA_ATIVA", "Dívida ativa"], ["DEBITO", "Débito (lançamento do exercício)"], ["PARCELAMENTO", "Parcelamento"]] },
      { k: "creditos", l: "Créditos (vazio = todos)", t: "text", ph: "todos" },
      { k: "destino", l: "Gerar para", t: "select", ops: [["cloud", "Tributos Cloud (uma fórmula de acréscimos)"], ["cidadao", "Cidadão Web (3 scripts: correção, juros e multa)"]] }
    ] },
    { grupo: "Correção monetária", itens: [
      { k: "modoCorrecao", l: "Correção", t: "select", ops: [["indicePadrao", "Pelo indexador da dívida; se estiver em R$, pelo índice abaixo"], ["soIndexador", "Só quando a dívida está em indexador (R$ fica sem correção)"], ["nenhuma", "Não calcular correção (mantém a do sistema)"]] },
      { k: "siglaCorrecao", l: "Índice de correção para dívidas em R$", t: "text", half: true, ph: "URM", lista: "indexador" }
    ] },
    { grupo: "Juros", itens: [
      { k: "juroMes", l: "% de juros ao mês", t: "number", half: true, ph: "1" },
      { k: "contagem", l: "Contagem dos meses", t: "select", half: true, ops: [["fracao", "Mês ou fração (fração conta mês inteiro)"], ["cheios", "Só meses cheios"], ["cheiosMin1", "Meses cheios, mínimo 1 quando vencido"]] },
      { k: "diaUtil", l: "Vencimento em dia não útil passa para o próximo dia útil", t: "check" }
    ] },
    { grupo: "Multa", itens: [
      { k: "modoMulta", l: "Tipo de multa", t: "select", ops: [["faixas", "Por faixa de dias de atraso"], ["diaria", "% ao dia, com teto"]] },
      { k: "multaFaixas", l: "Faixas (por faixa de dias): última com 'até' vazio = sem limite", t: "rows", cols: [["ate", "Atraso até (dias)"], ["perc", "% de multa"]] },
      { k: "multaDia", l: "% ao dia (multa diária)", t: "number", half: true, ph: "0.33" },
      { k: "multaTeto", l: "Teto da multa diária (%)", t: "number", half: true, ph: "20" }
    ] },
    { grupo: "Base e exceções", itens: [
      { k: "base", l: "Juros e multa calculados sobre", t: "select", ops: [["corrigido", "Valor corrigido (valor + correção − deduções)"], ["original", "Valor original (valor − deduções)"]] },
      { k: "semAcrescimo", l: "Créditos sem juros e multa (abreviaturas separadas por vírgula)", t: "text", ph: "TCE, DHE" },
      { k: "semAcrescimoCod", l: "Cidadão Web: códigos de receita sem juros e multa (separados por vírgula)", t: "text", ph: "1301, 2301" },
      { k: "depurar", l: "Imprimir índices e resultado na aba Logs (desligar depois de validar)", t: "check" }
    ] }
  ],
  padrao: {},
  avisos(s) {
    const w = [];
    if (num(s.juroMes) === null) w.push("Informe o % de juros ao mês (0 se não houver).");
    if (s.modoCorrecao === "indicePadrao" && !String(s.siglaCorrecao || "").trim()) w.push("Informe o índice de correção para dívidas em R$ (ex.: URM).");
    if (s.modoMulta === "faixas") {
      const f = (s.multaFaixas || []).filter(r => num(r.perc) !== null);
      if (!f.length) w.push("Informe ao menos uma faixa de multa.");
      f.forEach((r, i) => { if (num(r.ate) === null && i < f.length - 1) w.push("Só a última faixa de multa pode ficar com 'até' vazio."); });
      for (let i = 1; i < f.length; i++) if (num(f[i].ate) !== null && num(f[i - 1].ate) !== null && num(f[i].ate) <= num(f[i - 1].ate)) w.push("As faixas de multa precisam estar em ordem crescente de dias.");
      if (f.length && num(f[f.length - 1].ate) !== null) w.push(`Atraso acima de ${num(f[f.length - 1].ate)} dias fica sem multa: deixe o 'até' da última faixa vazio se a lei não tem limite.`);
    } else if (num(s.multaDia) === null) w.push("Informe o % de multa ao dia.");
    if (s.modoCorrecao !== "nenhuma") w.push("A correção usa o último valor do índice até cada data: se faltar um ano no cadastro do índice, vale o do ano anterior.");
    if (s.tipoLanc === "PARCELAMENTO" && s.destino !== "cidadao") w.push("Parcelamento: confira no catálogo (aba Variáveis) se as receitas trazem remissao e anistiaTributo.");
    if (s.destino === "cidadao") {
      w.push("Cidadão Web: cole cada script no tipo indicado no cabeçalho (Cadastros > Scripts) e teste com Executar antes de marcar Disponível = Sim.");
      if (String(s.semAcrescimo || "").trim() && !String(s.semAcrescimoCod || "").trim()) w.push("Cidadão Web identifica a receita por código: informe os códigos de receita sem juros e multa (abreviaturas não valem lá).");
      if (s.modoCorrecao === "soIndexador") w.push("Cidadão Web não informa o indexador da dívida ao script: a correção sai pelo índice informado acima.");
    }
    return [...new Set(w)];
  },
  gerar(s) {
    if (s.destino === "cidadao") return gerarCidadaoWeb(s);
    const tipoTxt = { DIVIDA_ATIVA: "DIVIDA_ATIVA", DEBITO: "DEBITO", PARCELAMENTO: "PARCELAMENTO" }[s.tipoLanc] || "DIVIDA_ATIVA";
    const credTxt = String(s.creditos || "").trim() || "todos";
    const L = header(s, "Acréscimos (calculo-acrescimos) | tipoLancamento: " + tipoTxt, credTxt, "correção monetária, juros de mora e multa sobre cada receita vencida");
    const isentos = String(s.semAcrescimo || "").split(",").map(x => x.trim()).filter(Boolean);
    const faixas = (s.multaFaixas || []).filter(r => num(r.perc) !== null);
    const deducao = s.tipoLanc === "DEBITO" ? "(receita.beneficio ?: 0)" : "(receita.remissao ?: 0) - (receita.anistiaTributo ?: 0)";
    const textoDeducao = s.tipoLanc === "DEBITO" ? "benefício" : "remissão e anistia";

    L.push(sec("PARÂMETROS (altere somente aqui)"));
    if (s.modoCorrecao === "indicePadrao") L.push(pad(`siglaCorrecaoPadrao = ${q(String(s.siglaCorrecao).trim())};`, 40) + "// índice de correção quando a dívida está em moeda corrente");
    L.push(pad(`juroAoMes = ${frac(s.juroMes)};`, 40) + `// ${num(s.juroMes) ?? 0}% ao mês`);
    if (s.modoMulta === "faixas") {
      L.push("// [atraso até (dias), multa]  nulo = sem limite; vale a primeira faixa que couber");
      L.push("faixasMulta = [");
      faixas.forEach((r, i) => L.push(pad(`  [${num(r.ate) === null ? "nulo" : num(r.ate)}, ${frac(r.perc)}]` + (i < faixas.length - 1 ? "," : ""), 40) + `// ${num(r.perc)}%` + (num(r.ate) === null ? " acima disso" : " até " + num(r.ate) + " dias")));
      L.push("];");
    } else {
      L.push(pad(`multaAoDia = ${frac(s.multaDia)};`, 40) + `// ${num(s.multaDia) ?? 0}% por dia de atraso`);
      L.push(pad(`multaTeto = ${frac(s.multaTeto)};`, 40) + `// teto de ${num(s.multaTeto) ?? 0}%`);
    }
    L.push(`creditosSemAcrescimo = [${isentos.map(q).join(", ")}];  // abreviaturas sem juros e multa`);
    L.push(`depurar = ${s.depurar ? "true" : "false"};`);

    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push("dtVencimento = dataVencimento;");
    if (s.diaUtil) {
      L.push("// vencimento em sábado, domingo ou feriado passa para o próximo dia útil");
      L.push("// (não usa Utilitarios.proximoDiaUtil: no teste do editor ele devolve a data de hoje)");
      L.push("percorrer(de: 1, ate: 10) { tentativa ->");
      L.push("  feriado = (\"\" + Utilitarios.ehFeriado(dtVencimento)) == \"true\" || (\"\" + Utilitarios.ehFeriado(dtVencimento)) == \"1\";");
      L.push("  se (Datas.diaSemana(dtVencimento) == 1 || Datas.diaSemana(dtVencimento) == 7 || feriado) {");
      L.push("    dtVencimento = Datas.adicionaDias(dtVencimento, 1);");
      L.push("  }");
      L.push("}");
    }
    if (s.modoCorrecao !== "nenhuma") {
      L.push("ehMoedaCorrente = (indexador == nulo) || indexador.ehMoedaCorrente();");
      if (s.modoCorrecao === "indicePadrao") {
        L.push("siglaCorrecao = siglaCorrecaoPadrao;", "se (!ehMoedaCorrente) {", "  siglaCorrecao = indexador.sigla;", "}");
      } else {
        L.push('siglaCorrecao = "";', "se (!ehMoedaCorrente) {", "  siglaCorrecao = indexador.sigla;", "}");
      }
      L.push("indiceNoVencimento = 0;", "indiceNaDataBase = 0;");
      L.push('se (siglaCorrecao != "") {');
      L.push("  indiceNoVencimento = Utilitarios.buscaValorIndexadorPorSiglaEData(siglaCorrecao, dataVencimento) ?: 0;");
      L.push("  indiceNaDataBase   = Utilitarios.buscaValorIndexadorPorSiglaEData(siglaCorrecao, dataBase) ?: 0;");
      L.push("}");
    }
    L.push("semAcrescimo = false;");
    L.push("percorrer(creditosSemAcrescimo) { abrev ->");
    L.push("  se (creditoTributario.abreviatura == abrev) {", "    semAcrescimo = true;", "  }", "}");
    L.push("se (depurar) {");
    L.push('  imprimir "Credito: " + creditoTributario.abreviatura + " | indexador: " + (indexador?.sigla ?: "nulo") + " | vencimento: " + dtVencimento + " | data base: " + dataBase;');
    if (s.modoCorrecao !== "nenhuma") L.push('  imprimir "Correcao por " + siglaCorrecao + ": " + indiceNoVencimento + " -> " + indiceNaDataBase;');
    L.push("}");

    L.push("", sec("CÁLCULO"));
    if (s.modoCorrecao !== "nenhuma") {
      L.push("// 1) correção monetária, do vencimento até a data base; nunca negativa");
      L.push("percorrer(receitas) { receita ->");
      L.push("  vlCorrecao = 0;");
      L.push("  se (indiceNoVencimento > 0 && indiceNaDataBase > 0) {");
      L.push("    se (ehMoedaCorrente) {");
      L.push("      // valor em R$: atualiza pela variação do índice");
      L.push("      vlCorrecao = receita.valor * (indiceNaDataBase / indiceNoVencimento) - receita.valor;");
      L.push("    } senao {");
      L.push("      // valor em quantidade do indexador: converte nas duas datas");
      L.push("      vlCorrecao = receita.valor * indiceNaDataBase - receita.valor * indiceNoVencimento;");
      L.push("    }");
      L.push("  }");
      L.push("  se (vlCorrecao < 0) {", "    vlCorrecao = 0;", "  }");
      L.push("  receita.comCorrecao(Numeros.arredonda(vlCorrecao, 2));");
      L.push("}", "");
    }
    L.push(`// ${s.modoCorrecao !== "nenhuma" ? 2 : 1}) prazo de atraso: meses para juros, dias para multa`);
    L.push("qtdMeses = 0;", "qtdDias = 0;");
    L.push("se (dataBase > dtVencimento) {");
    L.push("  qtdDias = Datas.diferencaDias(dtVencimento, dataBase);");
    L.push("  // diferencaMeses conta meses do calendário (31/10 a 01/11 = 1): ajusta pelo dia do vencimento");
    L.push("  qtdMeses = Datas.diferencaMeses(dtVencimento, dataBase);");
    if (s.contagem !== "fracao") {
      L.push("  se (Datas.adicionaMeses(dtVencimento, qtdMeses) > dataBase) {", "    qtdMeses = qtdMeses - 1;  // o último mês ainda não completou", "  }");
    }
    if (s.contagem === "fracao") {
      L.push("  se (Datas.adicionaMeses(dtVencimento, qtdMeses) < dataBase) {", "    qtdMeses = qtdMeses + 1;  // fração de mês conta como mês inteiro", "  }");
    } else if (s.contagem === "cheiosMin1") {
      L.push("  se (qtdMeses == 0) {", "    qtdMeses = 1;  // vencido há menos de um mês: cobra 1 mês", "  }");
    }
    L.push("}", "");
    L.push(`// ${s.modoCorrecao !== "nenhuma" ? 3 : 2}) percentual de multa pelo atraso`);
    L.push("percMulta = 0;");
    if (s.modoMulta === "faixas") {
      L.push("se (qtdDias > 0) {");
      L.push("  multaDefinida = false;");
      L.push("  percorrer(faixasMulta) { faixa ->");
      L.push("    se (!multaDefinida && (faixa[0] == nulo || qtdDias <= faixa[0])) {");
      L.push("      percMulta = faixa[1];", "      multaDefinida = true;", "    }", "  }", "}");
    } else {
      L.push("se (qtdDias > 0) {", "  percMulta = multaAoDia * qtdDias;", "  se (percMulta > multaTeto) {", "    percMulta = multaTeto;", "  }", "}");
    }

    L.push("", sec("RESULTADO"));
    L.push(`// juros e multa sobre o valor ${s.base === "original" ? "original" : "corrigido"}, já deduzidos ${textoDeducao}`);
    L.push("percorrer(receitas) { receita ->");
    L.push(`  vlBase = receita.valor${s.base === "original" ? "" : " + (receita.correcao ?: 0)"} - ${deducao};`);
    L.push("  se (semAcrescimo || vlBase <= 0) {");
    L.push("    receita.comJuro(0);", "    receita.comMulta(0);");
    L.push("  } senao {");
    L.push("    receita.comJuro(Numeros.arredonda(vlBase * qtdMeses * juroAoMes, 2));");
    L.push("    receita.comMulta(Numeros.arredonda(vlBase * percMulta, 2));");
    L.push("  }");
    L.push("  se (depurar) {");
    L.push('    imprimir receita.abreviatura + ": valor " + receita.valor + " | correcao " + receita.correcao + " | juros " + receita.juro + " | multa " + receita.multa;');
    L.push("  }");
    L.push("}");
    return L.join("\n");
  },
  notas: ["Validado em Barão do Triunfo (dívida ativa, URM, 1% ao mês ou fração, multa 10/20/30%).", "Gerar para Cidadão Web: a mesma regra sai em 3 scripts (correção, juros e multa), cada um com o tipo de script do Cidadão Web no cabeçalho. Variáveis de lá: vlDevido, vlCorrecaoCalc, dtVencto, dtPagto, IndexadoresUtil, Feriados.", "Uma fórmula por tipo de lançamento: dívida ativa, débito e parcelamento são cadastrados separados em Acréscimos.", "Teste no botão Executar do editor e, depois de salvar, confira o resumo de um contribuinte com dívida antiga."]
};

/* ---------- MODELO 5: IPTU completo (padrão Barão do Triunfo) ---------- */
const mIptu = {
  id: "iptu", titulo: "IPTU completo (venal + TCL + TLC)", sub: "Valor venal por setor e fatores de tabela, IPTU por alíquota, TCL por utilização, TLC e isenção", tipo: "GERACAO_CREDITO · IMOVEIS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:IMOVEIS" }, { k: "sigla", l: "Indexador", t: "text", half: true, lista: "indexador" }] },
    { grupo: "Campos adicionais lidos", itens: [
      { k: "cAreaTerreno", l: "Área do terreno", t: "text", lista: "campo:IMOVEIS" },
      { k: "cAreaUnidade", l: "Área da unidade", t: "text", lista: "campo:IMOVEIS" },
      { k: "cAreaTotal", l: "Área total da edificação", t: "text", lista: "campo:IMOVEIS" },
      { k: "cOcupacao", l: "Ocupação", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "oConstruido", l: "Opção \"construído\"", t: "text", half: true, lista: "opcao:cOcupacao" },
      { k: "cColeta", l: "Coleta de lixo", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "oColeta", l: "Opção que cobra", t: "text", half: true, lista: "opcao:cColeta" },
      { k: "cLimpeza", l: "Limpeza e conservação", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "oLimpeza", l: "Opção que cobra", t: "text", half: true, lista: "opcao:cLimpeza" },
      { k: "cUtilizacao", l: "Utilização do imóvel (define a TCL)", t: "text", lista: "campo:IMOVEIS" },
      { k: "cIsencao", l: "Isenção", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "oIsencao", l: "Opção que isenta", t: "text", half: true, lista: "opcao:cIsencao" }
    ] },
    { grupo: "Setor e valor do m² do terreno", itens: [
      { k: "setorCampo", l: "Setor lido de", t: "select", ops: [["campo1", "Inscrição imobiliária: campo 1"], ["campo2", "Inscrição imobiliária: campo 2"], ["campo3", "Inscrição imobiliária: campo 3"], ["campo4", "Inscrição imobiliária: campo 4"], ["setor", "imovel.setor"]] },
      { k: "setores", l: "Valor do m² do terreno por setor (decreto do exercício)", t: "rows", cols: [["setor", "Setor"], ["vl", "R$ por m²"]] }
    ] },
    { grupo: "Alíquotas do IPTU (%)", itens: [
      { k: "aTerrNaoConst", l: "Terreno, não construído", t: "number", half: true },
      { k: "aTerrConst", l: "Terreno, construído", t: "number", half: true },
      { k: "aPredio", l: "Prédio", t: "number", half: true }
    ] },
    { grupo: "Tabelas de cálculo (códigos)", itens: [
      { k: "tSituacao", l: "Situação", t: "number", half: true, lista: "tabela" },
      { k: "tPedologia", l: "Pedologia", t: "number", half: true, lista: "tabela" },
      { k: "tTopografia", l: "Topografia", t: "number", half: true, lista: "tabela" },
      { k: "tNivel", l: "Nível", t: "number", half: true, lista: "tabela" },
      { k: "tConservacao", l: "Conservação", t: "number", half: true, lista: "tabela" },
      { k: "tVlM2Predio", l: "Valor do m² do prédio", t: "number", half: true, lista: "tabela" },
      { k: "tPontuacao", l: "Tabelas somadas na pontuação (separe por vírgula)", t: "text" },
      { k: "divPontuacao", l: "Divisor da pontuação", t: "number", half: true }
    ] },
    { grupo: "Taxas", itens: [
      { k: "tcl", l: "TCL: utilização e fator em indexador (vale a primeira que bater)", t: "rows", cols: [["uso", "Utilização", "opcao:cUtilizacao"], ["fator", "Fator"]] },
      { k: "ocupColeta", l: "Ocupações que também pagam TCL, além de construído", t: "rows", cols: [["op", "Opção da ocupação", "opcao:cOcupacao"]] },
      { k: "fTlc", l: "TLC: fator em indexador", t: "number", half: true }
    ] },
    { grupo: "Receitas e benefício", itens: [
      { k: "rIT", l: "Imposto territorial", t: "text", half: true, lista: "receita:credito" },
      { k: "rIP", l: "Imposto predial", t: "text", half: true, lista: "receita:credito" },
      { k: "rTCL", l: "Coleta de lixo", t: "text", half: true, lista: "receita:credito" },
      { k: "rTLC", l: "Limpeza e conservação", t: "text", half: true, lista: "receita:credito" },
      { k: "benef", l: "Benefício fiscal da isenção", t: "text", half: true },
      { k: "percBenef", l: "% de concessão", t: "number", half: true }
    ] },
    { grupo: "Campos adicionais gravados (deixe vazio para não gravar)", itens: [
      { k: "gFracao", l: "Fração ideal", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gPontuacao", l: "Pontuação", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVVT", l: "Valor venal do terreno", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVVP", l: "Valor venal do prédio", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVVI", l: "Valor venal do imóvel", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVIT", l: "Valor imposto territorial", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVIP", l: "Valor imposto predial", t: "text", half: true, lista: "campo:IMOVEIS" },
      { k: "gVIPTU", l: "Valor IPTU", t: "text", half: true, lista: "campo:IMOVEIS" }
    ] }
  ],
  padrao: {
    nome: "IPTU - Imposto Predial e Territorial Urbano", ano: 2026, credito: "IPTU", sigla: "URM",
    lei: "CTM art. 14 (alíquotas); Decreto nº ____/2025 (m² por setor); Lei nº ____ (TCL e TLC)",
    cAreaTerreno: "Área do Terreno", cAreaUnidade: "Área da Unidade", cAreaTotal: "Área Total da Edificação",
    cOcupacao: "OCUPAÇÃO", oConstruido: "Construido", cColeta: "COLETA DE LIXO", oColeta: "Sim",
    cLimpeza: "TAXA DE LIMPEZA E CONSERVAÇÃO", oLimpeza: "Sim", cUtilizacao: "UTILIZAÇÃO DO IMÓVEL",
    cIsencao: "IMUNE/ISENTO IPTU", oIsencao: "Sim",
    setorCampo: "campo2", setores: [{ setor: 1, vl: 6.10 }, { setor: 2, vl: 4.83 }, { setor: 3, vl: 3.41 }],
    aTerrNaoConst: 2, aTerrConst: 0.5, aPredio: 0.5,
    tSituacao: 122, tPedologia: 123, tTopografia: 124, tNivel: 125, tConservacao: 126, tVlM2Predio: 127,
    tPontuacao: "115, 116, 117, 118, 119, 120, 121", divPontuacao: 100,
    tcl: [{ uso: "Comercial/Serviço", fator: 0.12 }, { uso: "Industrial", fator: 0.17 }, { uso: "Terreno Sem Uso", fator: 0.084 }, { uso: "Residencial", fator: 0.084 }],
    ocupColeta: [{ op: "Ruínas" }, { op: "Em Demolição" }, { op: "Paralisada" }, { op: "Em Andamento" }],
    fTlc: 0.03, rIT: "I.T.", rIP: "I.P.", rTCL: "TCL", rTLC: "TLC", benef: "Créditos tributários", percBenef: 100,
    gFracao: "Fração Ideal", gPontuacao: "PONTUAÇÃO DO IMÓVEL", gVVT: "Valor Venal Terreno", gVVP: "Valor Venal Prédio",
    gVVI: "Valor Venal do Imóvel", gVIT: "Valor Imposto Territorial", gVIP: "Valor Imposto Predial", gVIPTU: "Valor IPTU"
  },
  avisos(s) {
    const w = [];
    ["cAreaTerreno", "cAreaUnidade", "cAreaTotal", "cOcupacao", "oConstruido"].forEach(k => { if (!String(s[k] || "").trim()) w.push("Preencha os campos adicionais de área e ocupação: são obrigatórios no cálculo."); });
    const st = (s.setores || []).filter(r => String(r.setor ?? "").trim() !== "");
    if (!st.length) w.push("Informe ao menos um setor com o valor do m².");
    const vistos = new Set(); st.forEach(r => { const k = String(r.setor).trim(); if (vistos.has(k)) w.push(`Setor ${k} repetido: vale o primeiro.`); vistos.add(k); if (!(num(r.vl) > 0)) w.push(`Setor ${k}: valor do m² vazio ou zero.`); });
    ["aTerrNaoConst", "aTerrConst", "aPredio"].forEach(k => { if (num(s[k]) === null) w.push("Alíquota vazia."); });
    ["tSituacao", "tPedologia", "tTopografia", "tNivel", "tConservacao", "tVlM2Predio"].forEach(k => { if (!Number.isInteger(num(s[k]))) w.push("Código de tabela de cálculo vazio ou não inteiro."); });
    const pts = String(s.tPontuacao || "").split(/[,;\s]+/).filter(Boolean);
    if (pts.some(x => !/^\d+$/.test(x))) w.push("Tabelas da pontuação: use só números separados por vírgula.");
    if (pts.length && !(num(s.divPontuacao) > 0)) w.push("Divisor da pontuação vazio ou zero.");
    ["rIT", "rIP", "rTCL", "rTLC"].forEach(k => { if (!String(s[k] || "").trim()) w.push("Informe as quatro abreviaturas de receita."); });
    if (s.cIsencao && !s.benef) w.push("Isenção sem descrição do benefício fiscal.");
    if (num(s.aTerrConst) !== null && num(s.aTerrNaoConst) !== null && num(s.aTerrConst) !== num(s.aTerrNaoConst))
      w.push(`Confira no CTM: imóvel construído paga ${num(s.aTerrConst).toLocaleString("pt-BR")}% sobre o venal do terreno e não construído ${num(s.aTerrNaoConst).toLocaleString("pt-BR")}%.`);
    return [...new Set(w)];
  },
  gerar(s) {
    const L = header(s, "Cálculo", s.credito, "calcula o valor venal (terreno + prédio), o IPTU, a TCL e a TLC e lança as receitas " + [s.rIT, s.rIP, s.rTCL, s.rTLC].join(", "));
    const st = (s.setores || []).filter(r => String(r.setor ?? "").trim() !== "");
    const pts = String(s.tPontuacao || "").split(/[,;\s]+/).filter(x => /^\d+$/.test(x));
    const setorNumerico = st.length > 0 && st.every(r => /^\d+$/.test(String(r.setor).trim()));
    const tcl = (s.tcl || []).filter(r => String(r.uso || "").trim());
    const ocs = (s.ocupColeta || []).map(r => String(r.op || "").trim()).filter(Boolean);
    const temIsencao = s.cIsencao && s.oIsencao;
    const tab = k => Number.isInteger(num(s[k])) ? num(s[k]) : 0;
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push(`siglaIndexador = ${q(s.sigla || "URM")};`, "");
    L.push("// [setor tributário, valor do m² do terreno em R$] (decreto do exercício)");
    L.push("valoresM2Terreno = [");
    st.forEach((r, i) => L.push(`  [${setorNumerico ? num(r.setor) : q(String(r.setor).trim())}, ${fx(num(r.vl) ?? 0)}]` + (i < st.length - 1 ? "," : "")));
    L.push("];", "");
    L.push("// alíquotas do IPTU");
    L.push(`aliqTerrenoNaoConstruido = ${fx((num(s.aTerrNaoConst) ?? 0) / 100, 3)};  // ${num(s.aTerrNaoConst) ?? 0}% sobre o venal do terreno, imóvel não construído`);
    L.push(`aliqTerrenoConstruido    = ${fx((num(s.aTerrConst) ?? 0) / 100, 3)};  // ${num(s.aTerrConst) ?? 0}% sobre o venal do terreno, imóvel construído`);
    L.push(`aliqPredio               = ${fx((num(s.aPredio) ?? 0) / 100, 3)};  // ${num(s.aPredio) ?? 0}% sobre o venal do prédio`, "");
    L.push("// códigos das tabelas de cálculo desta entidade");
    L.push(`tabSituacao    = ${tab("tSituacao")};`, `tabPedologia   = ${tab("tPedologia")};`, `tabTopografia  = ${tab("tTopografia")};`, `tabNivel       = ${tab("tNivel")};`, `tabConservacao = ${tab("tConservacao")};`, `tabVlM2Predio  = ${tab("tVlM2Predio")};`);
    L.push(`tabelasPontuacao = [${pts.join(", ")}];  // soma = pontuação`);
    L.push(`divisorPontuacao = ${fx(num(s.divPontuacao) || 100, 1)};  // pontuação ÷ divisor = fator do prédio`, "");
    L.push(`// Taxa de Coleta de Lixo: fator em ${s.sigla || "URM"} conforme a utilização (vale a primeira que bater)`);
    L.push("fatoresTcl = [");
    tcl.forEach((r, i) => L.push(`  [${q(String(r.uso).trim())}, ${fx(num(r.fator) ?? 0, 2)}]` + (i < tcl.length - 1 ? "," : "")));
    L.push("];");
    L.push(`// além de ${q(s.oConstruido)}, estas ocupações também pagam TCL`);
    L.push(`ocupacoesComColeta = [${ocs.map(q).join(", ")}];`, "");
    L.push(`fatorTlc = ${fx(num(s.fTlc) ?? 0, 2)};  // Taxa de Limpeza e Conservação, em ${s.sigla || "URM"}`, "");
    if (temIsencao) { L.push(`beneficioIsencao = ${q(s.benef)};`, `percIsencao      = ${num(s.percBenef) ?? 100};`, ""); }
    L.push("// nomes dos campos adicionais e receitas");
    L.push(`campoAreaTerreno = ${q(s.cAreaTerreno)};`, `campoAreaUnidade = ${q(s.cAreaUnidade)};`, `campoAreaTotal   = ${q(s.cAreaTotal)};`);
    L.push(`campoOcupacao    = ${q(s.cOcupacao)};`, `opcaoConstruido  = ${q(s.oConstruido)};`);
    L.push(`campoColeta      = ${q(s.cColeta)};`, `opcaoColeta      = ${q(s.oColeta)};`);
    L.push(`campoLimpeza     = ${q(s.cLimpeza)};`, `opcaoLimpeza     = ${q(s.oLimpeza)};`);
    L.push(`campoUtilizacao  = ${q(s.cUtilizacao)};`);
    if (temIsencao) L.push(`campoIsencao     = ${q(s.cIsencao)};`, `opcaoIsencao     = ${q(s.oIsencao)};`);
    L.push(`receitaIT  = ${q(s.rIT)};`, `receitaIP  = ${q(s.rIP)};`, `receitaTCL = ${q(s.rTCL)};`, `receitaTLC = ${q(s.rTLC)};`);

    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Imovel " + imovel.codigo + " (exercicio " + ano + "): ";', "");
    L.push("vlUrm = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
    L.push("se (vlUrm == nulo || vlUrm == 0) {", '  suspender(ident + "valor do indexador " + siglaIndexador + " nao foi informado para o exercicio " + ano + ".");', "}", "");
    L.push("areaTerreno     = CamposAdicionais.valor(imovel, campoAreaTerreno, ano) ?: 0;");
    L.push("areaUnidade     = CamposAdicionais.valor(imovel, campoAreaUnidade, ano) ?: 0;");
    L.push("areaTotalPredio = CamposAdicionais.valor(imovel, campoAreaTotal, ano) ?: 0;", "");
    L.push("ehConstruido = (CamposAdicionais.valorOpcao(imovel, campoOcupacao, opcaoConstruido, ano) ?: false);", "");
    L.push("se (ehConstruido) {");
    L.push("  se (areaTotalPredio == 0) {", '    suspender(ident + "Area Total da Edificacao deve ser maior que zero para calcular a fracao ideal.");', "  }");
    L.push("  se (areaUnidade == 0) {", '    suspender(ident + "Area da Unidade nao informada para imovel construido.");', "  }");
    L.push("}", "");
    if (s.setorCampo === "setor") {
      L.push("// setor lido de imovel.setor");
      L.push("setorTxt = \"\";", "se (imovel.setor != nulo) {", "  setorTxt = \"\" + imovel.setor;", "}");
    } else {
      L.push(`// setor lido do ${s.setorCampo} da inscrição imobiliária; imovel.setor é a segunda opção`);
      L.push("setorTxt = \"\";");
      L.push(`se (imovel.inscricaoImobiliaria != nulo && imovel.inscricaoImobiliaria.${s.setorCampo} != nulo) {`, `  setorTxt = "" + imovel.inscricaoImobiliaria.${s.setorCampo};`, "}");
      L.push("se (setorTxt == \"\" && imovel.setor != nulo) {", "  setorTxt = \"\" + imovel.setor;", "}");
    }
    if (setorNumerico) {
      L.push("// setor numérico: \"01\" e \"1\" valem o mesmo setor");
      L.push("setor = nulo;", "se (setorTxt != \"\" && Numeros.ehNumero(setorTxt)) {", "  setor = Numeros.numero(setorTxt);", "}", "");
      L.push("vlM2Terreno = nulo;");
      L.push("percorrer(valoresM2Terreno) { faixa ->");
      L.push("  se (vlM2Terreno == nulo && setor != nulo && setor == faixa[0]) {", "    vlM2Terreno = faixa[1];", "  }");
      L.push("}");
    } else {
      L.push("", "vlM2Terreno = nulo;");
      L.push("percorrer(valoresM2Terreno) { faixa ->");
      L.push("  se (vlM2Terreno == nulo && setorTxt == faixa[0]) {", "    vlM2Terreno = faixa[1];", "  }");
      L.push("}");
    }
    L.push("se (vlM2Terreno == nulo) {", `  suspender(ident + "Setor tributario '" + setorTxt + "' sem valor do m2 (esperado ${st.map(r => String(r.setor).trim()).join(", ")}).");`, "}", "");
    L.push("// fatores corretivos do terreno: obrigatórios para todo imóvel");
    L.push("fatorSituacao   = tabelasCalculos.getValor(ano, tabSituacao,   imovel.codigo);");
    L.push("fatorPedologia  = tabelasCalculos.getValor(ano, tabPedologia,  imovel.codigo);");
    L.push("fatorTopografia = tabelasCalculos.getValor(ano, tabTopografia, imovel.codigo);");
    L.push("fatorNivel      = tabelasCalculos.getValor(ano, tabNivel,      imovel.codigo);", "");
    L.push("faltando = \"\";");
    L.push('se (fatorSituacao   == nulo) { faltando = faltando + " Situacao(" + tabSituacao + ")"; }');
    L.push('se (fatorPedologia  == nulo) { faltando = faltando + " Pedologia(" + tabPedologia + ")"; }');
    L.push('se (fatorTopografia == nulo) { faltando = faltando + " Topografia(" + tabTopografia + ")"; }');
    L.push('se (fatorNivel      == nulo) { faltando = faltando + " Nivel(" + tabNivel + ")"; }');
    L.push("se (faltando != \"\") {", '  suspender(ident + "Fatores do terreno sem valor na tabela de calculo:" + faltando);', "}", "");
    L.push("// fatores do prédio: só exigidos quando o imóvel é construído");
    L.push("vlM2Predio = 0;", "fatorConservacao = 0;", "pontos = 0;");
    L.push("se (ehConstruido) {");
    L.push("  vlM2Predio       = tabelasCalculos.getValor(ano, tabVlM2Predio,  imovel.codigo);");
    L.push("  fatorConservacao = tabelasCalculos.getValor(ano, tabConservacao, imovel.codigo);", "");
    L.push("  faltando = \"\";");
    L.push('  se (vlM2Predio       == nulo) { faltando = faltando + " Valor m2 Predio(" + tabVlM2Predio + ")"; }');
    L.push('  se (fatorConservacao == nulo) { faltando = faltando + " Conservacao(" + tabConservacao + ")"; }');
    L.push("  se (faltando != \"\") {", '    suspender(ident + "Fatores do predio sem valor na tabela de calculo:" + faltando);', "  }", "");
    L.push("  // item da pontuação ausente conta como 0 ponto");
    L.push("  percorrer(tabelasPontuacao) { codTabela ->", "    pontos = pontos + (tabelasCalculos.getValor(ano, codTabela, imovel.codigo) ?: 0);", "  }");
    L.push("}", "");
    L.push("// dados das taxas e da isenção");
    L.push("temOcupacaoComColeta = ehConstruido;");
    L.push("percorrer(ocupacoesComColeta) { ocupacao ->", "  se (CamposAdicionais.valorOpcao(imovel, campoOcupacao, ocupacao, ano) ?: false) {", "    temOcupacaoComColeta = true;", "  }", "}");
    L.push("temColetaLixo = (CamposAdicionais.valorOpcao(imovel, campoColeta, opcaoColeta, ano) ?: false);");
    L.push("temLimpeza    = (CamposAdicionais.valorOpcao(imovel, campoLimpeza, opcaoLimpeza, ano) ?: false);");
    L.push(temIsencao ? "ehIsento      = (CamposAdicionais.valorOpcao(imovel, campoIsencao, opcaoIsencao, ano) ?: false);" : "ehIsento      = false;  // sem campo de isenção configurado");

    L.push("", sec("CÁLCULO"));
    L.push("// fração ideal: construído divide o terreno pela participação da unidade no prédio");
    L.push("fracaoIdeal = areaTerreno;", "se (ehConstruido) {", "  fracaoIdeal = (areaTerreno * areaUnidade) / areaTotalPredio;", "}", "");
    L.push("vlVenalTerreno = fracaoIdeal * vlM2Terreno * fatorSituacao * fatorPedologia * fatorTopografia * fatorNivel;", "");
    L.push("vlVenalPredio = 0;", "se (ehConstruido) {", "  // usa \"pontos\" direto, sem reler o campo gravado nesta mesma execução", "  fatorPontuacao = pontos / divisorPontuacao;", "  vlVenalPredio  = vlM2Predio * areaUnidade * fatorConservacao * fatorPontuacao;", "}", "");
    L.push("vlVenalImovel = vlVenalTerreno + vlVenalPredio;", "");
    L.push("// IPTU; \"vlIT\" e não \"it\", que é reservado no BFC-Script (Groovy)");
    L.push("vlIT = 0;", "vlIP = 0;", "se (ehConstruido) {", "  vlIT = vlVenalTerreno * aliqTerrenoConstruido;", "  vlIP = vlVenalPredio * aliqPredio;", "} senao {", "  vlIT = vlVenalTerreno * aliqTerrenoNaoConstruido;", "}", "vlIptu = vlIT + vlIP;", "");
    L.push("// TCL: precisa de coleta e de uma ocupação que gere lixo; vale a primeira utilização que bater");
    L.push("vlTCL = 0;", "se (temColetaLixo && temOcupacaoComColeta) {", "  fatorTclAplicado = nulo;", "  percorrer(fatoresTcl) { faixa ->",
      "    se (fatorTclAplicado == nulo && (CamposAdicionais.valorOpcao(imovel, campoUtilizacao, faixa[0], ano) ?: false)) {", "      fatorTclAplicado = faixa[1];", "    }", "  }",
      "  se (fatorTclAplicado != nulo) {", "    vlTCL = fatorTclAplicado * vlUrm;", "  }", "}", "");
    L.push("vlTLC = 0;", "se (temLimpeza) {", "  vlTLC = fatorTlc * vlUrm;", "}");

    L.push("", sec("RESULTADO"));
    const grav = [["gFracao", "fracaoIdeal", true], ["gVVT", "vlVenalTerreno"], ["gPontuacao", "pontos", true], ["gVVP", "vlVenalPredio"], ["gVVI", "vlVenalImovel"], ["gVIT", "vlIT"], ["gVIP", "vlIP"], ["gVIPTU", "vlIptu"]]
      .filter(g => String(s[g[0]] || "").trim());
    if (grav.length) {
      L.push("// campos adicionais gravados para consulta no cadastro (valores sem arredondar)");
      grav.forEach(([k, v, soConstruido]) => {
        const linha = `CamposAdicionais.preencherCampoAdicional(imovel, ${q(s[k])}, ${v}, ano);`;
        if (soConstruido) L.push("se (ehConstruido) {", "  " + linha, "}"); else L.push(linha);
      });
      L.push("");
    }
    L.push("// arredondamento e garantia final contra nulo");
    L.push("vlIT  = Numeros.arredonda(vlIT  ?: 0, 2);", "vlIP  = Numeros.arredonda(vlIP  ?: 0, 2);", "vlTCL = Numeros.arredonda(vlTCL ?: 0, 2);", "vlTLC = Numeros.arredonda(vlTLC ?: 0, 2);", "");
    L.push("// só cria receita com valor > 0");
    if (temIsencao) {
      L.push("se (ehIsento) {", "  beneficio = Utilitarios.buscaBeneficioFiscal(beneficioIsencao);",
        "  se (vlIT  > 0) { lancamento.criarReceita(receitaIT,  vlIT,  beneficio, percIsencao); }",
        "  se (vlIP  > 0) { lancamento.criarReceita(receitaIP,  vlIP,  beneficio, percIsencao); }",
        "  se (vlTCL > 0) { lancamento.criarReceita(receitaTCL, vlTCL, beneficio, percIsencao); }",
        "  se (vlTLC > 0) { lancamento.criarReceita(receitaTLC, vlTLC, beneficio, percIsencao); }", "} senao {");
      ["IT", "IP", "TCL", "TLC"].forEach(r => L.push(`  se (vl${r}${" ".repeat(3 - r.length + 1)}> 0) { lancamento.criarReceita(receita${r}, vl${r}); }`));
      L.push("}");
    } else ["IT", "IP", "TCL", "TLC"].forEach(r => L.push(`se (vl${r} > 0) { lancamento.criarReceita(receita${r}, vl${r}); }`));
    return L.join("\n");
  },
  notas: ["Modelo baseado no IPTU de Barão do Triunfo (registro 511404). Com os valores padrão, o resultado é o mesmo da fórmula em produção.", "Setores só com números são comparados como número, como na fórmula original (\"01\" = 1). Com letras, a comparação é pelo texto exato.", "Teste o percorrer da pontuação numa simulação: se a pontuação vier 0 num imóvel com pontos, avise."]
};

/* ---------- MODELO 0: fórmula do zero ---------- */
const nomeVarSeguro = s => {
  const p = String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").split(/[^A-Za-z0-9]+/).filter(Boolean).map(w => w.toLowerCase());
  let n = p.map((w, i) => i ? w[0].toUpperCase() + w.slice(1) : w).join("");
  if (/^[0-9]/.test(n)) n = "v" + n;
  if (["it", "item", "indice", "ano", "imovel", "economico", "lancamento", "nulo", "se", "senao", "receita", "receitas", "ident"].includes(n)) n += "Param";
  return n;
};
const mBranco = {
  id: "branco", titulo: "Fórmula do zero", sub: "Esqueleto no padrão da casa: cabeçalho, parâmetros, entradas, cálculo e resultado", tipo: "qualquer tipo",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "oQueFaz", l: "O que a fórmula faz (uma frase)", t: "text" }] },
    { grupo: "Tipo e crédito", itens: [
      { k: "tipoF", l: "Tipo de fórmula", t: "select", ops: [["calculo", "Cálculo (lança receitas)"], ["desconto", "Desconto para parcelamentos"], ["acrescimos", "Acréscimos (juro e multa)"], ["convenio", "Convênio bancário"]] },
      { k: "cadastro", l: "Cadastro do crédito", t: "select", ops: [["IMOVEIS", "Imóveis"], ["ECONOMICOS", "Econômicos"], ["RECEITAS_DIVERSAS", "Receitas diversas"]] },
      { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:*" },
      { k: "sigla", l: "Indexador (opcional)", t: "text", half: true, lista: "indexador" }
    ] },
    { grupo: "Parâmetros (valores de lei)", itens: [
      { k: "params", l: "Um por linha: nome, valor e de onde vem", t: "rows", cols: [["nome", "Nome"], ["valor", "Valor"], ["fonte", "Lei / artigo"]] }
    ] },
    { grupo: "Receitas lançadas (só cálculo)", itens: [
      { k: "receitas", l: "Abreviaturas das receitas", t: "rows", cols: [["abrev", "Abreviatura", "receita:credito"]] }
    ] }
  ],
  padrao: {},
  avisos(s) {
    const w = [], nomes = new Set();
    (s.params || []).forEach(r => {
      if (!String(r.nome || "").trim()) return;
      const n = nomeVarSeguro(r.nome);
      if (nomes.has(n)) w.push(`Parâmetro "${r.nome}" repetido.`);
      nomes.add(n);
      if (String(r.valor ?? "").trim() === "") w.push(`Parâmetro "${r.nome}" sem valor.`);
      if (n.endsWith("Param")) w.push(`"${r.nome}" é palavra reservada: virou ${n}.`);
    });
    if (s.tipoF === "calculo" && !(s.receitas || []).some(r => String(r.abrev || "").trim())) w.push("Informe ao menos uma receita para a fórmula de cálculo.");
    if (!String(s.nome || "").trim()) w.push("Dê um nome à fórmula.");
    return w;
  },
  gerar(s) {
    const tipoTela = { calculo: "Cálculo", desconto: "Desconto para parcelamentos", acrescimos: "Acréscimos", convenio: "Convênio bancário" }[s.tipoF || "calculo"];
    const L = header(s, tipoTela, s.credito, s.oQueFaz || "<descreva em uma frase>");
    const ref = { IMOVEIS: "imovel", ECONOMICOS: "economico", RECEITAS_DIVERSAS: "receitaDiversa" }[s.cadastro || "IMOVEIS"];
    const tipoF = s.tipoF || "calculo";
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    const ps = (s.params || []).filter(r => String(r.nome || "").trim());
    if (!ps.length) L.push("// <nomeDoParametro> = <valor>;  // Lei nº __, art. __");
    ps.forEach(r => {
      const v = String(r.valor ?? "").trim(), n = num(v);
      const lit = v === "" ? "0" : (n !== null && /^-?[\d.,]+$/.test(v)) ? String(n) : q(v);
      L.push(`${nomeVarSeguro(r.nome)} = ${lit};` + (r.fonte ? `  // ${r.fonte}` : ""));
    });
    if (s.sigla && tipoF === "calculo") L.push(`siglaIndexador = ${q(s.sigla)};`);
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    if (tipoF === "calculo") {
      L.push(`ident = ${{ imovel: '"Imovel " + imovel.codigo', economico: '"Economico " + economico.codigo', receitaDiversa: '"Receita diversa " + receitaDiversa.codigo' }[ref]} + " (" + ano + "): ";`);
      if (ref === "economico") L.push("// em econômicos o campo adicional é lido por data, não por ano", "dtBaseCampos = dataBase ?: Datas.data(ano, 1, 1);");
      if (s.sigla) {
        L.push("", "vlIndexador = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
        L.push("se (vlIndexador == nulo || vlIndexador == 0) {", '  suspender(ident + "valor do indexador " + siglaIndexador + " nao cadastrado para " + ano + ".");', "}");
      }
      L.push("", `// leia aqui os campos adicionais e tabelas (aba Campos gera estas linhas)`);
      L.push(`// ex.: area = CamposAdicionais.valor(${ref}, "<nome exato do campo>", ${ref === "economico" ? "dtBaseCampos" : "ano"}) ?: 0;`);
    } else if (tipoF === "desconto") {
      L.push("// variáveis prontas: qtdParcelas, vlTotalJuros, vlTotalMulta, vlTotalCorrecao, vlTotalLancado (e as versões ...Parcelar)");
    } else if (tipoF === "acrescimos") {
      L.push("// variáveis prontas: dataVencimento, dataBase, receitas (cada receita: valor, beneficio, correcao)");
    } else {
      L.push("// variáveis prontas: valorDoDocumento, dataDeVencimento, numeroDeBaixa, nroDaparcela, Convenio");
    }
    L.push("", sec("CÁLCULO"));
    const recs = (s.receitas || []).map(r => String(r.abrev || "").trim()).filter(Boolean);
    if (tipoF === "calculo") {
      if (!recs.length) L.push("// vlReceita = ...;");
      recs.forEach(r => L.push(`vl${nomeVarSeguro(r).replace(/^./, c => c.toUpperCase())} = 0;  // calcule o valor da receita ${r}`));
      L.push("", sec("RESULTADO"));
      recs.forEach(r => { const v = "vl" + nomeVarSeguro(r).replace(/^./, c => c.toUpperCase()); L.push(`${v} = Numeros.arredonda(${v} ?: 0, 2);`); });
      if (recs.length) L.push("");
      recs.forEach(r => { const v = "vl" + nomeVarSeguro(r).replace(/^./, c => c.toUpperCase()); L.push(`se (${v} > 0) { lancamento.criarReceita(${q(r)}, ${v}); }`); });
      if (!recs.length) L.push('// lancamento.criarReceita("<ABREV>", vlReceita);');
    } else if (tipoF === "desconto") {
      L.push("descontoTributo  = 0.00;", "descontoCorrecao = 0.00;", "descontoMulta    = 0.00;", "descontoJuros    = 0.00;", "", "// regra do desconto aqui (valores em R$, não percentuais)");
      L.push("", sec("RESULTADO"));
      L.push("retornar TRIBUTO: Numeros.arredonda(descontoTributo, 2), CORRECAO: Numeros.arredonda(descontoCorrecao, 2), MULTA: Numeros.arredonda(descontoMulta, 2), JUROS: Numeros.arredonda(descontoJuros, 2);");
    } else if (tipoF === "acrescimos") {
      L.push("percorrer(receitas) { receita ->", "  base = receita.valor - receita.beneficio;", "  vlJuro  = 0;  // regra dos juros", "  vlMulta = 0;  // regra da multa", "", sec("RESULTADO").replace(/^/, "  "),
        "  receita.comJuro(Numeros.arredonda(vlJuro, 2));", "  receita.comMulta(Numeros.arredonda(vlMulta, 2));", "}");
    } else {
      L.push("codigoBarras = \"\";           // monte o código de barras", "representacaoNumerica = \"\";  // linha digitável", "nossoNumero = numeroDeBaixa;", "", sec("RESULTADO"));
      L.push("retornar codigoBarras: codigoBarras, representacaoNumerica: representacaoNumerica, nossoNumero: nossoNumero;");
    }
    return L.join("\n");
  },
  notas: ["Comece pelos parâmetros e pelas receitas; depois use a aba Campos para gerar a leitura dos campos adicionais e cole no bloco ENTRADAS.", "Quando o esqueleto estiver preenchido, use Revisar com IA para completar a regra a partir da lei."]
};

function hl(code) {
  return code.split("\n").map(line => {
    const ci = line.indexOf("//");
    let body = ci >= 0 ? line.slice(0, ci) : line, com = ci >= 0 ? line.slice(ci) : "";
    if (/^\s*\/?\*/.test(line)) { body = ""; com = line; }
    let out = esc(body).replace(/(&quot;[^&]*?&quot;|"[^"]*")/g, '<span class="s">$1</span>')
      .replace(/\b(se|senao|percorrer|retornar|suspender|nulo|imprimir)\b/g, '<span class="k">$1</span>');
    return out + (com ? `<span class="c">${esc(com)}</span>` : "");
  }).join("\n");
}
/* modelos começam em branco: os exemplos antigos de Barão saíram do padrão */
function vazio(m) {
  const s = { ano: new Date().getFullYear() };
  m.campos.forEach(g => g.itens.forEach(c => {
    if (c.k === "ano") return;
    if (c.t === "rows") s[c.k] = [Object.fromEntries(c.cols.map(x => [x[0], ""]))];
    else if (c.t === "select") s[c.k] = c.ops[0][0];
    else if (c.t === "check") s[c.k] = false;
    else s[c.k] = "";
  }));
  return s;
}
const MODELOS_LISTA = [mBranco, mIptu, mDesconto, mAcrescimos, mEnquadramento, mFaixas, mReceita];
MODELOS_LISTA.forEach(m => { m.padrao = vazio(m); });
mIptu.notas = mIptu.notas.filter(n => !/Barão/.test(n));
window.GF = { VERSAO_PADRAO: 2, MODELOS: MODELOS_LISTA, hl, esc, num, hoje };
})();
