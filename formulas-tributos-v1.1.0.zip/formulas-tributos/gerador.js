/* Gerador de fórmulas — modelos e utilidades (sem DOM). */
(function () {
"use strict";
/* ---------- utilidades ---------- */
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const q = s => '"' + String(s ?? "").replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
const num = v => { const n = parseFloat(String(v).replace(",", ".")); return isNaN(n) ? null : n; };
function fx(n, min = 2, max = 6) {            // número BFC: ponto decimal, ao menos 2 casas
  if (n === null || n === undefined) return "nulo";
  let s = Number(n).toFixed(max).replace(/0+$/, "");
  const [i, d = ""] = s.split(".");
  return i + "." + (d + "0".repeat(min)).slice(0, Math.max(min, d.length));
}
const frac = p => fx(num(p) === null ? 0 : num(p) / 100);
const pad = (s, n) => (s + " ".repeat(n)).slice(0, Math.max(n, s.length));
const hoje = () => { const d = new Date(); return [d.getDate(), d.getMonth() + 1, d.getFullYear()].map((x, i) => i < 2 ? String(x).padStart(2, "0") : x).join("/"); };

function header(s, tipo, credito, oQueFaz) {
  return [
    "// ============================================================",
    "// " + (s.nome || "FÓRMULA").toUpperCase(),
    "// Tipo      : " + tipo + " | Crédito: " + (credito || "____") + " | Exercício: " + (s.ano || "____"),
    "// O que faz : " + oQueFaz,
    "// Base legal: " + (s.lei || "Lei nº ____/____, art. __"),
    "// Histórico : " + hoje() + " - " + (s.autor || "<nome>") + " - " + (s.motivo || "criação pelo gerador"),
    "// ============================================================",
    ""
  ];
}
const sec = t => "// ---------- " + t + " ----------";

/* ---------- campos comuns ---------- */
const comuns = [
  { k: "nome", l: "Nome da fórmula", t: "text" },
  { k: "ano", l: "Exercício", t: "number", half: true },
  { k: "autor", l: "Seu nome (histórico)", t: "text", half: true },
  { k: "lei", l: "Base legal", t: "text", ph: "Lei nº 857/2026, art. 3º" },
  { k: "motivo", l: "Motivo da alteração (histórico)", t: "text", ph: "criação pelo gerador" }
];

/* ---------- MODELO 1: desconto de parcelamento ---------- */
const mDesconto = {
  id: "desconto", titulo: "Desconto de parcelamento / REFIS", sub: "Desconto em juros, multa, correção e tributo por faixa de parcelas", tipo: "DESCONTO_PARCELAMENTO",
  campos: [
    { grupo: "Identificação", itens: comuns },
    { grupo: "Regra", itens: [
      { k: "base", l: "Desconto calculado sobre", t: "select", ops: [["total", "Totais da dívida/lançamento (vlTotalJuros...)"], ["parcelar", "Só o que está sendo parcelado (vlTotalJurosParcelar...)"]] },
      { k: "faixas", l: "Faixas de parcelas (percentuais de desconto)", t: "rows", cols: [["de", "Parcelas de"], ["ate", "até"], ["j", "% juros"], ["m", "% multa"], ["c", "% correção"], ["t", "% tributo"]] },
      { k: "limite", l: "Adesão válida até (opcional)", t: "date" }
    ] }
  ],
  padrao: { nome: "REFIS 2026", ano: 2026, base: "total", lei: "", limite: "",
    faixas: [{ de: 1, ate: 1, j: 100, m: 100, c: 0, t: 0 }, { de: 2, ate: 12, j: 80, m: 80, c: 0, t: 0 }, { de: 13, ate: 60, j: 50, m: 50, c: 0, t: 0 }] },
  avisos(s) {
    const w = [], f = (s.faixas || []).map(r => ({ de: num(r.de), ate: num(r.ate) })).filter(r => r.de !== null && r.ate !== null).sort((a, b) => a.de - b.de);
    if (!f.length) w.push("Informe ao menos uma faixa de parcelas.");
    f.forEach((r, i) => {
      if (r.de > r.ate) w.push(`Faixa ${r.de}–${r.ate}: "de" é maior que "até".`);
      if (i && r.de <= f[i - 1].ate) w.push(`Faixas ${f[i - 1].de}–${f[i - 1].ate} e ${r.de}–${r.ate} se sobrepõem: vale a que aparece primeiro na lista.`);
      if (i && r.de > f[i - 1].ate + 1) w.push(`Buraco entre ${f[i - 1].ate} e ${r.de} parcelas: nessas quantidades não há desconto.`);
    });
    (s.faixas || []).forEach(r => ["j", "m", "c", "t"].forEach(k => { const v = num(r[k]); if (v !== null && (v < 0 || v > 100)) w.push("Percentual fora de 0 a 100 numa faixa."); }));
    return [...new Set(w)];
  },
  gerar(s) {
    const b = s.base === "parcelar"
      ? { t: "vlTotalLancadoParcelar", c: "vlTotalCorrecaoParcelar", m: "vlTotalMultaParcelar", j: "vlTotalJurosParcelar" }
      : { t: "vlTotalLancado", c: "vlTotalCorrecao", m: "vlTotalMulta", j: "vlTotalJuros" };
    const rows = (s.faixas || []).filter(r => num(r.de) !== null && num(r.ate) !== null);
    const L = header(s, "Desconto para parcelamentos", "todos", "desconto sobre juros, multa, correção e tributo conforme o nº de parcelas");
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push("// Cada faixa: [parcelas de, parcelas até, desc. juros, desc. multa, desc. correção, desc. tributo]");
    L.push("// Percentuais em fração: 0.95 = 95% de desconto sobre o valor.");
    L.push("faixasDesconto = [");
    rows.forEach((r, i) => {
      const linha = `  [${num(r.de)}, ${num(r.ate)}, ${frac(r.j)}, ${frac(r.m)}, ${frac(r.c)}, ${frac(r.t)}]` + (i < rows.length - 1 ? "," : "");
      L.push(pad(linha, 46) + `// ${num(r.de) === num(r.ate) ? num(r.de) + (num(r.de) === 1 ? " parcela (à vista)" : " parcelas") : num(r.de) + " a " + num(r.ate) + " parcelas"}`);
    });
    L.push("];");
    const lim = s.limite ? s.limite.split("-").map(Number) : null;
    if (lim) L.push(`dtFimAdesao = Datas.data(${lim[0]}, ${lim[1]}, ${lim[2]});  // último dia para aderir com desconto`);
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push(`// Base: ${s.base === "parcelar" ? "somente os valores que estão sendo parcelados" : "totais da dívida ou do lançamento do exercício"}.`);
    L.push("faixaAplicada = nulo;");
    L.push("percorrer(faixasDesconto) { faixa ->");
    L.push("  se (faixaAplicada == nulo && qtdParcelas >= faixa[0] && qtdParcelas <= faixa[1]) {");
    L.push("    faixaAplicada = faixa;");
    L.push("  }");
    L.push("}");
    if (lim) {
      L.push("// fora do prazo de adesão não há desconto (compara com o dia seguinte ao limite, porque hoje() traz a hora)");
      L.push("se (Datas.hoje() >= Datas.adicionaDias(dtFimAdesao, 1)) {");
      L.push("  faixaAplicada = nulo;");
      L.push("}");
    }
    L.push("", sec("CÁLCULO"));
    L.push("descontoTributo  = 0.00;", "descontoCorrecao = 0.00;", "descontoMulta    = 0.00;", "descontoJuros    = 0.00;", "");
    L.push("// quantidade de parcelas fora das faixas: sem desconto");
    L.push("se (faixaAplicada != nulo) {");
    L.push(`  descontoJuros    = ${b.j} * faixaAplicada[2];`);
    L.push(`  descontoMulta    = ${b.m} * faixaAplicada[3];`);
    L.push(`  descontoCorrecao = ${b.c} * faixaAplicada[4];`);
    L.push(`  descontoTributo  = ${b.t} * faixaAplicada[5];`);
    L.push("}");
    L.push("", sec("RESULTADO"));
    L.push("descontoTributo  = Numeros.arredonda(descontoTributo, 2);", "descontoCorrecao = Numeros.arredonda(descontoCorrecao, 2);", "descontoMulta    = Numeros.arredonda(descontoMulta, 2);", "descontoJuros    = Numeros.arredonda(descontoJuros, 2);", "");
    L.push("retornar TRIBUTO: descontoTributo, CORRECAO: descontoCorrecao, MULTA: descontoMulta, JUROS: descontoJuros;");
    return L.join("\n");
  },
  notas: ["Lembre de ativar a configuração de desconto no parcelamento: sem ela, a fórmula não é usada.", "A variável atribuída dentro do percorrer vale fora dele. Na primeira vez, confira com imprimir faixaAplicada no console."]
};

/* ---------- MODELO 2: taxa por enquadramento (econômicos) ---------- */
const mEnquadramento = {
  id: "enquadramento", titulo: "Taxa por enquadramento (econômicos)", sub: "Alvará, licença, fiscalização: fator em URM conforme opção de campo adicional", tipo: "GERACAO_CREDITO · ECONOMICOS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:ECONOMICOS" }] },
    { grupo: "Enquadramento", itens: [
      { k: "campo", l: "Campo adicional do econômico", t: "text", lista: "campo:ECONOMICOS" },
      { k: "sigla", l: "Indexador", t: "text", half: true, lista: "indexador" },
      { k: "receita", l: "Receita da taxa", t: "text", half: true, lista: "receita:credito" },
      { k: "enq", l: "Opções e fator (quantas vezes o indexador, por ano)", t: "rows", cols: [["op", "Opção do campo", "opcao:campo"], ["fator", "Fator"]] }
    ] },
    { grupo: "Regras opcionais", itens: [
      { k: "prop", l: "Proporcional aos meses a partir do início da atividade", t: "check" },
      { k: "receitaInicio", l: "Receita diferente no ano de início (ex.: alvará × fiscalização)", t: "text", ph: "deixe vazio para usar sempre a mesma", lista: "receita:credito" },
      { k: "mei", l: "MEI não paga (suspende o cálculo)", t: "check" },
      { k: "exp", l: "Taxa de expediente (% do indexador, 0 = não cobra)", t: "number", half: true },
      { k: "receitaExp", l: "Receita da taxa de expediente", t: "text", half: true, lista: "receita:credito" }
    ] }
  ],
  padrao: { nome: "Taxa de Licença e Fiscalização 2026", ano: 2026, credito: "ALVAR", campo: "TX LICENÇA/FISCALIZAÇÃO", sigla: "URM", receita: "TXFIS", receitaInicio: "TXALV",
    enq: [{ op: "101", fator: 0.9 }, { op: "102", fator: 1.5 }, { op: "103", fator: 3 }, { op: "105", fator: 2 }, { op: "108", fator: 1 }],
    prop: true, mei: true, exp: 6, receitaExp: "TXEXP" },
  avisos(s) {
    const w = [], ops = (s.enq || []).map(r => String(r.op || "").trim()).filter(Boolean);
    if (!ops.length) w.push("Informe ao menos uma opção de enquadramento.");
    if (new Set(ops).size !== ops.length) w.push("Há opção repetida na tabela: vale a primeira.");
    (s.enq || []).forEach(r => { if (String(r.op || "").trim() && !(num(r.fator) > 0)) w.push(`Opção ${r.op}: fator vazio ou zero.`); });
    if (!s.campo) w.push("Informe o nome do campo adicional exatamente como no cadastro, com acentos.");
    if (!s.receita) w.push("Informe a abreviatura da receita.");
    if (num(s.exp) > 0 && !s.receitaExp) w.push("Taxa de expediente sem abreviatura de receita.");
    return w;
  },
  gerar(s) {
    const rows = (s.enq || []).filter(r => String(r.op || "").trim());
    const exp = num(s.exp) > 0;
    const L = header(s, "Cálculo", s.credito, "taxa anual em " + (s.sigla || "URM") + " conforme o enquadramento do econômico" + (s.prop ? ", proporcional aos meses de atividade no ano de início" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push(`siglaIndexador     = ${q(s.sigla || "URM")};`);
    L.push(`campoEnquadramento = ${q(s.campo)};`);
    L.push(`receitaTaxa        = ${q(s.receita)};`);
    if (s.prop && s.receitaInicio) L.push(`receitaAnoInicio   = ${q(s.receitaInicio)};  // usada quando a atividade começou no próprio exercício`);
    if (exp) { L.push(`percTaxaExpediente = ${frac(s.exp)};  // ${num(s.exp)}% do indexador`); L.push(`receitaExpediente  = ${q(s.receitaExp)};`); }
    L.push("// [opção do campo de enquadramento, fator em " + (s.sigla || "URM") + " por ano]");
    L.push("enquadramentos = [");
    rows.forEach((r, i) => L.push(`  [${q(String(r.op).trim())}, ${fx(num(r.fator) ?? 0, 1)}]` + (i < rows.length - 1 ? "," : "")));
    L.push("];");
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Economico " + economico.codigo + " (" + ano + "): ";', "");
    if (s.mei) {
      L.push("// confirme com imprimir o valor que o porte devolve nesta entidade");
      L.push("porte = economico.porteDaEmpresa;");
      L.push('se (porte == "MEI" || porte == "MICROEMPREENDEDOR_INDIVIDUAL") {');
      L.push('  suspender(ident + "MEI nao paga esta taxa.");');
      L.push("}", "");
    }
    L.push("vlIndexador = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
    L.push("se (vlIndexador == nulo || vlIndexador == 0) {");
    L.push('  suspender(ident + "valor do indexador " + siglaIndexador + " nao cadastrado para " + ano + ".");');
    L.push("}", "");
    L.push("fatorIndexador = 0;");
    L.push("percorrer(enquadramentos) { opcao ->");
    L.push("  se (fatorIndexador == 0 && (CamposAdicionais.valorOpcao(economico, campoEnquadramento, opcao[0], ano) ?: false)) {");
    L.push("    fatorIndexador = opcao[1];");
    L.push("  }");
    L.push("}");
    L.push("se (fatorIndexador == 0) {");
    L.push('  suspender(ident + "enquadramento nao informado no campo " + campoEnquadramento + ".");');
    L.push("}");
    if (s.prop) {
      L.push("", "dtInicio = economico.dataInicioOuReinicio;");
      L.push("se (dtInicio == nulo) {");
      L.push('  suspender(ident + "data de inicio ou reinicio da atividade nao informada.");');
      L.push("}");
      L.push("ehAnoInicio = (Datas.ano(dtInicio) == ano);");
    }
    L.push("", sec("CÁLCULO"));
    if (s.prop) {
      L.push("// ano de início: cobra do mês de início até dezembro; demais anos: 12 meses");
      L.push("mesesDevidos = 12;");
      L.push("se (ehAnoInicio) {");
      L.push("  mesesDevidos = 13 - Datas.mes(dtInicio);");
      L.push("}");
      L.push("vlTaxa = ((vlIndexador * fatorIndexador) / 12) * mesesDevidos;");
    } else {
      L.push("vlTaxa = vlIndexador * fatorIndexador;");
    }
    if (exp) L.push("vlExpediente = vlIndexador * percTaxaExpediente;");
    if (s.prop && s.receitaInicio) {
      L.push("", "receitaLancar = receitaTaxa;");
      L.push("se (ehAnoInicio) {");
      L.push("  receitaLancar = receitaAnoInicio;");
      L.push("}");
    }
    L.push("", sec("RESULTADO"));
    L.push("vlTaxa = Numeros.arredonda(vlTaxa, 2);");
    if (exp) L.push("vlExpediente = Numeros.arredonda(vlExpediente, 2);");
    L.push("");
    L.push(`lancamento.criarReceita(${s.prop && s.receitaInicio ? "receitaLancar" : "receitaTaxa"}, vlTaxa);`);
    if (exp) { L.push("se (vlExpediente > 0) {", "  lancamento.criarReceita(receitaExpediente, vlExpediente);", "}"); }
    return L.join("\n");
  },
  notas: ["O nome do campo adicional e das opções tem de ser idêntico ao cadastro, inclusive acentos e espaços.", "Confira se a data de início deve vir de economico.dataInicioOuReinicio ou de um campo adicional, como em algumas migrações."]
};

/* ---------- MODELO 3: faixas de valor (imóveis) ---------- */
const mFaixas = {
  id: "faixas", titulo: "Imposto ou taxa por faixas de valor (imóveis)", sub: "Alíquota conforme a faixa do valor de um campo adicional, com mínimo e isenção", tipo: "GERACAO_CREDITO · IMOVEIS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:IMOVEIS" }] },
    { grupo: "Base e faixas", itens: [
      { k: "campo", l: "Campo adicional com a base de cálculo", t: "text", lista: "campo:IMOVEIS" },
      { k: "receita", l: "Receita lançada", t: "text", half: true, lista: "receita:credito" },
      { k: "minimo", l: "Valor mínimo em R$ (0 = sem mínimo)", t: "number", half: true },
      { k: "faixas", l: "Faixas (limite vazio = sem limite; use na última)", t: "rows", cols: [["lim", "Até (R$)"], ["aliq", "Alíquota %"]] }
    ] },
    { grupo: "Isenção (opcional)", itens: [
      { k: "isCampo", l: "Campo adicional da isenção", t: "text", lista: "campo:IMOVEIS" },
      { k: "isOpcao", l: "Opção que isenta", t: "text", half: true, lista: "opcao:isCampo" },
      { k: "isBenef", l: "Benefício fiscal (descrição)", t: "text", half: true }
    ] }
  ],
  padrao: { nome: "IPTU Territorial 2026", ano: 2026, credito: "IPTU", campo: "Valor Venal do Imóvel", receita: "I.T.", minimo: 0,
    faixas: [{ lim: 50000, aliq: 0.5 }, { lim: 150000, aliq: 0.8 }, { lim: "", aliq: 1 }], isCampo: "IMUNE/ISENTO IPTU", isOpcao: "Sim", isBenef: "Créditos tributários" },
  avisos(s) {
    const w = [], f = s.faixas || [];
    if (!f.length) w.push("Informe ao menos uma faixa.");
    let ant = -Infinity, aberta = false;
    f.forEach((r, i) => {
      const l = num(r.lim);
      if (num(r.aliq) === null) w.push(`Faixa ${i + 1}: alíquota vazia.`);
      if (aberta) w.push(`Faixa ${i + 1} vem depois de uma faixa sem limite e nunca será usada.`);
      if (l === null) aberta = true; else { if (l <= ant) w.push(`Faixa ${i + 1}: limites precisam estar em ordem crescente.`); ant = l; }
    });
    if (f.length && !aberta) w.push("A última faixa tem limite: valores acima dele suspendem o cálculo. Deixe o limite da última vazio se a lei não tiver teto.");
    if ((s.isCampo && !s.isOpcao) || (!s.isCampo && s.isOpcao)) w.push("Isenção incompleta: informe o campo e a opção.");
    return w;
  },
  gerar(s) {
    const f = s.faixas || [];
    const isento = s.isCampo && s.isOpcao;
    const minimo = num(s.minimo) > 0 ? num(s.minimo) : 0;
    const L = header(s, "Cálculo", s.credito, "alíquota por faixa sobre " + (s.campo || "a base de cálculo") + (minimo ? ", com valor mínimo" : "") + (isento ? ", com isenção por campo adicional" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    L.push(`campoBase = ${q(s.campo)};`);
    L.push(`receita   = ${q(s.receita)};`);
    if (minimo) L.push(`vlMinimo  = ${fx(minimo)};`);
    L.push("// [limite superior da faixa em R$ (nulo = sem limite), alíquota em fração]");
    L.push("faixas = [");
    f.forEach((r, i) => {
      const l = num(r.lim), a = num(r.aliq) ?? 0;
      const linha = `  [${l === null ? "nulo" : fx(l)}, ${fx(a / 100, 3)}]` + (i < f.length - 1 ? "," : "");
      L.push(pad(linha, 30) + `// ${l === null ? "acima da faixa anterior" : "até R$ " + l.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}: ${a.toLocaleString("pt-BR")}%`);
    });
    L.push("];");
    if (isento) { L.push(`campoIsencao     = ${q(s.isCampo)};`); L.push(`opcaoIsencao     = ${q(s.isOpcao)};`); L.push(`beneficioIsencao = ${q(s.isBenef || "")};`); }
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Imovel " + imovel.codigo + " (" + ano + "): ";', "");
    L.push("vlBase = CamposAdicionais.valor(imovel, campoBase, ano);");
    L.push("se (vlBase == nulo) {");
    L.push('  suspender(ident + "campo " + campoBase + " sem valor.");');
    L.push("}");
    if (isento) L.push("", "ehIsento = (CamposAdicionais.valorOpcao(imovel, campoIsencao, opcaoIsencao, ano) ?: false);");
    L.push("", sec("CÁLCULO"));
    L.push("aliquota = nulo;");
    L.push("percorrer(faixas) { faixa ->");
    L.push("  se (aliquota == nulo && (faixa[0] == nulo || vlBase <= faixa[0])) {");
    L.push("    aliquota = faixa[1];");
    L.push("  }");
    L.push("}");
    L.push("se (aliquota == nulo) {");
    L.push('  suspender(ident + "valor " + vlBase + " acima da ultima faixa.");');
    L.push("}", "");
    L.push("vlImposto = vlBase * aliquota;");
    if (minimo) { L.push("se (vlImposto > 0 && vlImposto < vlMinimo) {", "  vlImposto = vlMinimo;", "}"); }
    L.push("", sec("RESULTADO"));
    L.push("vlImposto = Numeros.arredonda(vlImposto, 2);", "");
    L.push("se (vlImposto > 0) {");
    if (isento) {
      L.push("  se (ehIsento) {");
      L.push("    beneficio = Utilitarios.buscaBeneficioFiscal(beneficioIsencao);");
      L.push("    lancamento.criarReceita(receita, vlImposto, beneficio, 100);");
      L.push("  } senao {");
      L.push("    lancamento.criarReceita(receita, vlImposto);");
      L.push("  }");
    } else L.push("  lancamento.criarReceita(receita, vlImposto);");
    L.push("}");
    return L.join("\n");
  },
  notas: ["Se o campo da base for texto no cadastro, troque a leitura por Numeros.numero(...).", "A alíquota da faixa vale sobre o valor inteiro (não é progressiva por parcela de valor). Para progressão por degraus, peça na aba Revisar com IA."]
};

/* ---------- MODELO 4: receita diversa de valor fixo ---------- */
const mReceita = {
  id: "receita", titulo: "Receita diversa de valor fixo", sub: "Certidões, serviços e ressarcimentos: valor em indexador ou R$, opcionalmente por quantidade", tipo: "GERACAO_CREDITO · RECEITAS DIVERSAS",
  campos: [
    { grupo: "Identificação", itens: [...comuns, { k: "credito", l: "Abreviatura do crédito", t: "text", half: true, lista: "credito:RECEITAS_DIVERSAS" }] },
    { grupo: "Valores", itens: [
      { k: "sigla", l: "Indexador (vazio = valores em R$)", t: "text", half: true, lista: "indexador" },
      { k: "qtd", l: "Campo adicional de quantidade (opcional)", t: "text", half: true, lista: "campo:*" },
      { k: "recs", l: "Receitas e valores", t: "rows", cols: [["abrev", "Abreviatura", "receita:credito"], ["valor", "Valor"]] }
    ] }
  ],
  padrao: { nome: "Taxa de Certidão Negativa 2026", ano: 2026, credito: "CERT", sigla: "URM", qtd: "", recs: [{ abrev: "TXCERT", valor: 0.5 }, { abrev: "TXEXP", valor: 0.06 }] },
  avisos(s) {
    const w = [], r = (s.recs || []).filter(x => String(x.abrev || "").trim());
    if (!r.length) w.push("Informe ao menos uma receita.");
    r.forEach(x => { if (!(num(x.valor) > 0)) w.push(`Receita ${x.abrev}: valor vazio ou zero.`); });
    if (s.qtd) w.push("Quantidade por campo adicional: confirme no console que CamposAdicionais.valor aceita receitaDiversa nesta entidade.");
    return w;
  },
  gerar(s) {
    const r = (s.recs || []).filter(x => String(x.abrev || "").trim());
    const ind = String(s.sigla || "").trim();
    const L = header(s, "Cálculo", s.credito, "lança receitas de valor fixo" + (ind ? " em " + ind : " em R$") + (s.qtd ? ", multiplicadas pela quantidade informada" : ""));
    L.push(sec("PARÂMETROS (altere somente aqui)"));
    if (ind) L.push(`siglaIndexador = ${q(ind)};`);
    if (s.qtd) L.push(`campoQuantidade = ${q(s.qtd)};`);
    L.push(`// [abreviatura da receita, valor em ${ind || "R$"}]`);
    L.push("receitasFixas = [");
    r.forEach((x, i) => L.push(`  [${q(String(x.abrev).trim())}, ${fx(num(x.valor) ?? 0)}]` + (i < r.length - 1 ? "," : "")));
    L.push("];");
    L.push("", sec("ENTRADAS E VALIDAÇÕES"));
    L.push('ident = "Receita diversa " + receitaDiversa.codigo + " (" + ano + "): ";', "");
    if (ind) {
      L.push("vlIndexador = Utilitarios.buscaValorDoIndexadorPorSiglaNumaDataEspecifica(siglaIndexador, Datas.data(ano, 1, 1));");
      L.push("se (vlIndexador == nulo || vlIndexador == 0) {");
      L.push('  suspender(ident + "valor do indexador " + siglaIndexador + " nao cadastrado para " + ano + ".");');
      L.push("}");
    } else L.push("vlIndexador = 1;  // valores já estão em R$");
    if (s.qtd) {
      L.push("", "quantidade = CamposAdicionais.valor(receitaDiversa, campoQuantidade, ano) ?: 0;");
      L.push("se (quantidade <= 0) {");
      L.push('  suspender(ident + "quantidade nao informada no campo " + campoQuantidade + ".");');
      L.push("}");
    } else L.push("quantidade = 1;");
    L.push("", sec("CÁLCULO"));
    L.push("// cada receita: valor do parâmetro x indexador x quantidade");
    L.push("valoresCalculados = [];");
    L.push("percorrer(receitasFixas) { rec ->");
    L.push("  valoresCalculados << [rec[0], rec[1] * vlIndexador * quantidade];");
    L.push("}");
    L.push("", sec("RESULTADO"));
    L.push("percorrer(valoresCalculados) { calc ->");
    L.push("  vlReceita = Numeros.arredonda(calc[1], 2);");
    L.push("  se (vlReceita > 0) {");
    L.push("    lancamento.criarReceita(calc[0], vlReceita);");
    L.push("  }");
    L.push("}");
    return L.join("\n");
  },
  notas: ["As abreviaturas precisam existir como receitas do crédito tributário."]
};




function hl(code) {
  return code.split("\n").map(line => {
    const ci = line.indexOf("//");
    let body = ci >= 0 ? line.slice(0, ci) : line, com = ci >= 0 ? line.slice(ci) : "";
    if (/^\s*\/?\*/.test(line)) { body = ""; com = line; }
    let out = esc(body).replace(/(&quot;[^&]*?&quot;|"[^"]*")/g, '<span class="s">$1</span>')
      .replace(/\b(se|senao|percorrer|retornar|suspender|nulo|imprimir)\b/g, '<span class="k">$1</span>');
    return out + (com ? `<span class="c">${esc(com)}</span>` : "");
  }).join("\n");
}
window.GF = { MODELOS: [mDesconto, mEnquadramento, mFaixas, mReceita], hl, esc, num, hoje };
})();
