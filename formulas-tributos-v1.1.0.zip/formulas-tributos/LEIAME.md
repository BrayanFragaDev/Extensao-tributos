# Fórmulas Tributos Cloud: extensão para Chrome e Edge

Painel lateral que aparece no Betha Tributos Cloud para gerar fórmulas no padrão da casa. Ele usa os
nomes reais da entidade aberta (campos adicionais, opções, créditos, receitas e indexadores).

**A extensão não grava nada no Cloud.** Ela só lê dados com a sua sessão. O botão "Inserir no editor"
coloca o código no editor da fórmula aberta, mas salvar continua sendo você, pelo botão Salvar do Cloud.

## Instalar (cada pessoa, modo desenvolvedor)

1. Descompacte o `.zip` numa pasta fixa, por exemplo `C:\Extensoes\formulas-tributos`. Não apague a
   pasta depois: o navegador carrega a extensão a partir dela.
2. Abra `chrome://extensions` (no Edge, `edge://extensions`).
3. Ligue o **Modo do desenvolvedor**, no canto superior direito (no Edge, na barra lateral).
4. Clique em **Carregar sem compactação** e escolha a pasta `formulas-tributos`, a que contém o
   `manifest.json`.
5. Fixe o ícone **fx** na barra do navegador (ícone de quebra-cabeça → alfinete).

Para atualizar: substitua os arquivos da pasta pela versão nova e clique em **Recarregar** no cartão da
extensão, em `chrome://extensions`.

## Usar

1. Entre no Tributos Cloud e abra a entidade.
2. Clique no ícone **fx**. O painel abre ao lado e mostra a entidade.
3. Na primeira vez em cada entidade, clique em **Atualizar dados**. A leitura dos cadastros leva alguns
   segundos. Repita quando criar um campo adicional, uma receita ou um indexador novo.
4. **Modelos:** escolha o modelo e preencha. Os campos de nome sugerem os valores da entidade, e o painel
   marca em amarelo o nome que não existe nela. Depois use:
   - **Copiar código**;
   - **Inserir no editor**, com a fórmula aberta no Cloud;
   - **Revisar com IA**.
5. **Campos:** pesquisa todos os campos adicionais de imóveis e econômicos, pelo nome ou pela opção,
   e mostra tipo, formato, vigência e opções. Em cada campo dá para copiar:
   - a leitura do valor;
   - o teste de uma opção (clique na opção);
   - o preenchimento;
   - o nome exato.

   Marque vários campos para gerar o bloco ENTRADAS E VALIDAÇÕES completo, que suspende o cálculo
   listando todos os campos vazios, ou o bloco de gravação. O botão "Inserir no cursor do editor"
   coloca o bloco onde o cursor está, sem apagar o resto da fórmula.
6. **Fórmulas:** lista as fórmulas cadastradas. Escolha uma para ver o código, copiar,
   mandar para revisão ou copiar o catálogo de variáveis daquele tipo.

Cada entidade tem o próprio perfil: ao trocar de entidade no Cloud, o painel troca sozinho. Em
**Ajustes**, dá para exportar o perfil para um arquivo e importá-lo em outro computador ou passá-lo a
um colega.

## Revisão com IA

"Revisar com IA" copia o código e abre a página **Gerador de Fórmulas Tributos Cloud** no claude.ai,
na aba de revisão. Lá, cole em "Fórmula atual" e clique em Revisar.

- Para a equipe usar, o dono da página precisa compartilhá-la com a organização no claude.ai. Cada
  pessoa então cola o link compartilhado em **Ajustes → Link da página de revisão**.
- Alternativa: marque "Copiar o pedido completo" em Ajustes. O botão passa a copiar o pedido inteiro,
  com as regras da skill, e abre uma conversa nova no Claude para você colar.

## Levar para a equipe toda

- **Poucas pessoas:** o modo desenvolvedor acima basta. O Chrome pode mostrar um aviso sobre extensões
  em modo desenvolvedor ao abrir; é só fechar.
- **Equipe maior:** publique na Chrome Web Store como **não listada**. Ela só aparece para quem tem o
  link e atualiza sozinha. Precisa de uma conta de desenvolvedor (taxa única) e de uma política de
  privacidade simples, dizendo que a extensão não envia dados para fora do navegador.
- **Máquinas gerenciadas pela TI:** a TI pode forçar a instalação pela política `ExtensionInstallForcelist`
  (Chrome ou Edge). Confirme antes se a política de vocês permite extensões.

## Permissões e por que existem

| Permissão | Uso |
|---|---|
| `tributos.betha.cloud` | ler os cadastros e as fórmulas com a sua sessão; só funciona nesse site |
| `scripting` | executar a leitura dentro da página do Cloud |
| `sidePanel` | mostrar o painel lateral |
| `storage` | guardar perfis e configurações neste navegador |
| `tabs` | saber qual entidade está aberta na aba ativa e abrir a página de revisão |
| `clipboardWrite` | copiar o código |

Nenhum dado sai do navegador, a não ser quando você mesmo cola o código na página de revisão ou no Claude.

## Limitações conhecidas

- **Inserir no editor** ainda não foi testado no editor real. Ele procura um editor CodeMirror, Monaco
  ou Ace, ou uma caixa de texto num modal. Se aparecer "Nenhum editor de fórmula aberto", use Copiar
  código e avise quem mantém a extensão.
- A leitura usa os serviços internos da tela do Tributos Cloud. Se a Betha mudar a tela, "Atualizar
  dados" ou "Listar fórmulas" podem parar de funcionar até a extensão ser ajustada. O gerador continua
  funcionando mesmo assim.
- O Cloud encerra a sessão quando você entra em outro navegador. Se o painel parar de ler, faça login de
  novo no Cloud.
