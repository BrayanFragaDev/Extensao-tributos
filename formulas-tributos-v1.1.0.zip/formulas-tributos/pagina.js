/* Funções executadas DENTRO da página do Tributos Cloud (world: MAIN), com a sessão do usuário.
   Somente leitura, exceto inserirNoEditor, que só troca o texto do editor aberto (não salva).
   Cada função precisa ser autocontida: o Chrome serializa o corpo e o executa na página. */

window.PAGINA = {

  contexto: async function () {
    const m = location.hash.match(/#\/entidades\/([^/]+)/);
    if (!m || !window.angular) return { ok: false, motivo: "Abra uma entidade no Tributos Cloud." };
    let chave = "";
    try { chave = atob(decodeURIComponent(m[1])); } catch (e) { chave = m[1]; }
    const ids = Object.fromEntries(chave.split(",").map(p => p.split(":")));
    let nome = "";
    try {
      const inj = angular.element(document.body).injector();
      const r = await inj.get("RestangularArrecadacao").all("entidade").customGET();
      const p = r.plain ? r.plain() : r;
      nome = p.nome || "";
    } catch (e) {}
    return { ok: true, chave: "db" + (ids.database || "?") + "-ent" + (ids.entity || "?"), database: ids.database, entidade: ids.entity, nome };
  },

  dadosEntidade: async function () {
    const inj = angular.element(document.body).injector();
    const plain = r => (r && r.plain ? r.plain() : r);
    async function todas(fn, max) {
      let out = [], off = 0;
      while (off < (max || 5000)) {
        const r = plain(await fn({ limit: 100, offset: off }));
        out = out.concat(r.content || []);
        if (!r.hasNext) break;
        off += 100;
      }
      return out;
    }
    const res = { campos: [], creditos: [], indexadores: [], tabelas: [], avisos: [] };

    try {
      const ca = inj.get("CamposAdicionaisService");
      const lista = await todas(p => ca.getAll(p));
      const pais = lista.filter(c => c.tipo !== "ITEM_SELECAO");
      for (const c of pais) {
        const item = { titulo: c.titulo, cadastro: c.cadastro, tipo: c.tipo, formato: c.formato || null, desabilitado: c.desabilitado, anoInicial: c.anoInicial, anoFinal: c.anoFinal, opcoes: [] };
        if (/SELECAO/.test(c.tipo)) {
          try {
            const r = plain(await ca.getAll({ limit: 100, filter: "itemPai = " + c.id + " and tipo = 'ITEM_SELECAO'" }));
            item.opcoes = (r.content || []).map(o => o.titulo);
          } catch (e) { res.avisos.push("Opções do campo " + c.titulo + " não carregaram."); }
        }
        res.campos.push(item);
      }
    } catch (e) { res.avisos.push("Campos adicionais não carregaram."); }

    try {
      const cs = inj.get("CreditosTributariosService");
      const creditos = await todas(p => cs.getAll(p));
      for (const c of creditos) {
        const item = { abreviatura: c.abreviatura, descricao: c.descricao, tipoCadastro: c.tipoCadastro, desativado: c.desativado, receitas: [] };
        try {
          const r = plain(await cs.getAllReceitas(c.id, { limit: 100 }));
          const rec = (r.content || [])[0];
          const lista = rec && rec.creditosTributarios && rec.creditosTributarios.receitas || [];
          item.receitas = lista.map(x => ({ abreviatura: x.receita && x.receita.abreviatura, descricao: x.receita && x.receita.descricao })).filter(x => x.abreviatura);
        } catch (e) { res.avisos.push("Receitas do crédito " + c.abreviatura + " não carregaram."); }
        res.creditos.push(item);
      }
    } catch (e) { res.avisos.push("Créditos tributários não carregaram."); }

    try {
      const RA = inj.get("RestangularArrecadacao");
      const lista = await todas(p => RA.all("indexadores").customGET(null, p));
      res.indexadores = lista.map(i => {
        const vals = (i.valoresIndexador || []).slice().sort((a, b) => String(b.data).localeCompare(String(a.data)));
        return { sigla: i.sigla, nome: i.nome, tipo: i.tipo, ultimo: vals[0] ? { data: vals[0].data, valor: vals[0].valor } : null };
      });
    } catch (e) { res.avisos.push("Indexadores não carregaram."); }

    try {
      const RA = inj.get("RestangularArrecadacao");
      const lista = await todas(p => RA.all("tabelasCalculos").customGET(null, p));
      res.tabelas = lista.map(t => ({ codigo: t.idTabelasCalculos, ano: t.ano, descricao: t.descricao, origem: t.origemCampos, situacao: t.situacao }));
    } catch (e) { res.avisos.push("Tabelas de cálculo não carregaram."); }

    res.carregadoEm = new Date().toISOString();
    return res;
  },

  listarFormulas: async function () {
    const inj = angular.element(document.body).injector();
    const svc = inj.get("tributos.commons.ScriptsArrecadacaoService");
    let todas = [], off = 0;
    while (off < 5000) {
      const r = (await svc.getAll({ limit: 100, offset: off })).plain();
      todas = todas.concat(r.content || []);
      if (!r.hasNext) break;
      off += 100;
    }
    return todas.map(f => ({
      id: f.id, tipo: f.tipoScript, ano: f.ano, disponivel: f.disponivel,
      descricao: f.script && f.script.descricao, credito: f.creditoTributario && f.creditoTributario.abreviatura,
      tipoCadastro: f.creditoTributario && f.creditoTributario.tipoCadastro,
      usuario: f.usuario, atualizacao: f.ultimaAtualizacao, codigo: f.script && f.script.script
    }));
  },

  catalogo: async function (id) {
    const inj = angular.element(document.body).injector();
    const R = inj.get("Restangular"), base = inj.get("URL_BASE_API_ARRECADACAO");
    const r = await R.allUrl("x", base + "scriptArrecadacao/" + id + "/script").options();
    const cat = r.plain ? r.plain() : r;
    const strip = s => String(s || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
    const curto = t => String(t || "").replace(/^.*\./, "");
    const linhas = [];
    for (const grupo of ["variables", "classes"]) {
      linhas.push(grupo === "variables" ? "## Variáveis" : "## Classes");
      for (const x of cat[grupo] || []) {
        linhas.push("- " + x.name + (x.typeScriptClass ? " [" + x.typeScriptClass + "]" : "") + ": " + strip(x.description));
        for (const m of x.methods || []) {
          const i = m.info || {};
          linhas.push("    ." + i.name + "(" + (i.parameters || []).map(p => p.name).join(", ") + ") -> " + curto(i.returnType) + " | " + strip(i.comment).slice(0, 160));
        }
      }
    }
    return linhas.join("\n");
  },

  inserirNoCursor: function (trecho) {
    const cmEl = Array.from(document.querySelectorAll(".CodeMirror")).filter(e => e.offsetParent !== null).pop();
    if (cmEl && cmEl.CodeMirror) { cmEl.CodeMirror.replaceSelection(trecho); cmEl.CodeMirror.focus(); return { ok: true, editor: "CodeMirror" }; }
    if (window.monaco && monaco.editor && monaco.editor.getEditors) {
      const eds = monaco.editor.getEditors().filter(e => e.getDomNode() && e.getDomNode().offsetParent !== null);
      if (eds.length) { const ed = eds[eds.length - 1]; ed.executeEdits("formulas-tributos", [{ range: ed.getSelection(), text: trecho, forceMoveMarkers: true }]); ed.focus(); return { ok: true, editor: "Monaco" }; }
    }
    const aceEl = Array.from(document.querySelectorAll(".ace_editor")).filter(e => e.offsetParent !== null).pop();
    if (aceEl && window.ace) { const ed = ace.edit(aceEl); ed.insert(trecho); ed.focus(); return { ok: true, editor: "Ace" }; }
    return { ok: false, motivo: "Nenhum editor de fórmula aberto na página." };
  },

  inserirNoEditor: function (codigo) {
    // CodeMirror
    const cmEl = Array.from(document.querySelectorAll(".CodeMirror")).filter(e => e.offsetParent !== null).pop();
    if (cmEl && cmEl.CodeMirror) { cmEl.CodeMirror.setValue(codigo); cmEl.CodeMirror.focus(); return { ok: true, editor: "CodeMirror" }; }
    // Monaco
    if (window.monaco && monaco.editor && monaco.editor.getEditors) {
      const eds = monaco.editor.getEditors().filter(e => e.getDomNode() && e.getDomNode().offsetParent !== null);
      if (eds.length) { eds[eds.length - 1].setValue(codigo); eds[eds.length - 1].focus(); return { ok: true, editor: "Monaco" }; }
    }
    // Ace
    const aceEl = Array.from(document.querySelectorAll(".ace_editor")).filter(e => e.offsetParent !== null).pop();
    if (aceEl && window.ace) { const ed = ace.edit(aceEl); ed.setValue(codigo, 1); ed.focus(); return { ok: true, editor: "Ace" }; }
    // textarea visível dentro de um modal
    const ta = Array.from(document.querySelectorAll(".modal textarea, [role=dialog] textarea")).filter(e => e.offsetParent !== null).pop();
    if (ta) { ta.value = codigo; ta.dispatchEvent(new Event("input", { bubbles: true })); ta.dispatchEvent(new Event("change", { bubbles: true })); return { ok: true, editor: "textarea" }; }
    return { ok: false, motivo: "Nenhum editor de fórmula aberto na página." };
  }
};
